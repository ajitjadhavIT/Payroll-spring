package com.example.PayRoll.DAO;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.TblLeave;

@Component
@Controller
public class LeaveDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	
	
	public TblLeave save(int id,String name,String sf,int ispaid,int limit)
	{
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		TblLeave tbllv=new TblLeave();
		
		tbllv.setIdLeave(id);
		tbllv.setName(name);
		tbllv.setShort_Form(sf);
		tbllv.setIsPaid(ispaid);
		tbllv.setLimit1(limit);
		session.saveOrUpdate(tbllv);
		t.commit();  
		session.close();
		
		return tbllv;
		
	}

	public TblLeave get(String Name)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		TblLeave e1=new TblLeave();
		
		e1 = (TblLeave)session.createCriteria(TblLeave.class).add(Restrictions.eq("name", Name)).uniqueResult();

		session.close(); 
		
		return e1;
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  


		Criteria e1 = session.createCriteria(TblLeave.class);

		return e1.list();
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		TblLeave d = (TblLeave ) session.createCriteria(TblLeave.class)
	             .add(Restrictions.eq("idLeave", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
