package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="otherdeduction")
public class OtherDeduction {
@Id
	//idOtherDeduction, idEmployees, idOtherDeductionType, Date, amount
	int idOtherDeduction;
	int idEmployees;
	int month;
	int year;
	int idOtherDeductionType;
	double amount;
	public int getIdOtherDeductions() {
		return idOtherDeduction;
	}
	public void setIdOtherDeductions(int idOtherDeductions) {
		this.idOtherDeduction = idOtherDeductions;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getIdOtherDeductionType() {
		return idOtherDeductionType;
	}
	public void setIdOtherDeductionType(int idOtherDeductionType) {
		this.idOtherDeductionType = idOtherDeductionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "OtherDeduction [idOtherDeductions=" + idOtherDeduction + ", idEmployees=" + idEmployees + ", month="
				+ month + ", year=" + year + ", idOtherDeductionType=" + idOtherDeductionType + ", amount=" + amount
				+ "]";
	}
	
	
}
