package com.example.PayRoll.POJO;

import java.sql.Time;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="workhours")
public class Workhours {

	@Id
	int idWorkHours;
	int idAttendance;
	Time inTime;
	Time outTime;
	public int getIdWorkHours() {
		return idWorkHours;
	}
	public void setIdWorkHours(int idWorkHours) {
		this.idWorkHours = idWorkHours;
	}
	public int getIdAttendance() {
		return idAttendance;
	}
	public void setIdAttendance(int idAttendance) {
		this.idAttendance = idAttendance;
	}
	public Time getInTime() {
		return inTime;
	}
	public void setInTime(Time inTime) {
		this.inTime = inTime;
	}
	public Time getOutTime() {
		return outTime;
	}
	public void setOutTime(Time outTime) {
		this.outTime = outTime;
	}
	@Override
	public String toString() {
		return "Workhours [idWorkHours=" + idWorkHours + ", idAttendance=" + idAttendance + ", inTime=" + inTime
				+ ", outTime=" + outTime + "]";
	}
	
}
