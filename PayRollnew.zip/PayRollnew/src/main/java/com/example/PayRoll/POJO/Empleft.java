package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="empleft")
public class Empleft 
	//idempleft, idEmployees, Date, reason
{
	@Id
	int idempleft;
	int idEmployees;
	Date date;
	String reason;
	public int getIdempleft() {
		return idempleft;
	}
	public void setIdempleft(int idempleft) {
		this.idempleft = idempleft;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	
	
	
}
