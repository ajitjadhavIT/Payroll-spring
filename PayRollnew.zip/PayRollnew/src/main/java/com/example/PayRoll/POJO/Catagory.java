package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="catagory")
public class Catagory 
{//idCatagory, idDepartment, name
	@Id
	int idCatagory;
	String name;
	int idDepartment;
	public int getIdCatagory() {
		return idCatagory;
	}
	public void setIdCatagory(int idCatagory) {
		this.idCatagory = idCatagory;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIdDepartment() {
		return idDepartment;
	}
	public void setIdDepartment(int idDepartment) {
		this.idDepartment = idDepartment;
	}
	
	
}
