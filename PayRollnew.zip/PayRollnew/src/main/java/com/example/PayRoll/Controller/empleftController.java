package com.example.PayRoll.Controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.EmpleftDAO;
import com.example.PayRoll.Manager.EmpleftManager;
import com.example.PayRoll.POJO.Empleft;

@Component
@Controller
@RequestMapping("/Empleft")
public class empleftController 
{
	@Autowired
	EmpleftManager empleft;
	@Autowired
	EmpleftDAO empdao;
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	
	@RequestMapping("/get")
	@GetMapping
	@ResponseBody
	public Object get(@RequestParam("empcode")String empcode)
	{
		return empleft.get(empcode);
	}
	@RequestMapping("/getall")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public List getall()
	{
		return empleft.getall();
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public List delete(@RequestParam("id")int id)
	{
		return empleft.delete(id);
	}
	@RequestMapping("/save")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Empleft save(@RequestParam("idleft")int idleft,@RequestParam("empcode")String empcode,@RequestParam("date")String date,@RequestParam("reason")String reason) throws ParseException
	{
		return empleft.save(idleft,empcode,date,reason);
	}
	@RequestMapping("/Monthly_left_report")
	@GetMapping
	@ResponseBody
	public Object Monthly_left_report(@RequestParam("Month")String Month,@RequestParam("year")String year)
	{
		if(!Month.matches(patternInt))
		{
			return "Enter the Month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter the year";
		}
		else
		{
			return empdao.Monthly_left_report(Month, year);	
		}
		
	}
	@RequestMapping("/yearly_left_report")
	@GetMapping
	@ResponseBody
	public Object yearly_left_report(@RequestParam("year")String year)
	{
		if(!year.matches(patternInt))
		{
			return "Enter the Valid Year";
		}
		else
		{
		return empdao.yearly_left_report(year);
		}
	}
}
