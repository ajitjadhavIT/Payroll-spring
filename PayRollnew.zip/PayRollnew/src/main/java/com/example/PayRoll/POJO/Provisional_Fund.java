package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pf")
public class Provisional_Fund {

	@Id
	int idPF;
	int idEmpType;
	float maxAmount;
	float percent;
	public int getIdPF() {
		return idPF;
	}
	public void setIdPF(int idPF) {
		this.idPF = idPF;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public float getmaxAmount() {
		return maxAmount;
	}
	public void setmaxAmount(float maxAmount) {
		maxAmount = maxAmount;
	}
	public float getpercent() {
		return percent;
	}
	public void setpercent(float percent) {
		percent = percent;
	}
	@Override
	public String toString() {
		return "Provisional_Fund [idPF=" + idPF + ", idEmpType=" + idEmpType + ", Limit_Condition=" + maxAmount
				+ ", percent=" + percent + "]";
	}
	
}
