package com.example.PayRoll.Manager;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import com.example.PayRoll.DAO.OvertimeDAO;
import com.example.PayRoll.POJO.Overtime;
@Component
@Controller
public class OvertimeManager
{
	@Autowired
	OvertimeDAO overdao;
	public String save(Overtime ov) {
		// TODO Auto-generated method stub
		return overdao.save(ov);
	}
	public Object get(String empcode,Date dt) {
		// TODO Auto-generated method stub
		return overdao.get(empcode,dt);
	}
}
