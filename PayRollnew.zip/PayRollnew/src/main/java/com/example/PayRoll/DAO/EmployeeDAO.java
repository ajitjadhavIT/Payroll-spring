package com.example.PayRoll.DAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Emptype;
import com.example.PayRoll.POJO.Salarytype;
import com.example.PayRoll.POJO.Shift;
@Component
@Controller
public class EmployeeDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	EmptypeDAO emptypeDAO;
	@Autowired
	SalrytypeDAO salarytypeDAO;
	
	public String save(int idemp,String empcode,String efn,String emn,String eln,String gender,String empt,String dob1,
			String bg,String mts,String ads,String nomi,String nmr,String rel,String cast,String qul,long con,
			String email,String wf,int society,String saltype,float salary) throws ParseException
	{	
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date dob = sdf.parse(dob1);
		 
		
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees e=new Employees();
		e.setIdEmployees(idemp);
		e.setEmployeeCode(empcode);
		e.setEmp_First_Name(efn);
		e.setEmp_Middle_Name(emn);
		e.setEmp_Last_Name(eln);
		e.setGender(gender);
		Emptype emp=(Emptype) emptypeDAO.get(empt);
		int idemptype=emp.getIdEmpType();
		e.setIdEmployees(idemp);
		e.setIdEmpType(idemptype);
		e.setdOB(dob);
		e.setBlood_Group(bg);
		e.setMarriatal_Status(mts);
		e.setAddress(ads);
		e.setNominee(nomi);
		e.setNominee_Relation(nmr);
		e.setReligion(rel);
		e.setCast(cast);
		e.setQualification(qul);
		e.setContact_No(con);
		e.setEmail_Id(email);
		e.setWeekly_Off(wf);
		e.setSociety(society);
		
		Criteria cr=session.createCriteria(Salarytype.class);
		cr.add(Restrictions.eq("name", saltype));
		Projection pr=Projections.property("idSalarytype");
		cr.setProjection(pr);
		int idsaltype=(int) cr.uniqueResult();
		//Salarytype s=salarytypeDAO.get(saltype);
		//int idsaltype=s.getIdSalarytype();
		e.setIdSalarytype(idsaltype);
		e.setSalary(salary);
		session.saveOrUpdate(e);
		t.commit();
		session.close();
		return "Saved successfully";
	}

	public Employees get(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession();
		Transaction t = session.beginTransaction();
		@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Employees.class);
		cr.add(Restrictions.eq("employeeCode", empcode));
		return (Employees) cr.uniqueResult();
	}
	
	
	public Employees getemp(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession();
		@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Employees.class);
		cr.add(Restrictions.eq("employeeCode", empcode));
		return  (Employees) cr.uniqueResult();
	}
	
	public List getall()
	{
		Session session = (Session) hipernateConfg.getSession();
	
		@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Employees.class);
	
		return  cr.list();
	}
	
	public List CardPrint(String empcode1,Date date)
	{	
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String, Object>> ShiftandDesig=new ArrayList<Map<String,Object>>();
		String empcode=empcode1;
		Map hm=new HashMap();
		//int empid=((int)session.createQuery("select idEmployees from Employees where EmployeeCode = "+empcode).uniqueResult());
		Query query= session.createQuery("select idEmployees from Employees where EmployeeCode = :empcode");
		query.setParameter("empcode", empcode);
		int empid=(int) query.uniqueResult();
		Query query1= session.createQuery("select emp_First_Name,emp_Middle_Name,emp_Last_Name,weekly_Off from Employees where idEmployees = :empid");
		query1.setParameter("empid", empid);
		List<Object[]> m=query1.list();
		
		String name1=String.valueOf(m.get(0)[0])+" "+String.valueOf(m.get(0)[1])+" "+String.valueOf(m.get(0)[2]);
		Date enterd = date;
		Calendar calendar = Calendar.getInstance();  
	    calendar.setTime(enterd);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    Date fd1 = calendar.getTime();
	        calendar.add(Calendar.MONTH, 1);  
	        calendar.set(Calendar.DAY_OF_MONTH, 1);  
	        calendar.add(Calendar.DATE, -1);
	        Date ld = calendar.getTime();
	        SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
	        String D[] = df.format(ld).split("/");
	        String  month = D[1];
	        String year =D[0];
	        
	        List<Object[]> x=new ArrayList<Object[]>();
	        Criteria cr=session.createCriteria(Attendance.class);
	        cr.add(Restrictions.eq("idEmployees", empid));
	        cr.add(Restrictions.ge("date", fd1));
	        cr.add(Restrictions.lt("date", ld));
	        Projection pr=Projections.property("idShift");
	        Projection pr1=Projections.property("idDesignation");
	        Projection pr2=Projections.property("date");
	        ProjectionList pt=Projections.projectionList();
	        pt.add(pr);
	        pt.add(pr1);
	        pt.add(pr2);
	        cr.setProjection(pt);
	        x=cr.list();
	   
	       
	        for(Object[] row:x)
	        {
	        Map n=new HashMap();
	     	int idShift=(int) row[0];
	        int idDesignation=(int) row[1];
	        Date date1=(Date) row[2];
	        
	        Criteria c=session.createCriteria(Shift.class);
	        c.add(Restrictions.eq("idShift", idShift));
	        Projection pn=Projections.property("name");
	        c.setProjection(pn);
	        String Shiftname=(String) c.uniqueResult();
	        
	        Criteria cs=session.createCriteria(Designation.class);
	        cs.add(Restrictions.eq("idDesignation", idDesignation));
	        Projection psn=Projections.property("name");
	        cs.setProjection(psn);
	        String Designame=(String) cs.uniqueResult();
	        n.put("Shift", Shiftname);
	        n.put("Designation", Designame);
	        n.put("Date", date1);
	        ShiftandDesig.add(n);
	        }
	        hm.put("empname", name1);
	       	hm.put("EmpCode", empcode);
	        hm.put("Weekly_off", m.get(0)[3]);
	        
		return ShiftandDesig;
 }
	public List employees()
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//EmployeeCode,Employeename,group,Department,Designation,Address,Contact
		
		//
		List<Map<String,Object>> empdata1 =new ArrayList<Map<String,Object>>();
		// 
		
		Criteria cp=session.createCriteria(Employees.class);
		Projection a3=Projections.property("employeeCode");
		Projection as=Projections.property("emp_First_Name");
		Projection a1=Projections.property("emp_Middle_Name");
		Projection a2=Projections.property("emp_Last_Name");
		Projection a4=Projections.property("address");
		Projection a5=Projections.property("contact_No");
		ProjectionList pa=Projections.projectionList();
		pa.add(a3);
		pa.add(as);
		pa.add(a1);
		pa.add(a2);
		pa.add(a4);
		pa.add(a5);
		cp.setProjection(pa);
		List<Object[]> empdata=cp.list();
		
		for(Object[] row:empdata)
		{
			Map x=new HashMap();
			String Empcode=(String) row[3];
			int idEmpType=(int)row[6];
			int id=(int)row[7];

			String Group;
			
			Criteria cr=session.createCriteria(Emptype.class);
			cr.add(Restrictions.eq("idEmpType", idEmpType));
			Projection pr=Projections.property("name");
			cr.setProjection(pr);
			Group =(String) cr.uniqueResult(); 
		
			long Contact_No=(long)row[5];
			String Address=(String)row[4];
			String EmpName=String.valueOf(row[0])+" "+String.valueOf(row[1])+" "+String.valueOf(row[2]);
			int idDesignation;
		
			/*
			  SELECT t1.idDesignation, t2.Name,t2.idDepartment, t3.Name FROM EmpWorkDetails t1 join Designation t2 
			  ON t1.idDesignation = t2.idDesignation join Department t3 ON t2.idDepartment = t3.idDepartment 
			  where t1.idEmployees = '1'
			 */
			
			//you can use one query for following three queries
			List<Object[]> m;
			
			Query query1 =session.createQuery("SELECT t1.idDesignation, t2.Name,t2.idDepartment, t3.Name FROM EmpWorkDetails t1 join Designation t2 \r\n" + 
					"			  ON t1.idDesignation = t2.idDesignation join Department t3 ON t2.idDepartment = t3.idDepartment \r\n" + 
					"			  where idEmployees = :idemployees");
			query1.setParameter("idemployees", id);
			m = (List<Object[]>) query1.list();
					
			
			
			String Designame=(String) m.get(0)[1];
			int idDepartment=(int) m.get(0)[2];
			String Name=(String)m.get(0)[3];
			
			
			x.put("Empcode", Empcode);
			x.put("EmpName", EmpName);
			x.put("group", Group);
			x.put("Department", Name);
			x.put("Designation", Designame);
			x.put("Address", Address);
			x.put("Contact", Contact_No);
			empdata1.add(x);
		}
		return empdata1;
	}

	public List delete(String empcode) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees d = (Employees ) session.createCriteria(Employees.class)
                 .add(Restrictions.eq("employeeCode", empcode)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
}
