package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.TDSDAO;
import com.example.PayRoll.POJO.TDS;
@Controller
@Component
public class TDSManager {

	@Autowired
	TDSDAO tdsDAO;
	public String save(TDS t) {
		// TODO Auto-generated method stub
		return tdsDAO.save(t);
	}

	public Object get(String id) {
		// TODO Auto-generated method stub
		return tdsDAO.get(id);
	}

}
