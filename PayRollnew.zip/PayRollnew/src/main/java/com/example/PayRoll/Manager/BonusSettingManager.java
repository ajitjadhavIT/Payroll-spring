package com.example.PayRoll.Manager;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.BonusSettingDAO;
import com.example.PayRoll.POJO.BonusSetting;
@Component
@Controller
public class BonusSettingManager {
	
	@Autowired
	BonusSettingDAO bsDAO;

	public BonusSetting save(BonusSetting bs) {
		// TODO Auto-generated method stub
	
		
		return bsDAO.save(bs);
	}

	public Object get(float con) {
	
		
		return bsDAO.get(con);
	}

	public List getall() {
		// TODO Auto-generated method stub
		return bsDAO.getall();
	}

	public Object delete(int id) {
		// TODO Auto-generated method stub
		return bsDAO.delete(id);
	}

}
