package com.example.PayRoll.Manager;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.OtherDeductionsDAO;
import com.example.PayRoll.POJO.OtherDeduction;

@Controller
@Component
public class OtherDeductionsManager {

	@Autowired
	OtherDeductionsDAO ODAO;
	public OtherDeduction save(int id,String Empcode,String dedname,int month,float amount,int year) {
		
		return ODAO.save(id,Empcode,dedname,month,amount,year);
	}

	public Object get(String empcode) {
		// TODO Auto-generated method stub
		return ODAO.get(empcode);

	}
	public List getall() {
		// TODO Auto-generated method stub
		return ODAO.getall();

	}

	
}
