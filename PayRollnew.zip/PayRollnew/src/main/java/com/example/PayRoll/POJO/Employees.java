package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employees")
public class Employees 
{/*idEmployees, employeeCode, emp_First_Name, emp_Middle_Name, emp_Last_Name, gender, 
	idEmpType, dOB, blood_Group, marriatal_Status, address, nominee, nominee_Relation,
	religion, cast, qualification, contact_No, email_Id, weekly_Off, society*/
	@Id
	int idEmployees;
	String employeeCode;
	String emp_First_Name;
	String emp_Middle_Name;
	String emp_Last_Name;
	String gender;
	int idEmpType;
	Date dOB;
	String blood_Group;
	String marriatal_Status;
	String address;
	String nominee;
	String nominee_Relation;
	String religion;
	String cast;
	String qualification;
	long contact_No;
	String email_Id;
	String weekly_Off;
	int society;
	int idSalarytype;//idSalaryType
	float salary;
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getEmp_First_Name() {
		return emp_First_Name;
	}
	public void setEmp_First_Name(String emp_First_Name) {
		this.emp_First_Name = emp_First_Name;
	}
	public String getEmp_Middle_Name() {
		return emp_Middle_Name;
	}
	public void setEmp_Middle_Name(String emp_Middle_Name) {
		this.emp_Middle_Name = emp_Middle_Name;
	}
	public String getEmp_Last_Name() {
		return emp_Last_Name;
	}
	public void setEmp_Last_Name(String emp_Last_Name) {
		this.emp_Last_Name = emp_Last_Name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public Date getdOB() {
		return dOB;
	}
	public void setdOB(Date dOB) {
		this.dOB = dOB;
	}
	public String getBlood_Group() {
		return blood_Group;
	}
	public void setBlood_Group(String blood_Group) {
		this.blood_Group = blood_Group;
	}
	public String getMarriatal_Status() {
		return marriatal_Status;
	}
	public void setMarriatal_Status(String marriatal_Status) {
		this.marriatal_Status = marriatal_Status;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getNominee() {
		return nominee;
	}
	public void setNominee(String nominee) {
		this.nominee = nominee;
	}
	public String getNominee_Relation() {
		return nominee_Relation;
	}
	public void setNominee_Relation(String nominee_Relation) {
		this.nominee_Relation = nominee_Relation;
	}
	public String getReligion() {
		return religion;
	}
	public void setReligion(String religion) {
		this.religion = religion;
	}
	public String getCast() {
		return cast;
	}
	public void setCast(String cast) {
		this.cast = cast;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public long getContact_No() {
		return contact_No;
	}
	public void setContact_No(long contact_No) {
		this.contact_No = contact_No;
	}
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getWeekly_Off() {
		return weekly_Off;
	}
	public void setWeekly_Off(String weekly_Off) {
		this.weekly_Off = weekly_Off;
	}
	public int getSociety() {
		return society;
	}
	public void setSociety(int society) {
		this.society = society;
	}
	public int getIdSalarytype() {
		return idSalarytype;
	}
	public void setIdSalarytype(int idSalarytype) {
		this.idSalarytype = idSalarytype;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	
	
	
}
