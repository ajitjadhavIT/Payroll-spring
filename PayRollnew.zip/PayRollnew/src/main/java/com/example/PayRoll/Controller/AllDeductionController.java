package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.AllDeductionDAO;
import com.example.PayRoll.Manager.BasicSalaryManager;

@Controller
@RequestMapping("AllDeduction")
public class AllDeductionController {
	
	@Autowired
	AllDeductionDAO adDAo;
	
	@RequestMapping("/dedAmount")
	@PostMapping
	@ResponseBody
	public Object Amount(@RequestParam("empcode")String empcode,@RequestParam("month") int month,@RequestParam("year") int year,@RequestParam("name") String name)
	{
		return adDAo.deductionAmount(empcode,month,year,name);
	}

}
