package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.BonusSetting;
import com.example.PayRoll.POJO.Catagory;
import com.example.PayRoll.POJO.IncentAmount;
@Component
@Controller
public class BonusSettingDAO {
	
	@Autowired
	HipernateConfg hipernateConfg;
	

	public BonusSetting save(BonusSetting bs) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		System.err.println("start  "+bs.getStartmonth()+"\n end "+bs.getEndmonth());
		session.saveOrUpdate(bs);
		t.commit();  
		session.close();
		return bs;
	}


	public Object get(float con) {
		Session session = (Session) hipernateConfg.getSession();  
				//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(BonusSetting.class);
				cr.add(Restrictions.eq("condition1", con));
				return (BonusSetting) cr.uniqueResult();
		
	}


	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		Criteria cr = session.createCriteria(BonusSetting.class);
		return cr.list();
		
	}


	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		BonusSetting d = (BonusSetting ) session.createCriteria(BonusSetting.class)
                 .add(Restrictions.eq("idBonusSetting", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
	
	

}
