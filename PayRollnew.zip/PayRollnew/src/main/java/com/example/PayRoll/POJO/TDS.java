package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tds")
public class TDS {
//idTDS, idEmpType, fromAmount, Percent, toAmount, tDScol
	@Id
	int idTDS;
	int idEmpType;
	float fromAmount;
	float percent;
	float toAmount;
	float tDScol;
	public int getIdTDS() {
		return idTDS;
	}
	public void setIdTDS(int idTDS) {
		this.idTDS = idTDS;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public float getfromAmount() {
		return fromAmount;
	}
	public void setfromAmount(float fromAmount) {
		fromAmount = fromAmount;
	}
	public float getPercent() {
		return percent;
	}
	public void setPercent(float percent) {
		this.percent = percent;
	}
	public float gettoAmount() {
		return toAmount;
	}
	public void settoAmount(float toAmount) {
		toAmount = toAmount;
	}
	public float gettDScol() {
		return tDScol;
	}
	public void settDScol(float tDScol) {
		tDScol = tDScol;
	}
	@Override
	public String toString() {
		return "TDS [idTDS=" + idTDS + ", idEmpType=" + idEmpType + ", fromAmount=" + fromAmount + ", percent="
				+ percent + ", toAmount=" + toAmount + ", tDScol=" + tDScol + "]";
	}
	
	
}
