package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.CategoryManager;
import com.example.PayRoll.POJO.Catagory;

@Component

@Controller
@RequestMapping("/Category")
public class CategoryController 
{
	@Autowired
	CategoryManager catman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("Name")String Name)
	{
		return catman.get(Name); 
	}
	
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	@RequestMapping("/save")
	public Catagory save(@RequestParam("idcatagory")int idcat,@RequestParam("deptName")String dept,@RequestParam("cName")String name)
	{//idCatagory, idDepartment, Name
		
			return catman.save(idcat,dept,name);
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public Object getall()
	{
	
		return catman.getall();
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/delete")
	public Object delete(@RequestParam("name")String name)
	{
	
		return catman.delete(name);
		
	}
	
}
