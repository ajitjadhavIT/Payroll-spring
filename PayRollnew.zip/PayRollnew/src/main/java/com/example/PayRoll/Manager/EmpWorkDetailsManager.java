package com.example.PayRoll.Manager;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.EmpWorkDetailsDAO;
import com.example.PayRoll.POJO.EmpWorkDetails;
@Component
@Controller
public class EmpWorkDetailsManager 
{	@Autowired
	EmpWorkDetailsDAO empwdtdao;

	public EmpWorkDetails save(String empcode,int iddes,int ids,String wrkarea,Date jdate) 
	{
		return null;
	}
	public Object get(String empcode) 
	{
		return empwdtdao.get(empcode);
	}
}
