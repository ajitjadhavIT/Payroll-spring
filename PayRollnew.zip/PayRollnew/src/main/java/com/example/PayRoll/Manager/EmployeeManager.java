package com.example.PayRoll.Manager;


import java.text.ParseException;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.DAO.BankdetailsDAO;
import com.example.PayRoll.DAO.BasicSalaryDAO;
import com.example.PayRoll.DAO.DesignationDAO;
import com.example.PayRoll.DAO.EmpWorkDetailsDAO;
import com.example.PayRoll.DAO.EmployeeDAO;
import com.example.PayRoll.DAO.ShiftDAO;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Shift;
@Component
@Controller
public class EmployeeManager 
{	@Autowired
	EmployeeDAO empdao;
	@Autowired
	BasicSalaryDAO basicSalaryDAO;
	@Autowired
	BankdetailsDAO bankdao;
	@Autowired
	EmpWorkDetailsDAO empworkdao;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	DesignationDAO designationDAO;
	@Autowired
	HipernateConfg hipernateConfg;
	
public String save(int idemp,String empcode,String efn,String emn,String eln,String gender,String empt,String dob,
		String bg,String mts,String ads,String nomi,String nmr,String rel,String cast,String qul,long con,
		String email,String wf,int society,String saltype,float salary) throws ParseException
{
	
	return empdao.save(  idemp, empcode, efn, emn, eln, gender, empt,
			 dob, bg, mts, ads, nomi, nmr, rel, cast,
			 qul, con, email, wf, society, saltype, salary);
}
public Employees getemp(String empcode)
{
	return empdao.getemp(empcode);
}
public Employees saveEmployees(int idemp,int idbank,int idwork,String empcode,String efn,String emn,String eln,String gender,
							String emptype,String dob,String bg,String mts,String ads,
							String nomi,String nmr,String rel,String cast,String qul,long con,
							String email,String wf,int society,String saltype,float salary,String desname,String shiftname,
							String wrkarea,String jdate,String bankname,String accno,String branch,
							String acctype,String ifsccode,String pfno) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	System.err.println("Designation "+desname);
	this.save(idemp,empcode, efn, emn, eln, gender, emptype,
			 dob, bg, mts, ads, nomi, nmr, rel, cast,
			 qul, con, email, wf, society, saltype, salary);
	 
	 bankdao.save( idbank,empcode, bankname, accno, branch, acctype, ifsccode, pfno);
	 Shift sft=(Shift) shiftDAO.getname(shiftname);
	 
	 Criteria cr=session.createCriteria(Designation.class);
	 cr.add(Restrictions.eq("short_Form", desname));
	 Projection pr=Projections.property("idDesignation");
	 cr.setProjection(pr);
	 int des=(int) cr.uniqueResult();
	 
	 Criteria cr1=session.createCriteria(Shift.class);
	 cr1.add(Restrictions.eq("name", shiftname));
	 Projection pr1=Projections.property("idShift");
	 cr1.setProjection(pr1);
	 int sft1=(int) cr1.uniqueResult();
//	 Designation des= (Designation) designationDAO.get(desname);
	 System.err.println("shift"+sft1);
	 System.err.println("des"+des);
	 empworkdao.save( idwork,empcode, des, sft1, wrkarea, jdate);
	return null;
}
public Object getall() {
	// TODO Auto-generated method stub
	return empdao.getall();
}
}
