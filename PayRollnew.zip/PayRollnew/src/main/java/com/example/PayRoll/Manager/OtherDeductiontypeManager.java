package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.DAO.OtherDeductiontypeDAO;
import com.example.PayRoll.POJO.OtherDeductiontype;
@Component
public class OtherDeductiontypeManager {
	@Autowired
	OtherDeductiontypeDAO oddao;

	public OtherDeductiontype save(int id,String name) {
		
		return oddao.save(id,name);
	}

	public Object getall() {
		// TODO Auto-generated method stub
		return oddao.getall();
	}

	public Object delete(String name) {
		// TODO Auto-generated method stub
		return oddao.delete(name); 
	}

}
