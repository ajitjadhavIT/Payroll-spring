package com.example.PayRoll.utils;

public class Response<T> {

	private String statusCode;
	private String message;
	private T resut;
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getResut() {
		return resut;
	}
	public void setResut(T resut) {
		this.resut = resut;
	}
	

	
	
}
