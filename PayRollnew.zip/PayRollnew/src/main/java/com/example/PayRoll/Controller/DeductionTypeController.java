package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.DeductionTypemanager;
import com.example.PayRoll.POJO.DeductionType;

	@Controller
	@RequestMapping("DeductionType")
	
	public class DeductionTypeController
	{
		
		@Autowired
		DeductionTypemanager dtManager;
		@RequestMapping("/save")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public DeductionType save(@RequestParam("id")int id,@RequestParam("name")String name)
		{
			
				return dtManager.save(id,name);
		}
		
		@RequestMapping("/getall")
		@PostMapping
		@ResponseBody
		public Object getall()
		{
			
				return dtManager.getall();
		}
		
		
	
}
