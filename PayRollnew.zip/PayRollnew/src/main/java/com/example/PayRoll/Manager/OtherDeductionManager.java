package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.BasicSalaryDAO;
import com.example.PayRoll.DAO.OtherDeductionDAO;
@Controller
@Component
public class OtherDeductionManager {

	@Autowired
	OtherDeductionDAO ODdao;
	
	@Autowired
	BasicSalaryDAO bsDAO;
	
	public double AllDeductions(String empcode, int month, int year) {
		// TODO Auto-generated method stub
		return ODdao.AllDeduction(empcode,month,year);
	}
	
	public Object SingleDeduction(String empcode, int month, int year)
	{
		return ODdao.AllDeduction(empcode, month, year);
	}

	

}
