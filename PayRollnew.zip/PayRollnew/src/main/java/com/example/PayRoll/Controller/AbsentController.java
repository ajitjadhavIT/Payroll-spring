package com.example.PayRoll.Controller;

import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.AbsentDAO;
import com.example.PayRoll.Manager.AbsentManager;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.DayPresent;

@Component
@Controller
@RequestMapping("/Absent")
public class AbsentController
{
	@Autowired
	AbsentManager absentManager;
	@Autowired
	AbsentDAO absentdao;
	@Autowired 
	DayPresent dp;
	
	@RequestMapping("/get")
	@GetMapping
	@ResponseBody
	public Absent get(@RequestParam("Empcode")String empcode,@RequestParam("Date")Date date)
	{
		return absentdao.get(empcode,date);
	}
	
	@PostMapping("/save")
	@ResponseBody
	
	public Object save(@RequestParam("idabsent")int idabsent,@RequestParam("date")Date date,@RequestParam("Shift")String shift,@RequestParam("Designation")String des,@RequestParam("Empcode")String empcode,@RequestParam("Reason")String Reason)
	{
		
		
		 if(shift.isEmpty())
		{
			return "Enter the valid idSHift";
		}
		else if(des.isEmpty())
		{
			return "Enter the valid iddes";
		}
		else if(empcode.isEmpty())
		{
			return "Enter the valid idemp";
		}
		else
		{
			return absentManager.save(idabsent,date,shift,des,empcode,Reason);
			}
	}
	
	@PostMapping("/AbsentReport")
	@ResponseBody
	public List AbsentReport(@RequestParam("Date")Date date)
	{
		System.err.println("date"+date);
		return absentdao.AbsentReport(date);
		
	}
	@PostMapping("/MonthAbsentReport")
	@ResponseBody
	public Object Absent_Monthly_Report(@RequestParam("Month")String Month,@RequestParam("year")String year)
	{
		
			return absentdao.Absent_Monthly_Report(Month, year);
		
		
	}
	
	@PostMapping("/Absent_yearly_Report")
	@ResponseBody
	public Object Absent_yearly_Report(String year)
	{
		
		return absentdao.Absent_yearly_Report(year);
		
	}
	@RequestMapping("/Day_Report")
	@GetMapping
	@ResponseBody
	public DayPresent Day_Report(Date date)
	{
		return absentdao.Day_Report(date);
	}
}

