package com.example.PayRoll.DAO;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.PersistentObjectException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ejb.access.EjbAccessException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Empleave;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Hoursleave;
import com.example.PayRoll.POJO.IncentAmount;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.TblLeave;
@Component
@Controller

public class BasicSalaryDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	
	public float DesignationSal(String empcode, int month, int year) {
		Session session = (Session) hipernateConfg.getSession();  
	
		int enterdmonth =month-1;
		
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd = calendar.getTime();
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
   

        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld = calendar.getTime();
    
        System.err.println("#########################in basic firstdate "+fd+"\n lastdate "+ld);
		
		List<Object[]> hm1 = new ArrayList<Object[]>();
	Criteria c=session.createCriteria(Employees.class);
	c.add(Restrictions.eq("employeeCode", empcode));
	Projection p=Projections.property("idEmployees");
		
	c.setProjection(p);
	int idemp=(int) c.uniqueResult();
	System.err.println("idemp"+idemp);
	
	
		Criteria cr=session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", idemp));
		cr.add(Restrictions.ge("date", fd)); 
		cr.add(Restrictions.lt("date", ld));
		
		
		Projection pr=Projections.property("idDesignation");
		Projection pt7=Projections.distinct(pr);
		Projection pr1=Projections.rowCount();
		
		ProjectionList pl=Projections.projectionList();
		pl.add(pt7);
		pl.add(pr1);
		cr.setProjection(pl);
		hm1=cr.list();


		int idDesignation=0;
		float totalsalary=0.0f;
		int presentDays=0;
		for(Object[] row : hm1)
		{
			
		
			try {
				
			
			idDesignation = Integer.parseInt(String.valueOf( row[0]));
		
			Criteria cp=session.createCriteria(Designation.class);
			cp.add(Restrictions.eq("idDesignation",idDesignation));
			Projection pt=Projections.property("salary");
			cp.setProjection(pt);
			float salary=(float)cp.uniqueResult();
			presentDays = Integer.parseInt(String.valueOf( row[1]));
			totalsalary+=presentDays*salary;
			}
			catch(Exception e)
			{
				
			}
		}
		session.close();
		return totalsalary;
	}

	public float Overtime(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		int enterdmonth =month-1;
		
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd1 = calendar.getTime();
        
        
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
	
		Criteria as=session.createCriteria(Employees.class);
		as.add(Restrictions.eq("employeeCode", empcode));
		Projection ps=Projections.property("idSalarytype");
		Projection ps1=Projections.property("idEmployees");
		ProjectionList pl=Projections.projectionList();
		pl.add(ps);
		pl.add(ps1);
		as.setProjection(pl);
		List<Object[]> idEmpTypeemp=as.list();
		int idEmp=(int) idEmpTypeemp.get(0)[1];
		int idSalaryType=(int) idEmpTypeemp.get(0)[0];
	
		if(idSalaryType==1)
		{
			List<Object[]> hm = new ArrayList<Object[]>();
			
			
			Criteria cr=session.createCriteria(Overtime.class);
			cr.add(Restrictions.eq("idEmployees", idEmp));
			cr.add(Restrictions.ge("date", fd1)); 
			cr.add(Restrictions.lt("date", ld1));
			
			Projection pd=Projections.property("idDesignation");
			Projection pd1=Projections.property("hours");
			ProjectionList pt=Projections.projectionList();
			pt.add(pd);
			pt.add(pd1);
			cr.setProjection(pt);
			hm=cr.list();
			
			int idDesignation=0;
			float hours;
			float DesHRSal=0.0f;
			float DesovrSal=0.0f;
			
			for(Object[] row : hm)
			{
				idDesignation = Integer.parseInt(String.valueOf( row[0]));
			
				hours= Float.parseFloat(String.valueOf((row[1])));
				
				Criteria cp=session.createCriteria(Designation.class);
				cp.add(Restrictions.eq("idDesignation", idDesignation));
				Projection a=Projections.property("salary");
				cp.setProjection(a);
				float Salary=(float) cp.uniqueResult();

				float daySalary=Salary/daysInMonth;
				DesHRSal=daySalary/8;
				DesovrSal+=hours*DesHRSal;
		
			}
	
			return DesovrSal;
		}
		else if(idSalaryType==2)
			
			{
			float ovrtimehours=0.0f;
			float salformonth=0.0f;
			try {
				
				
				Criteria sd=session.createCriteria(Overtime.class);
				sd.add(Restrictions.eq("idEmployees", idEmp));
				sd.add(Restrictions.ge("date", fd1));
				sd.add(Restrictions.lt("date", ld1));
				Projection p=Projections.sum("hours");
				sd.setProjection(p);
				ovrtimehours=(float) sd.uniqueResult();
				
				Criteria ds=session.createCriteria(Employees.class);
				ds.add(Restrictions.eq("idEmployees", idEmp));
				Projection s=Projections.property("salary");
				ds.setProjection(s);
				salformonth=(float) ds.uniqueResult();
				
			
			}
			catch(Exception ex)
			{
				ovrtimehours=0.0f;
			}
				float perdaysal=salformonth/daysInMonth;
				float perHRsal=perdaysal/8;
				float overtimeHRSal=perHRsal*ovrtimehours;
				return overtimeHRSal;
			}
		else if(idSalaryType==3)
			{float ovrtimehours=0.0f;
			float PerDaySal=0.0f;
			try {
				
				Criteria sd=session.createCriteria(Overtime.class);
				sd.add(Restrictions.eq("idEmployees", idEmp));
				sd.add(Restrictions.ge("date", fd1));
				sd.add(Restrictions.lt("date", ld1));
				Projection p=Projections.sum("hours");
				sd.setProjection(p);
				ovrtimehours=(float) sd.uniqueResult();
				
				Criteria ds=session.createCriteria(Employees.class);
				ds.add(Restrictions.eq("idEmployees", idEmp));
				Projection s=Projections.property("salary");
				ds.setProjection(s);
				PerDaySal=(float) ds.uniqueResult();
				
				
			}	
			catch(Exception ex)
			{
				PerDaySal=0.0f;
				ovrtimehours=0.0f;
			}
				
				float perHRsal=PerDaySal/8;
				float overtimeHRsal=perHRsal*ovrtimehours;
				return overtimeHRsal;
			}
		session.close();
		return 0.0f;
		}
		
	public float paidLeaveSal(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int enterdmonth =month-1;
		int enterdYear=year;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd1 = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

		int year1 = calendar.get(Calendar.YEAR);
		int month1 = calendar.get(Calendar.MONTH);
		
		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
	
		Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		b.setProjection(ad);
		int idEmp=(int) b.uniqueResult();
		
		List<Object[]> hm1 = new ArrayList<Object[]>();
		System.err.println("idEmpoyee =" +idEmp);
		Criteria xz=session.createCriteria(Attendance.class);
		xz.add(Restrictions.eq("idEmployees", idEmp));
		//xz.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		Projection pd=Projections.property("idDesignation");
		Projection pd1=Projections.rowCount();
		ProjectionList pt=Projections.projectionList();
		pt.add(pd);
		pt.add(pd1);
		xz.setProjection(pt);
		hm1=xz.list();
		
		
		int idDesignation=0;
		int presentDays=0;
		float salary=0.0f;
		float totalsalary=0.0f;
		for(Object[] row : hm1)
		{
		
			idDesignation = Integer.parseInt(String.valueOf(row[0]));

			Criteria cp=session.createCriteria(Designation.class);
			cp.add(Restrictions.eq("idDesignation", idDesignation));
			Projection a=Projections.property("salary");
			cp.setProjection(a);
			 salary=(float) cp.uniqueResult();
			
			presentDays += Integer.parseInt(String.valueOf( row[1]));
			totalsalary+=presentDays*salary;
			
		}
		float paidleavesal=0.0f;
		int idLeave=0;
		int isPaid=0;
		try {
		
		Criteria cp=session.createCriteria(Designation.class);
		cp.add(Restrictions.eq("idDesignation", idDesignation));
		Projection a=Projections.property("salary");
		cp.setProjection(a);
		 paidleavesal=(float) cp.uniqueResult();
		
		Criteria d=session.createCriteria(Empleave.class);
		d.add(Restrictions.eq("idEmployees", idEmp));
		Projection fd=Projections.property("idLeaave");
		d.setProjection(fd);
		idLeave=(int) d.uniqueResult();
		
		Criteria s=session.createCriteria(TblLeave.class);
		s.add(Restrictions.eq("idLeave", idLeave));
		Projection f=Projections.property("isPaid");
		s.setProjection(f);
		isPaid=(int)s.uniqueResult();
		
		}
		catch(Exception ex)
		{
			 paidleavesal=0.0f;
			 idLeave=0;
			 isPaid=0;
		}
		
		float totalPaidLeaveSal=isPaid*paidleavesal;
		session.close();
		
		return totalPaidLeaveSal;
		
	
	}
	public float LeaveHR(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month;
		int enterdYear=year;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd1 = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

		int year1 = calendar.get(Calendar.YEAR);
		int month1 = calendar.get(Calendar.MONTH);
		
		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		 
	     Criteria b=session.createCriteria(Employees.class);
			b.add(Restrictions.eq("employeeCode", empcode));
			Projection ad=Projections.property("idEmployees");
			Projection ad1=Projections.property("idSalarytype");
			ProjectionList pr=Projections.projectionList();
			pr.add(ad);
			pr.add(ad1);
			b.setProjection(pr);
			 List<Object[]> idEmpSalType= b.list();
	        
		
		int idEmp=(int) idEmpSalType.get(0)[0];
		int idSalaryType=(int) idEmpSalType.get(0)[1];
		Map salHours=new HashMap();
		float EmpSal=0.0f;
		
		float leavehours=0.0f;
		try {
		
		Criteria a=session.createCriteria(Employees.class);
		a.add(Restrictions.eq("idEmployees", idEmp));
		Projection p=Projections.property("salary");
		a.setProjection(p);
		EmpSal=(float)a.uniqueResult();

		Criteria ab=session.createCriteria(Hoursleave.class);
		ab.add(Restrictions.eq("idEmployees", idEmp));
		ab.add(Restrictions.ge("date", fd1));
		ab.add(Restrictions.lt("date", ld1));
		Projection pb=Projections.sum("hours");
		ab.setProjection(pb);
		
		leavehours=(float) ab.uniqueResult();
		}
		catch(NullPointerException ex)
		{
			 EmpSal=0.0f;
			 leavehours=0.0f;
		}
		if(idSalaryType==1)
		{
		List<Map<String, Object>> hm = new ArrayList<Map<String, Object>>();
	
		Criteria ab=session.createCriteria(Hoursleave.class);
		ab.add(Restrictions.eq("idEmployees", idEmp));
		ab.add(Restrictions.ge("date", fd1));
		ab.add(Restrictions.lt("date", ld1));
		Projection pq=Projections.property("idDesignation");
		Projection pb=Projections.property("hours");
		ProjectionList list=Projections.projectionList();
		list.add(pq);
		list.add(pb);
		
		ab.setProjection(list);
		hm=ab.list();
		
		int idDesignation=0;
		float hours;
		float DesHRSal=0.0f;
		float DesLeaveSal=0.0f;
		
		for(Map row : hm)
		{
			idDesignation = Integer.parseInt(String.valueOf( row.get("idDesignation")));
		
			hours= Float.parseFloat(String.valueOf((row.get("hours"))));
			
			
			Criteria cp=session.createCriteria(Designation.class);
			cp.add(Restrictions.eq("idDesignation", idDesignation));
			Projection a=Projections.property("salary");
			cp.setProjection(a);
			 float Salary=(float) cp.uniqueResult();
			
			float daySalary=Salary/daysInMonth;
			DesHRSal=daySalary/8;
			DesLeaveSal+=hours*DesHRSal;
	
		}

		return DesLeaveSal;
	}
	else if(idSalaryType==2)
		{
			float perdaysal=EmpSal/daysInMonth;
			float perHRsal=perdaysal/8;
			float LeaveHRSal=perHRsal*leavehours;
			return LeaveHRSal;
		}
	else if(idSalaryType==3)
		{
			float perHRsal=EmpSal/8;
			float LeaveHRsal=perHRsal*leavehours;
			return LeaveHRsal;
		}
		session.close();
	return 0.0f;
	}
	
	public float PerDaySal(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        Date fd1 = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

        Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		Projection ad1=Projections.property("salary");
		ProjectionList pr=Projections.projectionList();
		pr.add(ad);
		pr.add(ad1);
		b.setProjection(pr);
		 List<Object[]> emsal= b.list();
        
        
        
        
		int idEmp=(int) emsal.get(0)[1];
		float salforday=(float) emsal.get(0)[0];
		
		Criteria dc=session.createCriteria(Attendance.class);
		dc.add(Restrictions.eq("idEmployees", idEmp));
		dc.add(Restrictions.ge("date", fd1));
		dc.add(Restrictions.lt("date", ld1));
		Projection p=Projections.rowCount();
		dc.setProjection(p);
		int PresentDays=(int) dc.uniqueResult();
		
		float Salaryperday=salforday*PresentDays;
		session.close();
		return Salaryperday;
	}

	public float MonthlySal(String empcode, int month, int year) {
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month;
		
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        Date fd1 =calendar.getTime();
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        Date fd=null;

        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();
        Date ld=null;
		
		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

		  Criteria b=session.createCriteria(Employees.class);
			b.add(Restrictions.eq("employeeCode", empcode));
			Projection ad=Projections.property("idEmployees");
			Projection ad1=Projections.property("salary");
			ProjectionList pr=Projections.projectionList();
			pr.add(ad);
			pr.add(ad1);
			b.setProjection(pr);
			 List<Object[]> emsal= b.list();
	        
		
		
		
		int idEmp=(int) emsal.get(0)[0];
		float salforMonth=(float) emsal.get(0)[1];
	
		Criteria dc=session.createCriteria(Attendance.class);
		dc.add(Restrictions.eq("idEmployees", idEmp));
		dc.add(Restrictions.ge("date", fd1));
		dc.add(Restrictions.lt("date", ld1));
		Projection p=Projections.rowCount();
		dc.setProjection(p);
		long PresentDays=(long) dc.uniqueResult();
		
		float Salaryperday=salforMonth/daysInMonth;
		float salarypermonth=Salaryperday*PresentDays;
		session.close();
		return salarypermonth;
	}
	public float Incentive(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month-1;
		int enterdYear=year;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        String fd1 =new SimpleDateFormat("yyyy/MM/dd").format(calendar.getTime());
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        Date fd=null;

        try {
			fd=format.parse(fd1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        String ld1 = new SimpleDateFormat("YYYY/MM/dd").format(calendar.getTime());
        Date ld=null;
		try {
			 ld=format.parse(ld1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		  Criteria b=session.createCriteria(Employees.class);
			b.add(Restrictions.eq("employeeCode", empcode));
			Projection ad=Projections.property("idEmployees");
			Projection ad1=Projections.property("idEmpType");
			ProjectionList pr=Projections.projectionList();
			pr.add(ad);
			pr.add(ad1);
			b.setProjection(pr);
			List<Object[]> empidEmpType= b.list();
			int idEmp=(int) empidEmpType.get(0)[0];
			int idEmpType=(int) empidEmpType.get(0)[1];

		Criteria dc=session.createCriteria(Attendance.class);
		dc.add(Restrictions.eq("idEmployees", idEmp));
		dc.add(Restrictions.ge("date", fd));
		dc.add(Restrictions.lt("date", ld));
		Projection p=Projections.rowCount();
		dc.setProjection(p);
		long PresentDays=(long) dc.uniqueResult();
	
		
		Criteria cp=session.createCriteria(IncentAmount.class);
		cp.add(Restrictions.eq("idEmpType", idEmpType));
		Projection p1=Projections.property("condition1");
		Projection p2=Projections.property("amount");
		ProjectionList pl=Projections.projectionList();
		pl.add(p1);
		pl.add(p2);
		cp.setProjection(pl);
		List<Object[]> hm=cp.list();
		
		ArrayList<Long> prescons = new ArrayList<Long>();
		
		long Con=0;
		float Dayinc=0;
		
		HashMap<String,String> insanAmount = new HashMap<String,String>();
		
		int x=0;
		if(!hm.isEmpty())
		{
			int condition = (int) hm.get(0)[0];
			prescons.add((long) condition);			
			insanAmount.put(String.valueOf(condition), String.valueOf(hm.get(0)[1]));
			x++;
		
		Collections.sort(prescons);
		for(int i = 0;i < prescons.size();i++ ) 
		{
			if(PresentDays>= prescons.get(i))
			{
				Con = prescons.get(i);
				Dayinc = Float.parseFloat(insanAmount.get(String.valueOf(Con)));
			}
			
		}
		}
		float totalinc=PresentDays*Dayinc;
		
	session.close();
		return totalinc;
	}
	public float Allownce(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		int enterdmonth =month-1;
		
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        String fd1 =new SimpleDateFormat("yyyy/MM/dd").format(calendar.getTime());
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        Date fd=null;

        try {
			fd=format.parse(fd1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        String ld1 = new SimpleDateFormat("YYYY/MM/dd").format(calendar.getTime());
        Date ld=null;
		try {
			 ld=format.parse(ld1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		List<Object[]> hm = new ArrayList<Object[]>();
		
		Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		b.setProjection(ad);
		int idEmp=(int) b.uniqueResult();
		
		Criteria as=session.createCriteria(Attendance.class);
		as.add(Restrictions.eq("idEmployees", idEmp));
		as.add(Restrictions.ge("date", fd));
		as.add(Restrictions.lt("date", ld));
		as.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		Projection ps=Projections.property("idShift");
		Projection ps1=Projections.rowCount();
		ProjectionList pl=Projections.projectionList();
		pl.add(ps);
		pl.add(ps1);
		as.setProjection(pl);
		hm=as.list();
	
		int idShifts=0;
		
	float totalAllownce=0.0f;
		for(Object[] row : hm) 
		{
			int PresntdayShift = 0;
			float Allownce=0.0f;
			try {
			idShifts = Integer.parseInt(String.valueOf( row[0]));
		
			PresntdayShift = Integer.parseInt(String.valueOf( row[1]));
			
			Shift s = (Shift) session.createCriteria(Shift.class).add( Restrictions.like("idShift", idShifts) ).uniqueResult();		
			
			Allownce=s.getAllownce();
			}
			catch(Exception e)
			{
				
			}
			Allownce=Allownce*PresntdayShift;
			totalAllownce+=Allownce;
		}
session.close();
		return totalAllownce ;
	}
	public float PresentDays(String empcode,int month,int year) 
	{
		Session session = (Session) hipernateConfg.getSession();  

		int enterdmonth =month-1;
	
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        String fd1 =new SimpleDateFormat("yyyy/MM/dd").format(calendar.getTime());
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        Date fd=null;
    	
		
        try {
			fd=format.parse(fd1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        String ld1 = new SimpleDateFormat("yyyy/MM/dd").format(calendar.getTime());
        Date ld=null;
   System.err.println(fd1+"\n "+ld1);
		try {
			 ld=format.parse(ld1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		b.setProjection(ad);
		int idEmp=(int) b.uniqueResult();
		
		Criteria as=session.createCriteria(Attendance.class);
		as.add(Restrictions.eq("idEmployees", idEmp));
		as.add(Restrictions.ge("date", fd));
		as.add(Restrictions.lt("date", ld));
		Projection ps1=Projections.rowCount();
	
		as.setProjection(ps1);
		long PresentDays=(long)as.uniqueResult();
	
		float LeavHR=0.0f;
		float ovrhours=0.0f;
		
	try {
		


		Criteria ab=session.createCriteria(Hoursleave.class);
		ab.add(Restrictions.eq("idEmployees", idEmp));
		ab.add(Restrictions.ge("date", fd1));
		ab.add(Restrictions.lt("date", ld1));
		Projection pb=Projections.sum("hours");
		ab.setProjection(pb);
		
		LeavHR=(float) ab.uniqueResult();
		
		Criteria sd=session.createCriteria(Overtime.class);
		sd.add(Restrictions.eq("idEmployees", idEmp));
		sd.add(Restrictions.ge("date", fd1));
		sd.add(Restrictions.lt("date", ld1));
		Projection p=Projections.sum("hours");
		sd.setProjection(p);
		ovrhours=(float) sd.uniqueResult();
	
		}
		catch(Exception  ex)
		{
			LeavHR=0.0f;
			ovrhours=0.0f;
		}
		float ovrtimeDays=ovrhours/8;
		float LeavDays=LeavHR/8;
		float totalWorkingDays=PresentDays+ovrtimeDays-LeavDays;
		session.close();
		return totalWorkingDays;
	}
	public Map DesigID_PresntDay(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month-1;
		
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        String fd1 =new SimpleDateFormat("yyyy/MM/dd").format(calendar.getTime());
        DateFormat format = new SimpleDateFormat("yyyy/MM/dd");
        Date fd=null;

        try {
			fd=format.parse(fd1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        String ld1 = new SimpleDateFormat("YYYY/MM/dd").format(calendar.getTime());
        Date ld=null;
		try {
			 ld=format.parse(ld1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
     
	List<Object[]> hm1=new ArrayList<Object[]>();
		Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		b.setProjection(ad);
		int idEmp=(int) b.uniqueResult();
		
		Criteria cr=session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", idEmp));
		cr.add(Restrictions.ge("date", fd)); 
		cr.add(Restrictions.lt("date", ld));
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		Projection pr=Projections.property("idDesignation");
		Projection pr1=Projections.rowCount();
		
		ProjectionList pl=Projections.projectionList();
		pl.add(pr);
		pl.add(pr1);
		cr.setProjection(pl);
		hm1=cr.list();
		
		int idDesignation=0;
		int presentDays=0;
		
		Map<String, Object> Design_presDAY = new HashMap<String, Object>();
		if(hm1.isEmpty()) 
		{
		for(Object[] row : hm1)
		{
			idDesignation = (int) row[0];
			presentDays = Integer.parseInt(String.valueOf( row[1]));
		
			Design_presDAY.put("Presentdays", presentDays);
			Design_presDAY.put("Designation", idDesignation);
			
		}
		}
		session.close();
		return Design_presDAY;
	}
	
	public Map info(String Empcode)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Map info1 =new HashMap();
		Criteria cr=session.createCriteria(Employees.class);
		cr.add(Restrictions.eq("employeeCode", Empcode));
		Projection p=Projections.property("idEmployees");
		Projection p1=Projections.property("emp_First_Name");
		Projection p2=Projections.property("emp_Middle_Name");
		Projection p3=Projections.property("emp_Last_Name");
		ProjectionList pl=Projections.projectionList();
		pl.add(p);
		pl.add(p1);
		pl.add(p2);
		pl.add(p3);
		cr.setProjection(pl);
		List<Object[]> info=cr.list();
		if(info.size()>0) {
System.err.println("idemp"+info.get(0)[0]);
System.err.println(info.get(0)[1]+" "+(String) info.get(0)[2]+" "+(String) info.get(0)[3]);
		int  IdEmp=(int) info.get(0)[0];
		String Name=(String) info.get(0)[1]+" "+(String) info.get(0)[2]+" "+(String) info.get(0)[3];
		info1.put("idEmployee", IdEmp);
		info1.put("EmployeeName", Name);
		session.close();
		}
		return info1;
	}
	
	public List Empid()
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		List<Map<String,Object>> idEmployees=new ArrayList<Map<String,Object>>();
	
		Criteria cr=session.createCriteria(Employees.class);
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		Projection pr=Projections.property("idEmployees");
		cr.setProjection(pr);
		idEmployees=cr.list();
		
		session.close();
		return idEmployees;
	}

	public float DesignationSal1(String empcode,Date dt) 
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		Calendar calendar = Calendar.getInstance();  
        calendar.setTime(dt);
        Date fd = calendar.getTime();
		List<Object[]> hm1 = new ArrayList<Object[]>();
		
		Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		b.setProjection(ad);
		int idEmp=(int) b.uniqueResult();
		
		Criteria c=session.createCriteria(Attendance.class);
		c.add(Restrictions.eq("idEmployees", idEmp));
		c.add(Restrictions.ge("date", fd));
		Projection p=Projections.property("idDesignation");
		c.setProjection(p);
		int idDesignation=(int) c.uniqueResult();

		Criteria cp=session.createCriteria(Designation.class);
		cp.add(Restrictions.eq("idDesignation", idDesignation));
		Projection a=Projections.property("salary");
		cp.setProjection(a);
		float salary=(float) cp.uniqueResult();
		
		
		
		session.close();
		return salary;
	}
	
	
	public float PerDaySal1(String empcode, Date dt)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		
		Calendar calendar = Calendar.getInstance();  
        calendar.setTime(dt); 
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        
        Criteria cp=session.createCriteria(Employees.class);
		cp.add(Restrictions.eq("employeeCode", empcode));
		Projection a=Projections.property("salary");
		cp.setProjection(a);
		float salforday=(float) cp.uniqueResult();
 
		session.close();
		return salforday;
	}

	public float MonthlySal1(String empcode, Date dt) 
	{	
		Session session = (Session) hipernateConfg.getSession();
		Calendar calendar = Calendar.getInstance();
        calendar.setTime(dt);
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		  Criteria cp=session.createCriteria(Employees.class);
			cp.add(Restrictions.eq("employeeCode", empcode));
			Projection a=Projections.property("salary");
			cp.setProjection(a);
			float salforMonth=(float) cp.uniqueResult();
		
		float Salaryperday=salforMonth/daysInMonth;
		session.close();
		return Salaryperday;
	}
	
	public Map paidLeaveSal1(String empcode, Date dt)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		System.err.println("usedate"+dt);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dt);
		System.err.println("calendar time"+calendar.getTime());
		int year=calendar.get(Calendar.YEAR);
		int month=calendar.get(Calendar.MONTH);
		System.err.println("month is"+month+"year is "+year);
	    int lastDate = calendar.getActualMaximum(Calendar.DATE);
        calendar.set(year, month, 1);
        Date fd = calendar.getTime();
        calendar.set(year, month, lastDate);
        Date ld = calendar.getTime();
        Map paidlvs=new HashMap();
        Criteria b=session.createCriteria(Employees.class);
		b.add(Restrictions.eq("employeeCode", empcode));
		Projection ad=Projections.property("idEmployees");
		b.setProjection(ad);
		int idEmp=(int) b.uniqueResult();
		Criteria cr=session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", idEmp));
		cr.add(Restrictions.ge("date", fd)); 
		cr.add(Restrictions.lt("date", ld));
		cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		Projection pr=Projections.property("idDesignation");
		cr.setProjection(pr);
		int iddes=(int) cr.uniqueResult();
		
		Criteria c=session.createCriteria(Designation.class);
		c.add(Restrictions.eq("idDesignation", iddes));
		Projection p=Projections.max("salary");
		c.setProjection(p);
		float salary=(float) c.uniqueResult();
		

		int idLeave=0;
		int isPaid=0;
		
		
		

		Criteria d=session.createCriteria(Empleave.class);
		d.add(Restrictions.eq("idEmployees", idEmp));
		Projection fdg=Projections.property("idLeave");
		d.setProjection(fdg);
		idLeave=(int) d.uniqueResult();
		
		Criteria s=session.createCriteria(TblLeave.class);
		s.add(Restrictions.eq("idLeave", idLeave));
		Projection f=Projections.property("isPaid");
		s.setProjection(f);
		isPaid=(int)s.uniqueResult();
		
				
		float totalPaidLeaveSal = isPaid * salary;
		paidlvs.put("isPaid", isPaid);
		paidlvs.put("totalPaidLeaveSal", totalPaidLeaveSal);
		session.close();
		return paidlvs;
		
	}
	
}
