package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.SocietyManager;
import com.example.PayRoll.POJO.Society;

@Controller
@RequestMapping("society")

public class SocietyController {
	

		
		@Autowired
		SocietyManager societyManager;
		
		@RequestMapping("/save")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Society save(@RequestParam("id")int id,@RequestParam("emptype")String emptype,@RequestParam("amount")float amount)
		{
			//idSociety, idEmpType, Amount
			
			return societyManager.save(id,emptype,amount); 
		}
		
		@RequestMapping("/getall")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Object get()
		{
			
				return societyManager.get(); 
		
			
		}
		
		@RequestMapping("/delete")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Object delete(@RequestParam("id")int id)
		{
			
				return societyManager.delete(id); 
		
			
		}
		
	
}
