package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.ESIManager;
import com.example.PayRoll.Manager.TDSManager;
import com.example.PayRoll.POJO.ESI;
import com.example.PayRoll.POJO.TDS;



	@Controller
	@RequestMapping("TDS")
	
	public class TDSController
	{
		
		@Autowired
		TDSManager tdsManager;
		
		@RequestMapping("/save")
		@PostMapping
		@ResponseBody
		public String save(TDS t)
		{
			
			return tdsManager.save(t); 
		}
		
		
		@RequestMapping("/get")
		@PostMapping
		@ResponseBody
		public Object get(@RequestParam("id")String id)
		{
			
				return tdsManager.get(id); 
			
		}
	
}
