package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.DeductionSettingDAO;
import com.example.PayRoll.POJO.DeductionSetting;
@Component
@Controller
public class DeductionSettingManager {

	@Autowired
	DeductionSettingDAO DSDAO;
	public DeductionSetting save(int idded,int con,float mincon,float maxcon,String dedtype,String ded,float amount) {
		
		return DSDAO.save(idded,con,mincon,maxcon,dedtype,ded,amount);
	}
	public List get(String con) {
		// TODO Auto-generated method stub
		return DSDAO.get(con);
	}
	public List getall() {
		// TODO Auto-generated method stub
		return DSDAO.getall();
	}
	public Object delete(int id) {
		// TODO Auto-generated method stub
		return DSDAO.delete(id);
	}

}
