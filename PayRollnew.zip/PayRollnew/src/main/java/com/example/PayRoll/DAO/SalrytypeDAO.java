package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.Salary;
import com.example.PayRoll.POJO.Salarytype;

@Component
@Controller
public class SalrytypeDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	
	
	public Salarytype save(Salarytype st) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		session.saveOrUpdate(st);
		t.commit();  
		session.close();
		
		return st;
	}

	public Salarytype get(String Salarytype)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		Salarytype e1=new Salarytype();
		e1 = (Salarytype)session.get(Salarytype.class,Salarytype);
		t.commit();
		session.close(); 
		
		return e1;
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession(); 
		Criteria cr=session.createCriteria(Salarytype.class);
		
		return cr.list();
	}

}
