package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.example.PayRoll.Manager.IncentiveManager;
import com.example.PayRoll.POJO.IncentAmount;
import com.example.PayRoll.POJO.Incentive;
@Component
@Controller
@RequestMapping("/Incentive")
public class IncentiveController 
{
	@Autowired
	IncentiveManager incman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Incentive get(@RequestParam("name")String name)
	{
		return incman.get(name);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/getall")
	public List getall()
	{
		return incman.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Incentive save(Incentive inc)
	{
		  return incman.save(inc);
	}
}
