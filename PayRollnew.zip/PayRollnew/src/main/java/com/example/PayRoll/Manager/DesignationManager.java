package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.DesignationDAO;
import com.example.PayRoll.POJO.Designation;
@Component
@Controller
public class DesignationManager 
{	@Autowired
	DesignationDAO desigdao;

	public Designation save(int iddes,String name,String sft,String deptName,String CatName,float sal) 
	{	
		return desigdao.save(iddes,name,sft,deptName,CatName,sal);
	}
	public Object get(String Shortform ) 
	{	
		return desigdao.get(Shortform);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return desigdao.getall();
	}
	public Object delete(String name) {
		// TODO Auto-generated method stub
		return desigdao.delete(name);
	}
}
