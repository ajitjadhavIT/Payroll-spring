package com.example.PayRoll.DAO;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;


import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.ShiftAllownce;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.Welfare;
@Controller
@Component

public class WelfareDAO {
	
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmptypeDAO emptypedao;
	
	 public Welfare save(int id,String emptype,int month,float amount) {
		
		 Session session = (Session) hipernateConfg.getSession(); 
			Transaction t = session.beginTransaction();  
			int idemptype=emptypedao.get(emptype).getIdEmpType();
			
			Welfare wf=new Welfare();
			wf.setIdWelfare(id);
			wf.setIdEmpType(idemptype);
			wf.setMonth(month);
			wf.setAmount(amount);
		
			session.saveOrUpdate(wf);
			t.commit();  
			System.out.println("successfully saved");    
		
			session.close();
			return wf;
	   
	 }

	//public String save(String id,String empTypeid,String month,String amount) {
		
		
		
		/*int id1=0;
		String sql="Insert into welfare (idWelfare, idEmpType, Month, Amount) values (?,?,?,?)";
		jdbcTemplate.update(sql,id1,empTypeid,month,amount);
		
	*/
	//}

	public List get(String emptype) {
		 Session session = (Session) hipernateConfg.getSession();
		 int idemptype=emptypedao.get(emptype).getIdEmpType();
			Criteria cr=session.createCriteria(Welfare.class);
			cr.add(Restrictions.eq("idEmpType", idemptype));
	
		return cr.list();
	}

	public List getall() 
	{
		Session session = (Session) hipernateConfg.getSession();
		Criteria cr=session.createCriteria(Welfare.class);
		return cr.list();
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Welfare d = (Welfare ) session.createCriteria(Welfare.class)
                 .add(Restrictions.eq("idWelfare", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}


