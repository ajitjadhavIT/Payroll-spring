package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.EmployeeSalaryDAO;
@Controller
@Component

public class EmployeeSalaryManager {

	@Autowired
	EmployeeSalaryDAO empsalDAO;
	public List empsal(String empcode, int month, int year) {
		return empsalDAO.EmpSal(empcode, month, year);
	}

}
