package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.ContractorDAO;
import com.example.PayRoll.POJO.Contractor;
@Component
@Controller
public class ContractorManager {

	@Autowired
	ContractorDAO cDAO;
	
	public Contractor save(int id,String name,String addr,int contact,String email) {
		// TODO Auto-generated method stub
		return cDAO.save(id,name,addr,contact,email);
	}

	public List get(String name)
	{
		return cDAO.get(name);
	}

	public Object getall() {
		// TODO Auto-generated method stub
		return cDAO.getall();
	}

	public List delete(int id) {
		// TODO Auto-generated method stub
		return cDAO.delete(id);
	}
	
}
