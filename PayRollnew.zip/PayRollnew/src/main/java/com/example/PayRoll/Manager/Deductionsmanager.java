package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.DeductionsDAO;
import com.example.PayRoll.POJO.Deductions;
@Controller
@Component
public class Deductionsmanager {

	@Autowired
	DeductionsDAO dtDAO;
	
	public Deductions save(int id,String name) {
		// TODO Auto-generated method stub
		return dtDAO.save(id,name);
	}

	public Object getall() {
		// TODO Auto-generated method stub
		return dtDAO.getAll();
	}

	public Object delete(String name) {
		// TODO Auto-generated method stub
		return dtDAO.delete(name);
	}

}
