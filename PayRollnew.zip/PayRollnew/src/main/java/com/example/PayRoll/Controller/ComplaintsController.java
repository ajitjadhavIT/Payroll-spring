package com.example.PayRoll.Controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.ComplaintsDAO;
import com.example.PayRoll.POJO.Complaints;

@Controller
@RequestMapping("/complaints")
public class ComplaintsController {

	@Autowired
	ComplaintsDAO cDAO;
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	//idComplaints, idEmployees, date, reason, complaintBy
	public Object save(@RequestParam("idcom")int idcom,@RequestParam("empcode")String empcode,@RequestParam("date")Date date,@RequestParam("reason")String reason,@RequestParam("complaintby")String complaintby)
	
	{
		return cDAO.save(idcom,empcode,date,reason,complaintby);
	}
	
	
	@RequestMapping("/get")
	@PostMapping
	@ResponseBody
	public Object get(@RequestParam("empcode")String empcode)
	{
		return cDAO.get(empcode);
	}
	@RequestMapping("/getall")
	@PostMapping
	@ResponseBody
	public Object getall()
	{
		return cDAO.getall();
	}
}
