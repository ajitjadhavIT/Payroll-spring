package com.example.PayRoll.POJO;

import java.sql.Time;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="latededuction")
public class LateDeduction {

	@Id
	int idLateDeduction;
	Time time;
	float days;
	float deductDays;
	int idShift;
	int idEmpType;
	public int getIdLateDeduction() {
		return idLateDeduction;
	}
	public void setIdLateDeduction(int idLateDeduction) {
		this.idLateDeduction = idLateDeduction;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	public float getDays() {
		return days;
	}
	public void setDays(float days) {
		this.days = days;
	}
	public float getDeductDays() {
		return deductDays;
	}
	public void setDeductDays(float deductDays) {
		this.deductDays = deductDays;
	}
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	
}
