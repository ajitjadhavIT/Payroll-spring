package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.Welfare;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.Society;

@Controller
@Component
public class SocietyDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmptypeDAO emptypedao;
	
	public Society save(int id,String emptype,float amount)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();

		int idemptype=emptypedao.get(emptype).getIdEmpType();
		Society s=new Society();
	
		s.setIdSociety(id);
		s.setAmount(amount);
		s.setIdEmpType(idemptype);
		session.saveOrUpdate(s);
		t.commit();  
		session.close();
		
		return s;
		
	}
	public List get() {
		Session session = (Session) hipernateConfg.getSession();  
		Criteria cr=session.createCriteria(Society.class);
		
		return cr.list();
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Society d = (Society ) session.createCriteria(Society.class)
                 .add(Restrictions.eq("idSociety", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
