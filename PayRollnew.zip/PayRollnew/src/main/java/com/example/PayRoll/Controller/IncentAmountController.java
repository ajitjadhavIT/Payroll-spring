package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.IncentAmountManager;
import com.example.PayRoll.POJO.IncentAmount;
@Component
@Controller
@RequestMapping("/IncentiveAmount")
public class IncentAmountController
{
	@Autowired
	IncentAmountManager incamttman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("empcode")String empcode)
	{
		return incamttman.get(empcode);
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/delete")
	public Object delete(@RequestParam("idIncentiveAmount")int id)
	{
		return incamttman.delete(id); 
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public Object getall()
	{
		return incamttman.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")
	public IncentAmount save(@RequestParam("idIncamount")int idinca,@RequestParam("Incentive")String inc,
			@RequestParam("Condition")int con,@RequestParam("Amount")float amount,@RequestParam("emptype")String emptype)
	{	
		 return incamttman.save(idinca,inc,con,amount,emptype); 
	}
}
