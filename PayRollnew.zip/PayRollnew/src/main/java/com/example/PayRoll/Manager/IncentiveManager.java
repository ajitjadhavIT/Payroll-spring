package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.IncentiveDAO;
import com.example.PayRoll.POJO.Incentive;
@Component
@Controller
public class IncentiveManager
{
	@Autowired
	IncentiveDAO incdao;
	public Incentive save(Incentive ic) {
		// TODO Auto-generated method stub
		return incdao.save(ic);
	}
	public Incentive get(String name) {
		// TODO Auto-generated method stub
		return incdao.get(name);
	}
	public List getall() {
		// TODO Auto-generated method stub
		return incdao.getall();
	}

}
