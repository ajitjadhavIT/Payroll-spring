package com.example.PayRoll.Controller;

import java.text.ParseException;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.EmployeeDAO;
import com.example.PayRoll.Manager.BankdetailsManager;
import com.example.PayRoll.Manager.EmpWorkDetailsManager;
import com.example.PayRoll.Manager.EmployeeManager;
import com.example.PayRoll.POJO.Employees;
@Component
@Controller
@RequestMapping("/Employee")
public class EmployeeController 
{
	@Autowired
	EmployeeManager empman;
	
	@Autowired
	EmployeeDAO empdao;
	
	@Autowired
	EmpWorkDetailsManager empwdtman;
	
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/get")
	public Employees get(@RequestParam("Empcode")String empcode)
	{
		return empman.getemp(empcode);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/getall")
	public Object getall()
	{
		return empman.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")
	public Object save(@RequestParam("EmployeeCode")String empcode,
			@RequestParam("idemp")int idemp,
			@RequestParam("idbank")int idbank,
			@RequestParam("idwork")int idwork,
			@RequestParam("Emp_First_Name")String efn,@RequestParam("Emp_Middle_Name")String emn,
			@RequestParam("Emp_Last_Name")String eln,@RequestParam("Gender")String gender,
			@RequestParam("EmpType")String empt,@RequestParam("DOB")String dob,
			@RequestParam("Blood_Group")String bg,@RequestParam("Marriatal_Status")String mts,
			@RequestParam("Address")String ads,@RequestParam("Nominee")String nomi,
			@RequestParam("Nominee_Relation")String nmr,@RequestParam("Religion")String rel,
			@RequestParam("Cast")String cast,@RequestParam("Qualification")String qul,
			@RequestParam("Contact_No")long con,@RequestParam("Email_ID")String email,
			@RequestParam("Weekly_Off")String wf,@RequestParam("Society")int society,
			@RequestParam("SalaryType")String saltype,@RequestParam("Salary")float salary,
			@RequestParam("Designation")String desname,@RequestParam("Shiftname")String shiftname,
			@RequestParam("Work_Area")String wrkarea,@RequestParam("Joining_Date")String jdate,
			@RequestParam("Bank_Name")String bankname,@RequestParam("Account_Number")String accno,
			@RequestParam("Branch")String branch,@RequestParam("Account_type")String acctype,
			@RequestParam("IFSC_Code")String ifsccode,@RequestParam("PF_NO")String pfno) throws ParseException
	{/*idEmployees, EmployeeCode, Emp_First_Name, Emp_Middle_Name, Emp_Last_Name, Gender, 
		idEmpType, DOB, Blood_Group, Marriatal_Status, Address, Nominee, Nominee_Relation,
		Religion, Cast, Qualification, Contact_No, Email_ID, Weekly_Off, Society*/
		 
		System.err.println(idemp+"\n"+idbank+"\n"+idwork);
		
		
			System.err.println("salary type="+saltype);
		return empman.saveEmployees(idemp,idbank,idwork,empcode, efn, emn, eln, gender, empt, dob, bg, mts, ads, nomi,
				nmr, rel, cast, qul, con, email, wf, society, saltype,salary,desname, shiftname, wrkarea, jdate, 
				bankname, accno, branch, acctype, ifsccode, pfno);
		
	}
	
	
	
	@ResponseBody
	@GetMapping
	@RequestMapping("/employees_data")
	public List employees()
	{
		
		return empdao.employees();
		
	}
			
	@ResponseBody
	@GetMapping
	@CrossOrigin()
	@RequestMapping("/delete")
	public List delete(@RequestParam("empcode")String empcode)
	{
		
		return empdao.delete(empcode);
		
	}
	@Autowired
	BankdetailsManager bnkman;
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getbank")
	public Object getbank(@RequestParam("Empcode")String empcode)
	{
		return bnkman.get(empcode);
	}
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getwork")
	public Object getwork(@RequestParam("Empcode")String empcode)
	{
		return empwdtman.get(empcode);
	}
}
