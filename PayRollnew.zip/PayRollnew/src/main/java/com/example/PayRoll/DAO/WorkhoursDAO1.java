package com.example.PayRoll.DAO;



import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.LateDeduction;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.Workhours;
@Component
public class WorkhoursDAO1 {
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmployeeDAO EmployeeDAO;
	@Autowired
	BasicSalaryDAO bsDAO;
	@Autowired
	OvertimeDAO oDAO;
	public Workhours save(Workhours a)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		session.save(a);
		t.commit();  
		session.close();
		return a;
	}
	
	public Object PresentDaybyHR(String empcode,int month,int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		
		int enterdmonth =month-1;
		
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd1 = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		
		System.err.println(fd1+"\n "+ld1);
		Employees emp= (Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		
		List<Object[]> idAttendance =new ArrayList<Object[]>();
	
		Criteria cr=session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", id));
		cr.add(Restrictions.ge("date", fd1));
		cr.add(Restrictions.lt("date", ld1));
		Projection p=Projections.property("idAttendance");
		Projection p1=Projections.property("idShift");
		Projection p2=Projections.property("idDesignation");
		Projection p3=Projections.property("date");

		ProjectionList pl=Projections.projectionList();
		pl.add(p);
		pl.add(p1);
		pl.add(p2);
		pl.add(p3);
		cr.setProjection(pl);
		idAttendance=cr.list();
		
		Criteria cb=session.createCriteria(Employees.class);
		cb.add(Restrictions.eq("employeeCode", empcode));
		Projection pr=Projections.property("idEmpType");
		cb.setProjection(pr);
		int idEmptype=(int) cb.uniqueResult();
		
		Criteria b=session.createCriteria(EmpWorkDetails.class);
		b.add(Restrictions.eq("idEmployees", id));
		Projection r=Projections.property("hours");
		b.setProjection(r);
		
		float hours=(float) b.uniqueResult();

		session.close();
		float Totalhours=0;
		int count=0;
		float PresentDays=0.0f;
		float finlpresentDAYS=0.0f;
		for(Object[] row:idAttendance)
		{
			Session session1 = (Session) hipernateConfg.getSession();  
			Transaction t = session1.beginTransaction();
			int idAttn = (int) row[0];
			int idShift=(int) row[1];
			int idDesignation=(int) row[2];
			Date date=(java.util.Date) row[3];

			List<Object[]> conditions=new ArrayList<Object[]>();
			Criteria sd=session1.createCriteria(LateDeduction.class);
			sd.add(Restrictions.eq("idShift", idShift));
			sd.add(Restrictions.eq("idEmpType", idEmptype));
			Projection ps=Projections.property("days");
			Projection ps1=Projections.property("deductDays");
			Projection ps2=Projections.property("time");
			ProjectionList pm=Projections.projectionList();
			pm.add(ps);
			pm.add(ps1);
			pm.add(ps2);
			sd.setProjection(pm);
			conditions=sd.list();
			
			float Days=(float) conditions.get(0)[0];
			float deductDays=(float) conditions.get(0)[1];
			Time time=(Time) conditions.get(0)[2];
		//	Date conditionTime = (Date)(time);
			 String contime=String.valueOf(time);
			 String[] hourMin = contime.split(":");
			    int hour = Integer.parseInt(hourMin[0]);
			    int mins = Integer.parseInt(hourMin[1]);
			    int hoursInMins = hour * 60;
			    int totalconMinutes=hoursInMins + mins;
			Time ShiftStrttime=null;
			Time ShiftEndtime=null;
			
			Criteria ca=session1.createCriteria(Shift.class);
			ca.add(Restrictions.eq("idShift", idShift));
			Projection j=Projections.property("startTime");
			Projection j1=Projections.property("endTime");
			ProjectionList rs=Projections.projectionList();
			rs.add(j);
			rs.add(j1);
			ca.setProjection(rs);
			List<Object[]> Shifttime= ca.list();

			ShiftStrttime=(Time) Shifttime.get(0)[0];
			ShiftEndtime=(Time) Shifttime.get(0)[1];
			
			Time usrintime=null;
			Time usrouttime=null;

			Criteria v=session1.createCriteria(Workhours.class);
			v.add(Restrictions.eq("idAttendance", idAttn));
			Projection pf=Projections.property("inTime");
			Projection pn=Projections.property("outTime");
			ProjectionList pt=Projections.projectionList();
			pt.add(pf);
			pt.add(pn);
			v.setProjection(pt);
			List<Object[]> m= v.list();
		
			 usrintime=(Time) m.get(0)[0];
			 usrouttime=(Time) m.get(0)[1];
	
			SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
		
			Date userdate1 = (Date)(usrintime);
			Date userdate2 = (Date)(usrouttime);
			float difference = userdate2.getTime() - userdate1.getTime(); 
			float diffMinutes = difference / (60 * 1000); 
			float timeinHR=difference / (60 * 60 * 1000) % 24;
			System.err.println("timeinHR"+timeinHR);
			
			Criteria ct=session1.createCriteria(Overtime.class);
			ct.add(Restrictions.eq("date", date));
			ct.add(Restrictions.eq("idEmployees", id));
			Projection fd=Projections.rowCount();
			ct.setProjection(fd);
			long countidovr=(long)ct.uniqueResult();
		System.err.println("time in hr"+timeinHR+" \n hours"+hours);
			
			if(timeinHR>hours && countidovr==0)
			{
				float ovrHR=timeinHR-hours;
				System.err.println(ovrHR);
				Overtime ovr=new Overtime();
				ovr.setDate(date);
				ovr.setIdShift(idShift);
				ovr.setIdDesignation(idDesignation);
				ovr.setIdEmployees(id);
				ovr.setHours(ovrHR);
			
				session1.save(ovr);
				t.commit();
				
			}
			else if(countidovr>0)
			{
				
				
				Criteria ct1=session1.createCriteria(Overtime.class);
				ct1.add(Restrictions.eq("date", date));
				ct1.add(Restrictions.eq("idEmployees", id));
				Projection f1=Projections.property("idOvertime");
				
				ct1.setProjection(f1);
				int idOvertime=(int) ct1.uniqueResult();
				
				float ovrHR=timeinHR-hours;
				System.err.println(ovrHR);
				Overtime ovr=new Overtime();
				ovr.setIdOvertime(idOvertime);
				ovr.setDate(date);
				ovr.setIdShift(idShift);
				ovr.setIdDesignation(idDesignation);
				ovr.setIdEmployees(id);
				System.err.println(ovrHR);
				ovr.setHours(ovrHR);
				session1.update(ovr);
			
			}
			Totalhours=Totalhours+timeinHR;
			
			Date ShiftDate1 = (Date)(ShiftStrttime);
			float difference1 = userdate1.getTime() - ShiftDate1.getTime(); //
			float diffMinutes1 = difference1 / (60 * 1000); 
		
			float Presentdays=bsDAO.PresentDays(empcode, month, year);
			System.err.println("presentdays "+Presentdays);
			if(diffMinutes1 >= totalconMinutes)
			{
				
				count++;
				if(count >= Days)
				{
					Presentdays=(float) (Presentdays-deductDays);
					count=0;
					
					
				}
			}
			
		

			finlpresentDAYS=Presentdays;
			
			
		}
	
		
		return finlpresentDAYS;
	}
	
	
	
	public Object PresentDaybyHRbyDate(String empcode,Date dt)
	{
		Session session = (Session) hipernateConfg.getSession();  

		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.setTime(dt);  
       
        Date fd1 = calendar.getTime();
      System.err.println(fd1);
		Employees emp= (Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		
		int idAttendance =0;
		try {
		Criteria cr=session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", id));
		cr.add(Restrictions.eq("date", fd1));

		Projection p=Projections.property("idAttendance");
		cr.setProjection(p);
		idAttendance=(int) cr.uniqueResult();
		
		Criteria bz=session.createCriteria(EmpWorkDetails.class);
		bz.add(Restrictions.eq("idEmployees", id));
		Projection r=Projections.property("hours");
		bz.setProjection(r);
		float hours=(float) bz.uniqueResult();
		float finlpresentDAYS=0.0f;
		}
		catch(Exception e)
		{
			
		}
		System.err.println("idAttendance +++++++++++++++++++++++"+idAttendance);
			Time usrintime=null;
			Time usrouttime=null;
			try {
				
			
			Criteria v=session.createCriteria(Workhours.class);
			v.add(Restrictions.eq("idAttendance", idAttendance));
			Projection pf=Projections.property("inTime");
			Projection pn=Projections.property("outTime");
			ProjectionList pt=Projections.projectionList();
			pt.add(pf);
			pt.add(pn);
			v.setProjection(pt);
			List<Object[]> m= v.list();
			
			usrintime=(Time) m.get(0)[0];
			usrouttime=(Time) m.get(0)[1];
			}
			catch(IndexOutOfBoundsException e)
			{
				
			}
			Date userdate1 = (Date)(usrintime);
			Date userdate2 = (Date)(usrouttime);
			float timeinHR=0.0f;
			try {
				
			
			float difference = userdate2.getTime() - userdate1.getTime (); 
			float diffMinutes = difference / (60 * 1000); 
			 timeinHR=difference / (60 * 60 * 1000) % 24;
			System.err.println("timeinHR"+timeinHR);
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		session.close();
		return timeinHR;
	}
	
	
	
}
