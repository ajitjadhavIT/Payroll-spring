package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="deductiontype")
public class DeductionType {

	@Id
	int idDeductionType;
	String type;
	public int getIdDeductionType() {
		return idDeductionType;
	}
	public void setIdDeductionType(int idDeductionType) {
		this.idDeductionType = idDeductionType;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
}
