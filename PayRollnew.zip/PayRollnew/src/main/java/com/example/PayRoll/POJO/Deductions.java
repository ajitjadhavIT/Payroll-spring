package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="deductions")
public class Deductions {

	@Id
	int idDeductions;
	String name;
	public int getIdDeductions() {
		return idDeductions;
	}
	public void setIdDeductions(int idDeductions) {
		this.idDeductions = idDeductions;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
}
