package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salarydeduction")
public class SalaryDeduction {

	@Id
int	idSalaryDeduction;
int idSalary;
String deductionType;
float deductionAmount;
public int getIdSalaryDeduction() {
	return idSalaryDeduction;
}
public void setIdSalaryDeduction(int idSalaryDeduction) {
	this.idSalaryDeduction = idSalaryDeduction;
}
public int getIdSalary() {
	return idSalary;
}
public void setIdSalary(int idSalary) {
	this.idSalary = idSalary;
}
public String getDeductionType() {
	return deductionType;
}
public void setDeductionType(String deductionType) {
	this.deductionType = deductionType;
}
public float getDeductionAmount() {
	return deductionAmount;
}
public void setDeductionAmount(float deductionAmount) {
	this.deductionAmount = deductionAmount;
}
@Override
public String toString() {
	return "SalaryDeduction [idSalaryDeduction=" + idSalaryDeduction + ", idSalary=" + idSalary + ", deductionType="
			+ deductionType + ", deductionAmount=" + deductionAmount + "]";
}



}
