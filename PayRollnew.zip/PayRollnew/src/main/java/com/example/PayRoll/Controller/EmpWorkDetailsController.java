package com.example.PayRoll.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.EmpWorkDetailsDAO;
import com.example.PayRoll.Manager.EmpWorkDetailsManager;
import com.example.PayRoll.POJO.EmpWorkDetails;
@Component
@Controller
@RequestMapping("/EmpWorkDetails")
public class EmpWorkDetailsController
{
	@Autowired
	EmpWorkDetailsManager empwdtman;
	@Autowired
	EmpWorkDetailsDAO  empdao;
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("empcode")String empcode)
	{
		return empwdtman.get(empcode);
	}

	@ResponseBody
	@PostMapping("/Monthly_joining_Report")
	public Object Monthly_joining_Report(@RequestParam("Month")String Month,@RequestParam("year")String year) 
	{
		if(!Month.matches(patternInt))
		{
			return "Enter the Month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter the year";
		}
		else
		{
		return empdao.Monthly_joining_Report(Month, year);
		}
	}
	@ResponseBody
	@PostMapping("/yearly_joining_Report")
	public Object yearly_joining_Report(@RequestParam("year")String year) 
	{
		if(!year.matches(patternInt))
		{
			return "Enter the year";
		}
		else 
		{
		return empdao.yearly_joining_Report(year);
		}
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	public EmpWorkDetails save(@RequestParam("Empcode")String empcode,
			@RequestParam("idDesignation")int iddes,@RequestParam("idShift")int ids,
			@RequestParam("Work_Area")String wrkarea,@RequestParam("Joining_Date")Date jdate)
	{//idEmpWorkDetails, idEmployees, idDesignation, idShift, Work_Area, Joining_Date
		
		return empwdtman.save(empcode,iddes,ids,wrkarea,jdate);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/MusterRollon_Report")
	public List MusterRollon_Report()
	{
		return empdao.MusterRollon_Report();
	}
}
