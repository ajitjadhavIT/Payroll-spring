package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
@Component

public class DayPresent
{
	List<Object[]> experienced=new ArrayList<Object[]>();
	List<Object[]> trainee=new ArrayList<Object[]>();
	public List<Object[]> getexperienced() {
		return experienced;
	}
	public void setexperienced(List<Object[]> experienced) {
		experienced = experienced;
	}
	public List<Object[]> getTrainee() {
		return trainee;
	}
	public void setTrainee(List<Object[]> trainee) {
		this.trainee = trainee;
	}
	
	
}
