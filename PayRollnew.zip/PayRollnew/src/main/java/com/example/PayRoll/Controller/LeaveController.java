package com.example.PayRoll.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.LeaveManager;
import com.example.PayRoll.POJO.TblLeave;

@Component
@Controller
@RequestMapping("/Leave")
public class LeaveController 
{
	String patternInt="\\d+";
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	@Autowired
	LeaveManager leavman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public TblLeave get(@RequestParam("Name")String name)
	{
		return leavman.get(name);
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public List getall()
	{
		return leavman.getall();
	}
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	@RequestMapping("/save")
	public TblLeave save(@RequestParam("id")int id,@RequestParam("name")String name,@RequestParam("shortform")String sf,@RequestParam("ispaid")int ispaid, @RequestParam("limit")int limit)
	{	
		return leavman.save(id,name,sf,ispaid,limit);
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id")int id)
	{
		return leavman.delete(id); 
	}
}
