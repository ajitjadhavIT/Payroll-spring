package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="shiftallownce")
public class ShiftAllownce {
@Id
	int idShiftAllownce;
	int idShift;
	float allownce;
	int idEmpType;
	public int getIdShiftAllownce() {
		return idShiftAllownce;
	}
	public void setIdShiftAllownce(int idShiftAllownce) {
		this.idShiftAllownce = idShiftAllownce;
	}
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public float getAllownce() {
		return allownce;
	}
	public void setAllownce(float allownce) {
		this.allownce = allownce;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	@Override
	public String toString() {
		return "ShiftAllownce [idShiftAllownce=" + idShiftAllownce + ", idShift=" + idShift + ", allownce=" + allownce
				+ ", idEmpType=" + idEmpType + "]";
	}
	
	
	
}
