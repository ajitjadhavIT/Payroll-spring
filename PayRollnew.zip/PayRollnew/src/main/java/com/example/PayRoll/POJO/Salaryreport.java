package com.example.PayRoll.POJO;

import java.util.HashMap;
import java.util.Map;

public class Salaryreport {


	String EmpName;
	String empcode;
	float PresentDays;
	String Designation;
	float NetPay;
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getEmpcode() {
		return empcode;
	}
	public void setEmpcode(String empcode) {
		this.empcode = empcode;
	}
	public float getPresentDays() {
		return PresentDays;
	}
	public void setPresentDays(float presentDays) {
		PresentDays = presentDays;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public float getNetPay() {
		return NetPay;
	}
	public void setNetPay(float netPay) {
		NetPay = netPay;
	}
	@Override
	public String toString() {
		return "Salaryreport [EmpName=" + EmpName + ", empcode=" + empcode + ", PresentDays=" + PresentDays
				+ ", Designation=" + Designation + ", NetPay=" + NetPay + "]";
	}
	
	
}
