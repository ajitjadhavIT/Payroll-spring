package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="designation")
public class Designation 
{//idDesignation, name, short_Form, idDepartment, idCatagory, salary
	@Id
	int idDesignation;
	String name;
	String short_Form;
	int idDepartment;
	int idCatagory;
	float salary;
	public int getIdDesignation() {
		return idDesignation;
	}
	public void setIdDesignation(int idDesignation) {
		this.idDesignation = idDesignation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShort_Form() {
		return short_Form;
	}
	public void setShort_Form(String short_Form) {
		this.short_Form = short_Form;
	}
	public int getIdDepartment() {
		return idDepartment;
	}
	public void setIdDepartment(int idDepartment) {
		this.idDepartment = idDepartment;
	}
	public int getIdCatagory() {
		return idCatagory;
	}
	public void setIdCatagory(int idCatagory) {
		this.idCatagory = idCatagory;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	
}
