package com.example.PayRoll.DAO;

import java.util.List;
import java.util.regex.Pattern;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.DeductionType;
import com.example.PayRoll.POJO.Deductions;


@Controller
@Component
public class DeductionTypeDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	
	
	
	public DeductionType save(int id,String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
	
		DeductionType d=new DeductionType();
		d.setIdDeductionType(id);
		d.setType(name);
		session.saveOrUpdate(d);
		t.commit();
		session.close();
		return d;
		
		
	}
public List getall()
{
	Session session = (Session) hipernateConfg.getSession();  
	Criteria cr=session.createCriteria(DeductionType.class);
	
	return cr.list();
	
}

}
