package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Shift_report 
{
	List Present =new ArrayList();
	List Summary =new ArrayList();
	List total =new ArrayList();
	public List getPresent() {
		return Present;
	}
	public void setPresent(List present) {
		Present = present;
	}
	public List getSummary() {
		return Summary;
	}
	public void setSummary(List summary) {
		Summary = summary;
	}
	public List getTotal() {
		return total;
	}
	public void setTotal(List total) {
		this.total = total;
	}
	
}
