package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="hours_leave")

public class Hoursleave 
{//idhours_Leave, Date, idshift, idDesignation, hours
	@Id
	int idhours_Leave;
	Date date;
    int idshift;

    int idDesignation;
    int hours;
    int idEmployees;
	public int getIdhours_Leave() {
		return idhours_Leave;
	}
	public void setIdhours_Leave(int idhours_Leave) {
		this.idhours_Leave = idhours_Leave;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getIdshift() {
		return idshift;
	}
	public void setIdshift(int idshift) {
		this.idshift = idshift;
	}
	public int getIdDesignation() {
		return idDesignation;
	}
	public void setIdDesignation(int idDesignation) {
		this.idDesignation = idDesignation;
	}
	public int getHours() {
		return hours;
	}
	public void setHours(int hours) {
		this.hours = hours;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	@Override
	public String toString() {
		return "Hoursleave [idhours_Leave=" + idhours_Leave + ", date=" + date + ", idshift=" + idshift
				+ ", idDesignation=" + idDesignation + ", hours=" + hours + ", idEmployees=" + idEmployees + "]";
	}
    
    
    
    
	
}
