package com.example.PayRoll.Manager;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.holiday_DAO;
import com.example.PayRoll.POJO.Holiday;
@Component
@Controller
public class holiday_Manager
{
	@Autowired
	holiday_DAO holidao;

	public List get(int Month,int year)
	{
		
		return holidao.get(Month, year);
	}

	public Holiday save(int id,String dt,String desc,int year) throws ParseException
	{
		return holidao.save(id,dt,desc,year);
	}

}
