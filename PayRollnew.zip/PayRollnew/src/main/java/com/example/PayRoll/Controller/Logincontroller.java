package com.example.PayRoll.Controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.LoginDAO;


@Component
@Controller
@RequestMapping("/login")


public class Logincontroller {

	@Autowired
	LoginDAO logindao;
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/get")
	public Object login(@RequestParam("username")String username,@RequestParam("password")String password) throws Exception
	{
		return logindao.login(username,password);
	}
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/create")
	public Object createlogin(@RequestParam("id")int id,@RequestParam("username")String username,@RequestParam("password")String password,@RequestParam("empcode")String empcode) throws Exception
	{
		return logindao.createlogin(id,username,password,empcode);
	}
}
