package com.example.PayRoll.Manager;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.HoursleaveDAO;
import com.example.PayRoll.POJO.Hoursleave;
@Component
@Controller
public class HoursleaveManager
{
	@Autowired
	HoursleaveDAO hrsdao;
	
	public Hoursleave save(int id,Date date,String shift,String des,int hr,String empcode) 
	{
		
		return hrsdao.save(id,date,shift,des,hr,empcode);
	}
	public Object get(String empcode,Date dt) {
		
		return hrsdao.get(empcode,dt);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return hrsdao.getall();
	}
	public Object delete(int id) {
		// TODO Auto-generated method stub
		return hrsdao.delete(id);
	}
}
