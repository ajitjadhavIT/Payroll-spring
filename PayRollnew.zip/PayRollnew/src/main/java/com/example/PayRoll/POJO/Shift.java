package com.example.PayRoll.POJO;

import java.sql.Time;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="shift")
public class Shift 
{
	

	@Id
	int idShift;
	String name;
	float allownce;
	Time startTime;
	Time endTime;
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getAllownce() {
		return allownce;
	}
	public void setAllownce(float allownce) {
		this.allownce = allownce;
	}
	public Time getStartTime() {
		return startTime;
	}
	public void setStartTime(Time startTime) {
		this.startTime = startTime;
	}
	public Time getEndTime() {
		return endTime;
	}
	public void setEndTime(Time endTime) {
		this.endTime = endTime;
	}

	
	
}
