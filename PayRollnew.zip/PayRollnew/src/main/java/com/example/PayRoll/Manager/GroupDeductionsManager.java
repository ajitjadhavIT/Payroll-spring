package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.DAO.GroupDeductionsDAO;
import com.example.PayRoll.POJO.GroupDeductions;
@Component
public class GroupDeductionsManager {
@Autowired
GroupDeductionsDAO gdDAO;
	public GroupDeductions save(int idGroupDeduction,String emptype,String deduction) {
		
		return gdDAO.save(idGroupDeduction,emptype,deduction);
	}
	public Object getall() {
	
		return gdDAO.getall();
	}

}
