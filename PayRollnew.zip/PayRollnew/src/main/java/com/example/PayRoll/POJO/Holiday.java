package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Entity
@Table(name="holiday")

public class Holiday 
{
	@Id
	int idHoliday;
	Date date;
	
	String description;
	int year;
	public int getIdHoliday() {
		return idHoliday;
	}
	public void setIdHoliday(int idHoliday) {
		this.idHoliday = idHoliday;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	
}
