package com.example.PayRoll.Controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.leaveApplicationDAO;
import com.example.PayRoll.Manager.leaveApplicationManager;
import com.example.PayRoll.POJO.leaveApplication;

@Component
@Controller
@RequestMapping("/leaveApplication")
public class leaveApplicationController
{
	@Autowired
	leaveApplicationManager leaapp;
	@Autowired
	leaveApplicationDAO leadao;
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public leaveApplication get(String empcode)
	{
		return leaapp.get(empcode);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/getall")
	public List getall()
	{
		return leaapp.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")//http://localhost:8080/leaveApplication/save?idleaveapp=0&employeeCode=1008&DateFrom=2018-10-14&DateTo=2018-10-15&Reason=dsfg&leave=SEEK&Description=dg&Application_Date=2018-10-13&Status=0
	public leaveApplication save(@RequestParam("idleaveapp")int id,@RequestParam("empcode")String empcode, @RequestParam("DateFrom")String DateFrom, 
			@RequestParam("DateTo")String DateTo, @RequestParam("Reason")String Reason,@RequestParam("leave")String leave,
			@RequestParam("Description")String Description, @RequestParam("Application_Date")String Application_Date,@RequestParam("Status")int Status) throws ParseException
	{
		return leaapp.save(id,empcode, DateFrom, DateTo, Reason, leave, Description, Application_Date,Status);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/leaveApplication_Report")
	public List leaveApplication_Report()
	{
		return leadao.leaveApplication_Report();
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/approval")
	public Object approval(@RequestParam("empcode")String empcode,@RequestParam("Result")String Result)
	{
		if(empcode.isEmpty())
		{
			return "Enter the valid Empcode";
		}
		else if(!Result.matches(patternInt))
		{
			return "Enter the Valid Result";
		}
		else
		{
		return leadao.approval(empcode, Result);
		}
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/leave_report")
	public Object leave_report(@RequestParam("Result")String Result,@RequestParam("Month")String Month,@RequestParam("year")String year)
	{
		if(!Result.matches(patternInt))
		{
			return "Enter the Valid Result";
		}
		else if(!Month.matches(patternInt))
		{
			return "Enter the Valid Month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter the valid Year";
		}
		else
		{
		return leadao.leave_report(Result, Month, year);
		}
	}
}
