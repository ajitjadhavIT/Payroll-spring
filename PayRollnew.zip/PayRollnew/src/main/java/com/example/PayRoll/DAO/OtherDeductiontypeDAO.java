package com.example.PayRoll.DAO;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.OtherDeduction;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.OtherDeductiontype;
@Component
public class OtherDeductiontypeDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	
	public OtherDeductiontype save(int id,String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		OtherDeductiontype od=new OtherDeductiontype();
		od.setIdOtherDeductionType(id);
		od.setName(name);
		session.saveOrUpdate(od);
		t.commit();  
		session.close();
		return od;
		
	}
	
	public Object get(String name)
	{
		Session session = (Session) hipernateConfg.getSession();  
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(OtherDeductiontype.class);
				cr.add(Restrictions.eq("name", name));
				return (OtherDeductiontype) cr.uniqueResult();

	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		Criteria cr = session.createCriteria(OtherDeductiontype.class);
	
		return cr.list();
	}

	public Object delete(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		OtherDeductiontype d = (OtherDeductiontype ) session.createCriteria(OtherDeductiontype.class)
                 .add(Restrictions.eq("name", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
}
