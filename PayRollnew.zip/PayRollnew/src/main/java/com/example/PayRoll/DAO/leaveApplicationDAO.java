package com.example.PayRoll.DAO;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Approval;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Incentive;
import com.example.PayRoll.POJO.LeaveAproval;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.leaveApplication;

@Component
@Controller
public class leaveApplicationDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	leaveApplication leapp;
	@Autowired
	EmployeeDAO EmployeeDAO;
	@Autowired
	LeaveDAO leavedao; 
	public leaveApplication get(String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(leaveApplication.class);
				cr.add(Restrictions.eq("idEmployees", id));
				return (leaveApplication) cr.uniqueResult();
	}
	public List getall() 
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(leaveApplication.class);
				return  cr.list();
	}

	public leaveApplication save(int id,String empcode,String DateFrom1,String DateTo1,String Reason,String leave, String Description,String Application_Date1,int Status) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date DateFrom = sdf.parse(DateFrom1);
		 Date DateTo = sdf.parse(DateTo1);
		 Date Application_Date = sdf.parse(Application_Date1);
		
		int idemp=EmployeeDAO.get(empcode).getIdEmployees();
		int idleave=leavedao.get(leave).getIdLeave();
		
		
		
		leaveApplication la=new leaveApplication();
		la.setIdLeaveapplication(id);
		la.setDateFrom(DateFrom);
		la.setDateTo(DateTo);
		la.setDescription(Description);
		la.setIdEmployees(idemp);
		la.setIdLeave(idleave);
		la.setReason(Reason);
		la.setApplication_Date(Application_Date);
		la.setStatus(Status);
		
		session.saveOrUpdate(la);
		t.commit();  
		session.close();
		return la;
	}
	public List leaveApplication_Report()
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Object[]> leave_application=new ArrayList<Object[]>();
		List<Map<String,Object>> leave_application_Report=new ArrayList<Map<String,Object>>();
	
	
		

		 Criteria cr=session.createCriteria(leaveApplication.class);
		 cr.add(Restrictions.eq("status", 0));
		 Projection p=Projections.property("idEmployees");
		 Projection p1=Projections.property("dateFrom");
		 Projection p2=Projections.property("dateTo");
		 Projection p3=Projections.property("reason");
		 Projection p4=Projections.property("idLeave");
		 Projection p5=Projections.property("application_Date");
		 ProjectionList sp=Projections.projectionList();
		 sp.add(p);
		 sp.add(p1);
		 sp.add(p2);
		 sp.add(p3);
		 sp.add(p4);
		 sp.add(p5);
		cr.setProjection(sp);
		leave_application=cr.list();
		 
		 
		for(Object[] rs:leave_application)
		{
			Map ms=new HashMap();
			
		int idEmployees=(int) rs[0];
		int idLeave=(int) rs[4];
		Criteria cp=session.createCriteria(Employees.class);
		cp.add(Restrictions.eq("idEmployees", idEmployees));
	
		Projection as=Projections.property("emp_First_Name");
		Projection a1=Projections.property("emp_Middle_Name");
		Projection a2=Projections.property("emp_Last_Name");

		ProjectionList pa=Projections.projectionList();

		pa.add(as);
		pa.add(a1);
		pa.add(a2);
	
		cp.setProjection(pa);
		List<Object[]> map=cp.list();
	
   		
		String name1=String.valueOf(map.get(0)[0])+" "+String.valueOf(map.get(0)[1])+" "+String.valueOf(map.get(0)[2]);


		Criteria r=session.createCriteria(TblLeave.class);
		r.add(Restrictions.eq("idLeave", idLeave));
		Projection pr=Projections.property("name");
		r.setProjection(pr);
		String Leave_type=(String) r.uniqueResult();

		ms.put("Employee_name  ", name1);
		ms.put("DateFrom", rs[1]);
		ms.put("DateTo", rs[2]);
		ms.put("Reason", rs[3]);
		ms.put("leave type", Leave_type);
		ms.put("Application_Date", rs[5]);
		leave_application_Report.add(ms);
		}
		return leave_application_Report;
		
		
	}
	public leaveApplication approval(String empcode1,String Result1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Date Current_Date=new Date();
		int Result=Integer.parseInt(Result1);
		System.err.print("empcode"+empcode1);
		System.err.print("Result"+Result);
		
		
		 Criteria ct=session.createCriteria(Employees.class);
		 ct.add(Restrictions.eq("employeeCode", empcode1));
		 Projection p=Projections.property("idEmployees");
		 ct.setProjection(p);
		 
		 int idemp=(int) ct.uniqueResult();
		 
		 int idleave=0;
	try {
		
		Criteria cr=session.createCriteria(leaveApplication.class);
		cr.add(Restrictions.eq("idEmployees", idemp));
		Projection pr=Projections.property("idLeaveapplication");
		cr.setProjection(pr);
		idleave=(int)cr.uniqueResult();

	}
	catch(Exception e)
	{
		idleave=0;
	}
		 LeaveAproval la=new LeaveAproval();
		la.setIdLeaveapplication(idleave);
		la.setresult(Result);
		la.setdate1(Current_Date);
		
		session.save(la);
	
	
		leaveApplication laApplication=new leaveApplication();
		session.saveOrUpdate(laApplication);
		
		
		   String hql = "update leaveApplication set status = '1' where idLeaveapplication = :idleave";
	        Query query = session.createQuery(hql);
	        query.setString(idleave,"idleave");
	        query.executeUpdate();
			return get(empcode1);
	}
	public List leave_report(String Result1,String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Calendar calendar = Calendar.getInstance();
		int Result=Integer.parseInt(Result1);
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		calendar.set(year, month-1, 1);
		Date Datef=calendar.getTime();
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date Datel=calendar.getTime();
	
		List<Map<String,Object>> Report=new ArrayList<Map<String,Object>>();
		List<Object[]> leave_application=new ArrayList<Object[]>();
		List<Object[]> leave_application1=new ArrayList<Object[]>();
		List<Map<String,Object>> m=new ArrayList<Map<String,Object>>();

		Criteria cr1=session.createCriteria(Approval.class);
		cr1.add(Restrictions.eq("result", Result));
		cr1.add(Restrictions.ge("date", Datef));
		cr1.add(Restrictions.lt("date", Datel));
		Projection p11=Projections.property("idLeaveapplication");
		cr1.setProjection(p11);
		leave_application=cr1.list();
		
		for(Object[] rs:leave_application)
		{
			Map z=new HashMap();
			int id=(int) rs[0];
	
			 Criteria cr=session.createCriteria(leaveApplication.class);
			 cr.add(Restrictions.eq("status", 0));
			 Projection p=Projections.property("idEmployees");
			 Projection p1=Projections.property("dateFrom");
			 Projection p2=Projections.property("dateTo");
			 Projection p3=Projections.property("reason");
			 Projection p4=Projections.property("idLeave");
			 Projection p5=Projections.property("application_Date");
			 Projection p6=Projections.property("status");
			 ProjectionList sp=Projections.projectionList();
			 sp.add(p);
			 sp.add(p1);
			 sp.add(p2);
			 sp.add(p3);
			 sp.add(p4);
			 sp.add(p5);
			 sp.add(p6);
			cr.setProjection(sp);
			leave_application1=cr.list();
			 
			for(Object[] x:leave_application1)
			{
				int idEmployees=(int) x[0];
				Criteria cp=session.createCriteria(Employees.class);
				cp.add(Restrictions.eq("idEmployees", idEmployees));
			
				Projection as=Projections.property("emp_First_Name");
				Projection a1=Projections.property("emp_Middle_Name");
				Projection a2=Projections.property("emp_Last_Name");

				ProjectionList pa=Projections.projectionList();

				pa.add(as);
				pa.add(a1);
				pa.add(a2);
			
				cp.setProjection(pa);
				List<Object[]> map=cp.list();
				
			String name1=String.valueOf(map.get(0)[0])+" "+String.valueOf(map.get(0)[1])+" "+String.valueOf(map.get(0)[2]);
			int idLeave=(int) x[4];
			Criteria r=session.createCriteria(TblLeave.class);
			r.add(Restrictions.eq("idLeave", idLeave));
			Projection pr=Projections.property("name");
			r.setProjection(pr);
			String Leave_type=(String) r.uniqueResult();
		
				z.put("Employee_Name", name1);
				z.put("DateFrom", x[1]);
				z.put("DateTo", x[2]);
				z.put("Reason", x[3]);
				z.put("Leave_type", Leave_type);
				z.put("Description", x[5]);
				z.put("Application_Date", x[6]);
				z.put("Status", x[7]);
				Report.add(z);
			}
		}
		return Report;
	}
}
