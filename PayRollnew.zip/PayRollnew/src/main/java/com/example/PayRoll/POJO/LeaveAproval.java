package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="approval")
public class LeaveAproval {
	@Id
	int idApproval;
	int idLeaveapplication;
	int result;
	Date date1;
	public int getIdApproval() {
		return idApproval;
	}
	public void setIdApproval(int idApproval) {
		this.idApproval = idApproval;
	}
	public int getIdLeaveapplication() {
		return idLeaveapplication;
	}
	public void setIdLeaveapplication(int idLeaveapplication) {
		this.idLeaveapplication = idLeaveapplication;
	}
	public int getresult() {
		return result;
	}
	public void setresult(int result) {
		result = result;
	}
	public Date getdate1() {
		return date1;
	}
	public void setdate1(Date date1) {
		date1 = date1;
	}
	@Override
	public String toString() {
		return "LeaveAproval [idApproval=" + idApproval + ", idLeaveapplication=" + idLeaveapplication + ", result="
				+ result + ", date1=" + date1 + "]";
	}
	
	
	
}
