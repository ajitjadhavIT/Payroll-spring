package com.example.PayRoll.Controller;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.example.PayRoll.DAO.OtpService;
import com.example.PayRoll.DAO.MyEmailService;

/**
 * @author shrisowdhaman
 * Dec 15, 2017
 */

@Controller
@RequestMapping("/OTP")

public class OtpController {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	public OtpService otpService;
	
	@Autowired
	public MyEmailService myEmailService;

	@GetMapping("/generateOtp")
	public int generateOtp(){
		
		
		//Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		String username = "AJIT";
		
		int otp = otpService.generateOTP(username);
		 
		logger.info("OTP : "+otp);
		
		//Generate The Template to send OTP 
		//EmailTemplate template = new EmailTemplate("SendOtp.html");
		
		Map<String,String> replacements = new HashMap<String,String>();
		replacements.put("user", username);
		replacements.put("otpnum", String.valueOf(otp));
		System.err.println("username "+username +"\n otp"+otp);
		 
		//String message = template.getTemplate(replacements);
		
		myEmailService.sendOtpMessage("ajitjadhav80@gmail.com", "OTP -PAYROLL ", String.valueOf(otp));
		
		return otp;
	}
	
	@RequestMapping(value ="/validateOtp", method = RequestMethod.GET)
	public @ResponseBody String validateOtp(@RequestParam("otpnum") int otpnum){
		
		final String SUCCESS = "Entered Otp is valid";
		
		final String FAIL = "Entered Otp is NOT valid. Please Retry!";
		
		//Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		String username = "user";
		
		//logger.info(" Otp Number : "+otpnum);
		
		//Validate the Otp 
		if(otpnum >= 0){
			int serverOtp = otpService.getOtp(username);
			
			if(serverOtp > 0){
				if(otpnum == serverOtp){
					otpService.clearOTP(username);
					return ("Entered Otp is valid");
				}else{
					return SUCCESS;	
				}
			}else {
				return FAIL;			
			}
		}else {
			return FAIL;	
		}
	}
}
