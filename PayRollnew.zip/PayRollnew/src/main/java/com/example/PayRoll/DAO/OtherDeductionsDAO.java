package com.example.PayRoll.DAO;


import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.OtherDeduction;
import com.example.PayRoll.POJO.OtherDeductiontype;
@Controller
@Component
public class OtherDeductionsDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	
	
	@Autowired
	EmployeeDAO EmployeeDAO;
	
	
	public OtherDeduction save(int id,String Empcode,String dedname,int month,float amount,int year) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();


		 Criteria ct=session.createCriteria(Employees.class);
		 ct.add(Restrictions.eq("employeeCode", Empcode));
		 Projection p=Projections.property("idEmployees");
		 ct.setProjection(p);
		 
		 int idemp=(int) ct.uniqueResult();
		
		Criteria cr=session.createCriteria(OtherDeductiontype.class);
		cr.add(Restrictions.eq("name", dedname));
		Projection pa=Projections.property("idOtherDeductionType");
		cr.setProjection(pa);
		
		 int idDED=(int) cr.uniqueResult();
		 OtherDeduction od=new OtherDeduction();
		od.setIdOtherDeductions(id);
		od.setAmount(amount);
		od.setIdEmployees(idemp);
		od.setIdOtherDeductionType(idDED);
		od.setMonth(month);
		od.setYear(year);
		session.saveOrUpdate(od);
		t.commit();  
		session.close();
		
		return od;
		
		
	}

	public List get(String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		OtherDeduction e1=new OtherDeduction();
	Criteria cr=session.createCriteria(OtherDeduction.class);
	cr.add(Restrictions.eq("idEmployees", id));
	
	
		return cr.list();

	}

	public List getall() 
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		Criteria e1 = session.createCriteria(OtherDeduction.class);
	
		return e1.list();

	}

	public Object delete(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		OtherDeduction d = (OtherDeduction ) session.createCriteria(OtherDeduction.class)
                 .add(Restrictions.eq("idSociety", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
}
