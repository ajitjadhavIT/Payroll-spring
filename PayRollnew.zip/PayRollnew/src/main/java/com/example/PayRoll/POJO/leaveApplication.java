package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
@Component
@Entity
@Table(name="leaveapplication")
public class leaveApplication 
{
//idLeaveapplication, idEmployees, dateFrom, dateTo, reason, idLeave, description, application_Date
	@Id
	int idLeaveapplication;
	int idEmployees;
	Date dateFrom;
	Date dateTo;
	String reason;
	int idLeave;
	String description;
	Date application_Date;
	 int status;
	public int getIdLeaveapplication() {
		return idLeaveapplication;
	}
	public void setIdLeaveapplication(int idLeaveapplication) {
		this.idLeaveapplication = idLeaveapplication;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public Date getDateFrom() {
		return dateFrom;
	}
	public void setDateFrom(Date dateFrom) {
		this.dateFrom = dateFrom;
	}
	public Date getDateTo() {
		return dateTo;
	}
	public void setDateTo(Date dateTo) {
		this.dateTo = dateTo;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getIdLeave() {
		return idLeave;
	}
	public void setIdLeave(int idLeave) {
		this.idLeave = idLeave;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getApplication_Date() {
		return application_Date;
	}
	public void setApplication_Date(Date application_Date) {
		this.application_Date = application_Date;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
