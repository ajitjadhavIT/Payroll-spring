package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.DesignationManager;
import com.example.PayRoll.POJO.Designation;
@Component
@Controller
@RequestMapping("/Designation")
public class DesignationController
{
	@Autowired
	DesignationManager desiman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("Shortform")String Shortform)
	{
		return desiman.get(Shortform);
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")
	public Designation save(@RequestParam("idDesignation")int iddes,@RequestParam("Name")String name,@RequestParam("Short_Form")String sft,@RequestParam("deptName")String deptName,@RequestParam("CatName")String CatName,@RequestParam("Salary")float sal)
	{
		
		return desiman.save(iddes,name,sft,deptName,CatName,sal);
		
	}
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public Object getall()
	{
		return desiman.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/delete")
	public Object delete(@RequestParam("name")String name)
	{
		return desiman.delete(name);
	}
}
