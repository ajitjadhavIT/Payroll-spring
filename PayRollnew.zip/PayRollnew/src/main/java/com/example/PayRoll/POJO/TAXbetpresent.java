package com.example.PayRoll.POJO;

public class TAXbetpresent {
	int month;
	String group;
	String dept;
	String Shiftname;
	String Design;
	String catag;
	String empcode;
	String EmpName;
	float pf;
	float pt;
	float esi;
	float other;
	float totaltax;
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getShiftname() {
		return Shiftname;
	}
	public void setShiftname(String shiftname) {
		Shiftname = shiftname;
	}
	public String getDesign() {
		return Design;
	}
	public void setDesign(String design) {
		Design = design;
	}
	public String getCatag() {
		return catag;
	}
	public void setCatag(String catag) {
		this.catag = catag;
	}
	public String getEmpcode() {
		return empcode;
	}
	public void setEmpcode(String empcode) {
		this.empcode = empcode;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public float getPf() {
		return pf;
	}
	public void setPf(float pf) {
		this.pf = pf;
	}
	public float getPt() {
		return pt;
	}
	public void setPt(float pt) {
		this.pt = pt;
	}
	public float getEsi() {
		return esi;
	}
	public void setEsi(float esi) {
		this.esi = esi;
	}
	public float getOther() {
		return other;
	}
	public void setOther(float other) {
		this.other = other;
	}
	public float getTotaltax() {
		return totaltax;
	}
	public void setTotaltax(float totaltax) {
		this.totaltax = totaltax;
	}
	
	
	

}
