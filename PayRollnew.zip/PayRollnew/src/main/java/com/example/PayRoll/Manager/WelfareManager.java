package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.WelfareDAO;
import com.example.PayRoll.POJO.Welfare;
@Controller
@Component
public class WelfareManager {

	@Autowired
	WelfareDAO welfareDAO;
	
	public Welfare save(int id,String emptype,int month,float amount) {
		
		return welfareDAO.save(id,emptype,month,amount);
	}

	public Object get(String id) {
		// TODO Auto-generated method stub
		return welfareDAO.get(id);
	}

	public Object getall() {
		// TODO Auto-generated method stub
		return welfareDAO.getall();
	}

	public Object delete(int id) {
		// TODO Auto-generated method stub
		return welfareDAO.delete(id);
	}

}
