package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="empworkdetails")
public class EmpWorkDetails 
{//idEmpWorkDetails, idEmployees, idDesignation, idShift, work_Area, joining_Date
	@Id
	int idEmpWorkDetails;
	int idEmployees;
	int idDesignation;
	int idShift;
	String work_Area;
	Date joining_Date;
	float hours;
	public int getIdEmpWorkDetails() {
		return idEmpWorkDetails;
	}
	public void setIdEmpWorkDetails(int idEmpWorkDetails) {
		this.idEmpWorkDetails = idEmpWorkDetails;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public int getIdDesignation() {
		return idDesignation;
	}
	public void setIdDesignation(int idDesignation) {
		this.idDesignation = idDesignation;
	}
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public String getWork_Area() {
		return work_Area;
	}
	public void setWork_Area(String work_Area) {
		this.work_Area = work_Area;
	}
	public Date getJoining_Date() {
		return joining_Date;
	}
	public void setJoining_Date(Date joining_Date) {
		this.joining_Date = joining_Date;
	}
	public float getHours() {
		return hours;
	}
	public void setHours(float hours) {
		this.hours = hours;
	}
	
	
	
	
}
