package com.example.PayRoll.Controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.ShiftDAO;
import com.example.PayRoll.Manager.ShiftManager;
import com.example.PayRoll.POJO.Shift;

@Component
@Controller
@RequestMapping("/Shift")

public class ShiftController 
{
	@Autowired
	ShiftManager shiftman;
	@Autowired
	ShiftDAO Shiftdao;
	
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("Name")String name)
	{
		return Shiftdao.getname(name);
	}
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/delete")
	public Object delete(@RequestParam("name")String name)
	{
		return Shiftdao.delete(name); 
	}
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public Object getall()
	{
		return Shiftdao.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")
	public Shift save(@RequestParam("id")int id,@RequestParam("name")String name,@RequestParam("start") String start,@RequestParam("end")String end,@RequestParam("allownce")float allownce) throws ParseException
	{
		return shiftman.save(id,name,start,end,allownce);
	}
}
