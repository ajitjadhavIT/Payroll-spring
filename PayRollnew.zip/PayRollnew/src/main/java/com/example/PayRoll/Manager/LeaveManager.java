package com.example.PayRoll.Manager;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import com.example.PayRoll.DAO.LeaveDAO;
import com.example.PayRoll.POJO.TblLeave;
@Component
@Controller
public class LeaveManager 
{	@Autowired
	LeaveDAO leavedao;

	public TblLeave save(int id,String name,String sf,int ispaid,int limit) {
		// TODO Auto-generated method stub
		return leavedao.save(id,name,sf,ispaid,limit);
	}
	public TblLeave get(String name) {
		// TODO Auto-generated method stub
		return leavedao.get(name);
	}
	public List getall() {
		// TODO Auto-generated method stub
		return leavedao.getall();
	}
	public Object delete(int id) {
		// TODO Auto-generated method stub
		return leavedao.delete(id);
	}
}
