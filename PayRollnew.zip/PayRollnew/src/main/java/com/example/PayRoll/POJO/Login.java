package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="login")
public class Login {
	
@Id

int idLogin;
String username;
String password;
String employeeCode;
public int getIdLogin() {
	return idLogin;
}
public void setIdLogin(int idLogin) {
	this.idLogin = idLogin;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmployeeCode() {
	return employeeCode;
}
public void setEmployeeCode(String employeeCode) {
	this.employeeCode = employeeCode;
}





}