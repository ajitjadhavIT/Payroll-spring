package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//otherdeductiontype
@Entity
@Table(name="otherdeductiontype")
public class OtherDeductiontype {
	
	@Id
	int idOtherDeductionType;
	String name;
	public int getIdOtherDeductionType() {
		return idOtherDeductionType;
	}
	public void setIdOtherDeductionType(int idOtherDeductionType) {
		this.idOtherDeductionType = idOtherDeductionType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "OtherDeductiontype [idOtherDeductionType=" + idOtherDeductionType + ", name=" + name + "]";
	}

	
	
	
	
}
