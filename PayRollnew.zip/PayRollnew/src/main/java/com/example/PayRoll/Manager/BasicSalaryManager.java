package com.example.PayRoll.Manager;

import java.util.Calendar;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.DAO.BasicSalaryDAO;
@Component
@Controller
public class BasicSalaryManager {

	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	BasicSalaryDAO bsDAO;
	
	public float basicsal(String empcode, int month, int year) {
		Session session = (Session) hipernateConfg.getSession();  
		
		Query s= session.createQuery("SELECT idSalarytype FROM Employees where EmployeeCode = :empcode");
		s.setParameter("empcode", empcode);	
		int idSalaryType=(int) s.uniqueResult();
		
		float Basic=0.0f;
		if(idSalaryType==1)
		{
			Basic= bsDAO.DesignationSal(empcode,month,year);
		}
		else if(idSalaryType==2)
		{
			Basic= bsDAO.PerDaySal(empcode,month,year);
		}
		else if(idSalaryType==3)
		{
			Basic= bsDAO.MonthlySal(empcode,month,year);
		}
		session.close();

return Basic;
	}
	public float LeaveHR(String empcode, int month, int year) {
		// TODO Auto-generated method stub
		return bsDAO.LeaveHR(empcode, month, year)+bsDAO.Overtime(empcode, month, year);
	}
	
	
	
	
	public float basicsal1(String empcode, Date dt) {
		Session session = (Session) hipernateConfg.getSession();  
		
		Query s= session.createQuery("SELECT idSalarytype FROM Employees where EmployeeCode = :empcode");
		s.setParameter("empcode", empcode);
		int idSalaryType=(int) s.uniqueResult();
		
		float Basic=0.0f;
		if(idSalaryType==1)
		{
			Basic= bsDAO.DesignationSal1(empcode,dt);
		}
		else if(idSalaryType==2)
		{
			Basic= bsDAO.PerDaySal1(empcode,dt);
		}
		else if(idSalaryType==3)
		{
			Basic= bsDAO.MonthlySal1(empcode,dt);
		}
		session.close();

return Basic;
	}/*
	public float basicsal2(String empcode, Date dt) {
		Session session = (Session) hipernateConfg.getSession();  
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dt);
	    int lastDate = calendar.getActualMaximum(Calendar.DATE);
	    
		Query s= session.createQuery("SELECT idSalarytype FROM Employees where EmployeeCode = :empcode");
		s.setParameter("empcode", empcode);
		int idSalaryType=(int) s.uniqueResult();
		
		float Basic=0.0f;
		if(idSalaryType==1)
		{
			Query w=session.createQuery("SELECT idEmployees FROM Employees where EmployeeCode = :empcode");
			w.setParameter("empcode", empcode);
			int idEmp=(int) w.uniqueResult();
			int idDesignation=0;
			
			Query q=session.createQuery("select MAX(salary) from designation where idDesignation in (SELECT distinct idDesignation FROM Attendance where idEmployees = (SELECT idEmployees FROM Employees where EmployeeCode = '1008' and Date = '2017/09/19'))");
			q.setParameter("empcode", empcode);
			q.setParameter("fd1", dt);
			
			idDesignation=(int) q.uniqueResult();
			Basic= bsDAO.DesignationSal1(empcode,dt);
		}
		else if(idSalaryType==2)
		{
			Basic= bsDAO.PerDaySal1(empcode,dt);
		}
		else if(idSalaryType==3)
		{
			Basic= bsDAO.MonthlySal1(empcode,dt);
		}
		session.close();

return Basic;
	}*/

}
