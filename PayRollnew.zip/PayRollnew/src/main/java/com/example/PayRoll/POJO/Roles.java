package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="roles")
public class Roles {
@Id
	int idRoles;
	String role;
	public int getIdRoles() {
		return idRoles;
	}
	public void setIdRoles(int idRoles) {
		this.idRoles = idRoles;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
