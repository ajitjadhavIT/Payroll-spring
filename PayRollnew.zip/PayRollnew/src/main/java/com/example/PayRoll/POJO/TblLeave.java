package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tblleave")
public class TblLeave 
{//idLeave, name, short_Form, isPaid, limit
	@Id
	int idLeave;
	String name;
	String short_Form;
	int limit1;
	int isPaid;
	public int getIdLeave() {
		return idLeave;
	}
	public void setIdLeave(int idLeave) {
		this.idLeave = idLeave;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShort_Form() {
		return short_Form;
	}
	public void setShort_Form(String short_Form) {
		this.short_Form = short_Form;
	}
	public int getLimit1() {
		return limit1;
	}
	public void setLimit1(int limit1) {
		this.limit1 = limit1;
	}
	public int getIsPaid() {
		return isPaid;
	}
	public void setIsPaid(int isPaid) {
		this.isPaid = isPaid;
	}
	
	
	
}
