package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.LeaveAprovalManager;
import com.example.PayRoll.POJO.LeaveAproval;

@Controller
@RequestMapping("/LeaveAproval")
public class LeaveAprovalController {
	
	@Autowired
	LeaveAprovalManager LAManager;
	
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public LeaveAproval save(@RequestBody LeaveAproval la)
	{
		return LAManager.save(la);
	}
	

	@RequestMapping("/getall")
	@GetMapping
	@ResponseBody
	public Object getall()
	{
		return LAManager.getall();
	}
	
}
