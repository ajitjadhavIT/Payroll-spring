 package com.example.PayRoll.POJO;

import java.util.HashMap;
import java.util.Map;

public class SalarySlip {

	int month;
	int year;
	String empName;
	String empCode;
	float basic;
	float incidence;
	float allownce;
	float other;
	float pF;
	float pT;
	float eSI;
	float advance;
	float society;
	float loan;
	float canteen;
	float busCharge;
	float houseRent;
	float phoneBill;
	float lWS;
	float tDS;
	float totalEarn;
	double totaldeduction;
	float payDays;
	String iNWordNetpay;
	Map desigDays=new HashMap();
	float Totalpayable;
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpCode() {
		return empCode;
	}
	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}
	public float getBasic() {
		return basic;
	}
	public void setBasic(float basic) {
		this.basic = basic;
	}
	public float getIncidence() {
		return incidence;
	}
	public void setIncidence(float incidence) {
		this.incidence = incidence;
	}
	public float getAllownce() {
		return allownce;
	}
	public void setAllownce(float allownce) {
		this.allownce = allownce;
	}
	public float getOther() {
		return other;
	}
	public void setOther(float other) {
		this.other = other;
	}
	public float getpF() {
		return pF;
	}
	public void setpF(float pF) {
		this.pF = pF;
	}
	public float getpT() {
		return pT;
	}
	public void setpT(float pT) {
		this.pT = pT;
	}
	public float geteSI() {
		return eSI;
	}
	public void seteSI(float eSI) {
		this.eSI = eSI;
	}
	public float getAdvance() {
		return advance;
	}
	public void setAdvance(float advance) {
		this.advance = advance;
	}
	public float getSociety() {
		return society;
	}
	public void setSociety(float society) {
		this.society = society;
	}
	public float getLoan() {
		return loan;
	}
	public void setLoan(float loan) {
		this.loan = loan;
	}
	public float getCanteen() {
		return canteen;
	}
	public void setCanteen(float canteen) {
		this.canteen = canteen;
	}
	public float getBusCharge() {
		return busCharge;
	}
	public void setBusCharge(float busCharge) {
		this.busCharge = busCharge;
	}
	public float getHouseRent() {
		return houseRent;
	}
	public void setHouseRent(float houseRent) {
		this.houseRent = houseRent;
	}
	public float getPhoneBill() {
		return phoneBill;
	}
	public void setPhoneBill(float phoneBill) {
		this.phoneBill = phoneBill;
	}
	public float getlWS() {
		return lWS;
	}
	public void setlWS(float lWS) {
		this.lWS = lWS;
	}
	public float gettDS() {
		return tDS;
	}
	public void settDS(float tDS) {
		this.tDS = tDS;
	}
	public float getTotalEarn() {
		return totalEarn;
	}
	public void setTotalEarn(float totalEarn) {
		this.totalEarn = totalEarn;
	}
	public double getTotaldeduction() {
		return totaldeduction;
	}
	public void setTotaldeduction(double totaldeduction) {
		this.totaldeduction = totaldeduction;
	}
	public float getPayDays() {
		return payDays;
	}
	public void setPayDays(float payDays) {
		this.payDays = payDays;
	}
	public String getiNWordNetpay() {
		return iNWordNetpay;
	}
	public void setiNWordNetpay(String iNWordNetpay) {
		this.iNWordNetpay = iNWordNetpay;
	}
	public Map getDesigDays() {
		return desigDays;
	}
	public void setDesigDays(Map desigDays) {
		this.desigDays = desigDays;
	}
	public float getTotalpayable() {
		return Totalpayable;
	}
	public void setTotalpayable(float totalpayable) {
		Totalpayable = totalpayable;
	}
	
	
	
}
