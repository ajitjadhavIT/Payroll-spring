package com.example.PayRoll.Controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.holiday_DAO;
import com.example.PayRoll.Manager.holiday_Manager;
import com.example.PayRoll.POJO.Holiday;

@Component
@Controller
@RequestMapping("/holiday")
public class holiday_Controller 
{
	@Autowired
	holiday_Manager holman;
	@Autowired
	holiday_DAO holdao;
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public List get(@RequestParam("Month")int Month,@RequestParam("year")int year)
	{
		return holdao.get(Month, year);
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public List getall()
	{
		return holdao.getall();
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")
	public Holiday save(@RequestParam("id")int id,@RequestParam("date")String dt,@RequestParam("descrip")String desc,@RequestParam("year")int year) throws ParseException
	{
		return holman.save(id,dt,desc,year);
		
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/Holiday_Report")
	public Object Holiday_Report(@RequestParam("year")String year)
	{
		if(!year.matches(patternInt))
		{
			return "Enter the valid year";
		}
		else
		{
			return holdao.Holiday_Report(year);	
		}
		
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id")int id)
	{
		return holdao.delete(id);
	}
}
