package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.BankdetailsManager;

@Controller
@RequestMapping("/Bankdetails")
public class BankdetailsController 
{
	@Autowired
	BankdetailsManager bnkman;
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/get")
	public Object get(@RequestParam("Empcode")String empcode)
	{
		return bnkman.get(empcode);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/getall")
	public Object getall()
	{
			return bnkman.getall();
	}
		
	@GetMapping
	@ResponseBody
	@RequestMapping("/delete")
	public Object delete(@RequestParam("Empcode")String empcode)
	{
			return bnkman.delete(empcode);
	}	
	
	@GetMapping
	@ResponseBody
	@RequestMapping
	public Object update(@RequestParam("idbank")int idbank,@RequestParam("empcode")String empcode,@RequestParam("bankname")String bankname,@RequestParam("accno")int accno,@RequestParam("branch")String branch,@RequestParam("acctype")String acctype,@RequestParam("ifsccode")String ifsccode,@RequestParam("pfno")String pfno)
	{
		return bnkman.update(idbank, empcode, bankname, accno, branch, acctype, ifsccode, pfno);
	}
}
