package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigurationPackage;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.Provisional_FundManager;
import com.example.PayRoll.POJO.Provisional_Fund;
@Controller
@RequestMapping("ProvisionalFund")

public class Provisional_FundController {


	
		@Autowired
		Provisional_FundManager PFManager;
		@RequestMapping("/save")
		@PostMapping
		@ResponseBody
		public String save(Provisional_Fund pf)
		{
			
			return PFManager.save(pf);
		}
	
		@RequestMapping("/get")
		@GetMapping
		@ResponseBody
		public String get(@RequestParam("id") String id) 
		{
			String pattern = "\\d+";
			if(id.matches(pattern))
				return ""+PFManager.get(id).toString();
			else
				return "Enter valid id";
			
			
		}

}