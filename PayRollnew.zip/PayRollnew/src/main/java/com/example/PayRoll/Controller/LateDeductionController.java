package com.example.PayRoll.Controller;

import java.sql.Time;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.LateDeductionDAO;
import com.example.PayRoll.POJO.LateDeduction;

@Component
@Controller
@RequestMapping("/latededuction")
public class LateDeductionController {

	@Autowired
	LateDeductionDAO lddao;
	@RequestMapping("/get")
	@GetMapping
	@ResponseBody
	public List get(@RequestParam("emptype")String emptype)
	{
		return lddao.get(emptype);
	}
	@RequestMapping("/getall")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public List getall()
	{
		return lddao.getall();
	}
	@RequestMapping("/save")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public LateDeduction save(@RequestParam("id")int id,@RequestParam("time")Time time,@RequestParam("days")float days,@RequestParam("deddays")float deddays,@RequestParam("shift")String shift,@RequestParam("emptype")String emptype)
	{
		return lddao.save(id,time,days,deddays,shift,emptype);
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id")int id)
	{
		return lddao.delete(id);
	}
}
