package com.example.PayRoll.DAO;



import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;

import com.example.PayRoll.POJO.Empleave;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.TblLeave;

@Component
@Controller
public class EmpleaveDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	LeaveDAO leaveDAO;
	@Autowired
	EmployeeDAO EmployeeDAO;
	public Empleave save(String empcode,Date date,String leavename,String Shift)
	{	
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		ShiftDAO s=new ShiftDAO();
		Shift info=(Shift) s.get(Shift);
		int idShift=info.getIdShift();
		int idemp=EmployeeDAO.get(empcode).getIdEmployees();
		int idleave=leaveDAO.get(leavename).getIdLeave();
		Empleave empl=new Empleave();
		empl.setDate(date);
		empl.setIdEmployees(idemp);
		empl.setIdleave(idleave);
		empl.setIdShift(idShift);
		
		session.saveOrUpdate(empl);
		t.commit();
		session.close();
		return empl;
		
	}

	public List get(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		System.err.println("idEmployees"+id);
		Criteria cr = session.createCriteria(Empleave.class);
		cr.add(Restrictions.eq("idEmployees", id));
		return cr.list();
		
	}
	public List getall()
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		
		Criteria cr = session.createCriteria(Empleave.class);
		
		return cr.list();
		
	}
	public List leaveReport(String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//shift, /Department, /Designation, Employee Code, Employee Name, Leave Type.
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, month-1, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date Lastdate=calendar.getTime();
		System.out.println("dates "+FirstDate+"last"+Lastdate);
		List<Map<String,Object>> leaveReport=new ArrayList<Map<String,Object>>();
		List<Object[]> map=new ArrayList<Object[]>();
		
		Map x=new HashMap();
		
		Criteria cr=session.createCriteria(Empleave.class);
		cr.add(Restrictions.ge("date", FirstDate));
		cr.add(Restrictions.lt("date", Lastdate));
		Projection p=Projections.property("idEmployees");
		Projection p1=Projections.property("idleave");
		Projection p2=Projections.property("idShift");
		ProjectionList pl=Projections.projectionList();
		pl.add(p);
		pl.add(p1);
		pl.add(p2);
		cr.setProjection(pl);
		map=cr.list();
		
		for(Object[] r:map)
		{
		int idEmployees=(int) r[0];
		int idLeave=(int) r[1];
		int idShift=(int) r[2];

		Criteria cp=session.createCriteria(Employees.class);
		cp.add(Restrictions.eq("idEmployees", idEmployees));
		Projection as=Projections.property("emp_First_Name");
		Projection a1=Projections.property("emp_Middle_Name");
		Projection a2=Projections.property("emp_Last_Name");
		Projection a3=Projections.property("employeeCode");
		ProjectionList pt=Projections.projectionList();
		pt.add(as);
		pt.add(a1);
		pt.add(a2);
		pt.add(a3);
		cp.setProjection(pt);
		List<Object[]> map1=cp.list();
		String name=String.valueOf(map1.get(0)[0])+" "+String.valueOf(map1.get(0)[1])+" "+String.valueOf(map1.get(0)[2]);
		int EmployeeCode=Integer.parseInt( (String) map1.get(0)[3]);
		
		
		Criteria cd=session.createCriteria(Shift.class);
		cd.add(Restrictions.eq("idShift", idShift));
		Projection ap=Projections.property("name");
		cd.setProjection(ap);
		String shift=(String)cd.uniqueResult();

		Criteria sd=session.createCriteria(TblLeave.class);
		sd.add(Restrictions.eq("idLeave", idLeave));
		Projection pn=Projections.property("name");
		sd.setProjection(pn);
		String Leave_Type=(String) sd.uniqueResult();
		Query query1 =session.createQuery("SELECT t1.idDesignation, t2.Name,t2.idDepartment, t3.Name FROM EmpWorkDetails t1 join Designation t2 \r\n" + 
				"			  ON t1.idDesignation = t2.idDesignation join Department t3 ON t2.idDepartment = t3.idDepartment \r\n" + 
				"			  where idEmployees = :idEmployees");
		query1.setParameter("idEmployees", idEmployees);
		List<Object[]> m =  query1.list();
				
		 String Designation_Name=(String) m.get(0)[1];
		 String DeptName=(String)m.get(0)[3];
		 
		 x.put("shift", shift);
		 x.put("EmployeeCode", EmployeeCode);
		 x.put("Employee Name",name);
		 x.put("Leave Type", Leave_Type);
		 x.put("Designation", Designation_Name);
		 x.put("DeptName", DeptName);
		 leaveReport.add(x);
		}
		 
		return leaveReport;
	}
}
