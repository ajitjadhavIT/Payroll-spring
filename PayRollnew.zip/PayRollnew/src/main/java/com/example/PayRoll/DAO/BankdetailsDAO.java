package com.example.PayRoll.DAO;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Bankdetails;
import com.example.PayRoll.POJO.Employees;


@Component

public class BankdetailsDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	BasicSalaryDAO basicSalaryDAO;
	@Autowired
	EmployeeDAO EmployeeDAO;
	
	public String save(int idbank,String empcode,String bankname,String accno,String branch,String acctype,String ifsccode,String pfno)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		//String empcode,String bankname,String accno,String branch,String acctype,String ifsccode,String pfno
		
		Bankdetails bd=new Bankdetails();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		bd.setIdBankDetails(idbank);
		bd.setIdEmployees(id);
		bd.setBank_Name(bankname);
		bd.setAccount_Number(Integer.parseInt(accno));
		bd.setBranch(branch);
		bd.setAccount_type(acctype);
		bd.setiFSC_Code(ifsccode);
		bd.setpF_NO(pfno);
		session.saveOrUpdate(bd);
		t.commit();  
		session.close();
		return "Saved Succesfully";
	}

	public Object get(String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Bankdetails.class);
		cr.add(Restrictions.eq("id", id));
		return (Bankdetails) cr.uniqueResult();
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		
		Criteria cr = session.createCriteria(Bankdetails.class);
	
		return  cr.list();
	}

	public Object delete(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		Criteria cr=session.createCriteria(Bankdetails.class);
		cr.add(Restrictions.eq("idEmployees", id));
		Projection pr=Projections.property("idBankDetails");
		cr.setProjection(pr);
		int idbank=(int) cr.uniqueResult();
		
		Bankdetails bd = (Bankdetails) session.get(Bankdetails.class, idbank);

        session.delete(bd);
        t.commit();

		return "record deleted";
	}

	public String update(int idbank,String empcode,String bankname,int accno,String branch,String acctype,String ifsccode,String pfno)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Bankdetails bd=new Bankdetails();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		
		bd.setIdBankDetails(idbank);
		bd.setAccount_Number(accno);
		bd.setAccount_type(acctype);
		bd.setBank_Name(bankname);
		bd.setBranch(branch);
		bd.setIdEmployees(id);
		bd.setiFSC_Code(ifsccode);
		bd.setpF_NO(pfno);
		session.update(bd);
		t.commit();
		
		return "record updated";
		
	}
	
}
