package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.Deductionsmanager;
import com.example.PayRoll.POJO.Deductions;

	@Controller
	@RequestMapping("Deductions")
	
	public class DeductionsController
	{
		
		@Autowired
		Deductionsmanager dtManager;
		@RequestMapping("/save")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Deductions save(@RequestParam("id")int id,@RequestParam("name")String name)
		{
		
				return dtManager.save(id,name);
		}
		
		
		@RequestMapping("/getall")
		@GetMapping
		@CrossOrigin()
		@ResponseBody
		public Object getall()
		{
				return dtManager.getall(); 
			
			
		}
		@RequestMapping("/delete")
		@GetMapping
		@CrossOrigin()
		@ResponseBody
		public Object delete(@RequestParam("name")String name)
		{
			return dtManager.delete(name);
		}
	
}
