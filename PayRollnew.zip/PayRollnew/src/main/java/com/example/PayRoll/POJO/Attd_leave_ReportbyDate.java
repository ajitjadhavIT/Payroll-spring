package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class Attd_leave_ReportbyDate 
{
	List<Object[]> present=new ArrayList<Object[]>();
	
	List<Object[]> leave=new ArrayList<Object[]>();
	
	List Total=new ArrayList();

	public List<Object[]> getPresent() {
		return present;
	}

	public void setPresent(List<Object[]> present) {
		this.present = present;
	}

	public List<Object[]> getLeave() {
		return leave;
	}

	public void setLeave(List<Object[]> leave) {
		this.leave = leave;
	}

	public List getTotal() {
		return Total;
	}

	public void setTotal(List total) {
		Total = total;
	}
	
	
	
}
