package com.example.PayRoll.DAO;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.Manager.BasicSalaryManager;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.BonusSetting;
import com.example.PayRoll.POJO.Catagory;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Empleave;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Emptype;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.Overtimebetdates;
import com.example.PayRoll.POJO.Salary;
import com.example.PayRoll.POJO.SalaryDeduction;
import com.example.PayRoll.POJO.SalaryEarning;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.TAXbetpresent;
import com.example.PayRoll.POJO.TOTALTAXbet;
import com.example.PayRoll.POJO.TaxDedReportFilter;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.WagesDayFilter;
import com.example.PayRoll.POJO.bonusSalaryFilter;
import com.example.PayRoll.POJO.incentiveFilter;
import com.example.PayRoll.POJO.otherDedBetMonthFilter;
import com.example.PayRoll.POJO.overtimebetmonth;
import com.example.PayRoll.POJO.overtimedayreport;
import com.example.PayRoll.POJO.salaryFilterMonth;
import com.example.PayRoll.POJO.wagesBetMonths;
import com.example.PayRoll.POJO.wagesDateBtwn;


@Component
public class WagesDayFilterDAO {

	@Autowired
	EmployeeSalaryDAO ESdao;
	@Autowired
	OtherDeductionDAO ODdao;
	@Autowired
	AllDeductionDAO ADdao;
	@Autowired
	DesignationDAO designationDAO;
	@Autowired
	EmployeeDAO employeeDAO;
	@Autowired
	DepartmentDAO departmentDAO;
	
	@Autowired
	AttendanceDAO adDAO;
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	WorkhoursDAO1 whdao;
	@Autowired
	BasicSalaryManager bsmanager;
	@Autowired
	BasicSalaryDAO bsdao;
	@Autowired
	ReportDAO rpDao;


public List<Object[]> BasicSalaryReport(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	
	
	List<Integer> Common_list=new ArrayList<Integer>();
	List<Object[]> present_report=new ArrayList<Object[]>();
	List<Integer> Shift_report=new ArrayList<Integer>();
	int idemp=0;

	Date date1=date;
	Calendar calendar = Calendar.getInstance();  
   calendar.setTime(date1);
   int year = calendar.get(Calendar.YEAR);
   int month = calendar.get(Calendar.MONTH) + 1;

Criteria cr=session.createCriteria(EmpWorkDetails.class);
Projection pr=Projections.property("idEmployees");
cr.setProjection(pr);
Common_list=cr.list();

	
	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
if(!Shift.isEmpty())
{
	   Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("Name", Shift )).uniqueResult();
	   int idshift=e1.getIdShift();
	 
	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date1));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();

	   Common_list.retainAll(Shift_report);
	   		
}



Query r=session.createQuery("select empt.name as Emptype, CONCAT(emp.emp_First_Name, ' ',emp.emp_Middle_Name,' ',emp.emp_Last_Name) AS EmployeeName "
 		+ ", emp.employeeCode as EmployeeCode, desg.name,desg.salary as Designation,"
 		+ " cat.name as Catagory, MINUTE(TIMEDIFF(outtime,intime )),Hour(TIMEDIFF(outtime,intime )) as WORKHOURS, "
 		+ "dept.name as Department"
 		+ " , sft.name as Shift, emwd.hours as Hours "
 		
  		+ "from Emptype as empt, Employees as emp, Designation as desg, Catagory as cat,"
 		+ " Department as dept, Shift as sft,Workhours whr, EmpWorkDetails as emwd " + 
 		"where " + 
 		"emp.idEmployees in :Common_list "
 		+ "and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)"
 		+ " and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)"
 		+ " and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)"
 		+ " and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )"
 		+ " and sft.idShift = (select idShift from Overtime where Date = :date and idEmployees = emp.idEmployees)"
 		+ " and whr.idWorkHours=(select idWorkHours from Workhours where idAttendance = (select idAttendance from Attendance where date = :date and idEmployees = emp.idEmployees))"
 		+ " and emwd.idEmpWorkDetails = (select idEmpWorkDetails from EmpWorkDetails where idEmployees = emp.idEmployees)");

	r.setParameter("Common_list", Common_list);
r.setParameter("date", date1);

present_report=r.list();


	return present_report;

	
}
public List overtimeSalaryReport(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	
	
	List<Integer> Common_list=new ArrayList<Integer>();
	List<Object[]> present_report=new ArrayList<Object[]>();
	List<Integer> Shift_report=new ArrayList<Integer>();
	int idemp=0;
	
	Date date1=date;
	Calendar calendar = Calendar.getInstance();  
  calendar.setTime(date1);
  int year = calendar.get(Calendar.YEAR);
  int month = calendar.get(Calendar.MONTH) + 1;

  Criteria cr=session.createCriteria(EmpWorkDetails.class);
  Projection pr=Projections.property("idEmployees");
  cr.setProjection(pr);
  Common_list=cr.list();
List ovr=new ArrayList<>();

	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
if(!Shift.isEmpty())
{
   Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add(Restrictions.eq("name", Shift )).uniqueResult();
	   int idshift=e1.getIdShift();

	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date1));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   Common_list.retainAll(Shift_report);
	   		
}

for(int i=0;i<Common_list.size();i++)
{
	List fnl=new ArrayList();
	//List<Object[]> bonnus=new ArrayList<Object[]>();
	int idEmployees=(int) Common_list.get(i);
	

	
	Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
			+ "cat.name as Catagory, dept.name as Department  "
			+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
			"	  		 where  " + 
			"	  		 emp.idEmployees in :idEmployees " + 
			"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
			"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
			"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
			"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

		r.setParameter("idEmployees", idEmployees);
		
		present_report=r.list();
		String group=(String) present_report.get(0)[0];
		String Design=(String) present_report.get(0)[1];
		
		String catag=(String) present_report.get(0)[2];
		String dept=(String) present_report.get(0)[3];

		Criteria a=session.createCriteria(Employees.class);
		a.add(Restrictions.eq("idEmployees", idEmployees));
		Projection p=Projections.property("employeeCode");
		a.setProjection(p);
		String empcode=(String) a.uniqueResult();
		

		Criteria va=session.createCriteria(Designation.class);
		va.add(Restrictions.eq("name", Design));
		Projection vp=Projections.property("salary");
		va.setProjection(vp);
		float salary=(float) va.uniqueResult();
		
		Criteria b=session.createCriteria(EmpWorkDetails.class);
		b.add(Restrictions.eq("idEmployees", idEmployees));
		Projection np=Projections.property("idShift");
		Projection pd=Projections.property("hours");
		ProjectionList pf=Projections.projectionList();
		pf.add(np);
		pf.add(pd);
		b.setProjection(pf);
		
		
		 List<Object[]>shifthr= b.list();
		int idShift= (int) shifthr.get(0)[0];
		float wkhours= (float) shifthr.get(0)[1];
		
		Criteria bs=session.createCriteria(Shift.class);
		bs.add(Restrictions.eq("idShift", idShift));
		Projection nps=Projections.property("name");
		bs.setProjection(nps);
		String Shiftname=(String) bs.uniqueResult();	
		
		
		
	Map Info=new HashMap();
	Info=bsdao.info(empcode);//Emp_id& Emp_Name
	String EmpName=(String) Info.get("EmployeeName");
	float hours=0.0f;
	try {
	Criteria qb=session.createCriteria(Overtime.class);
	qb.add(Restrictions.eq("idEmployees", idEmployees));
	qb.add(Restrictions.eq("date", date));
	Projection npq=Projections.property("hours");
	qb.setProjection(npq);
	 hours=(float) qb.uniqueResult();
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	float daycon=hours/wkhours;
	
	float tsalary=daycon*salary;
	fnl.add(group);
	fnl.add(Design);
	fnl.add(catag);
	fnl.add( dept);
	fnl.add(Shiftname);
	fnl.add(hours);
	fnl.add(tsalary);
	fnl.add(EmpName);
	fnl.add(empcode);
ovr.add(fnl);

}
return ovr;
	
}


public List LeaveSalaryReport(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  

	List<Integer> From_dept=new ArrayList<Integer>();
	List<Integer> From_group=new ArrayList<Integer>();
	List<Integer> From_Category=new ArrayList<Integer>();      
	List<Integer> From_designation=new ArrayList<Integer>();
	List<Integer> from_employeecode=new ArrayList<Integer>();
	List<Integer> Common_list=new ArrayList<Integer>();
	List<Attendance> present_report=new ArrayList<Attendance>();
	List<Integer> Shift_report=new ArrayList<Integer>();
	int idemp=0;
	

	Date date1=date;
	Calendar calendar = Calendar.getInstance();  
 calendar.setTime(date1);
 int year = calendar.get(Calendar.YEAR);
 int month = calendar.get(Calendar.MONTH) + 1;
Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
	
if(!Shift.isEmpty())
{
  Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
	   int idshift=e1.getIdShift();

	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date1));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   Common_list.retainAll(Shift_report);
	   		
}

Query r=session.createQuery("select empt.name as Emptype,CONCAT(emp.emp_First_Name,' ',emp.emp_Middle_Name,' ',emp.emp_Last_Name) AS EmployeeName , emp.employeeCode as EmployeeCode, desg.name,desg.salary as Designation, "
	+ "cat.name as Catagory,lea.name as leaveName, dept.name as Department , sft.name as Shift "
	+ "from Emptype as empt, Employees as emp, Designation as desg, TblLeave as lea, Catagory as cat, Department as dept, Shift as sft  " + 
	"	  		 where  " + 
	"	  		 emp.idEmployees in :Common_list " + 
	"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
	"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
	"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
	"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )  " + 
	"	  		  and sft.idShift = (select idShift from Overtime where Date = :date and idEmployees = emp.idEmployees)  " + 
	"	  		  and lea.idLeave = (SELECT idLeave FROM Empleave where Date = :date and idEmployees = emp.idEmployees)");

r.setParameter("Common_list", Common_list);
r.setParameter("date", date1);
//r.setParameter("month", month);
//r.setParameter("year", year);
present_report=r.list();

	session.close();

	return present_report;

	
}



public List TotalSalaryReportday(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	
	List<Integer> Common_list=new ArrayList<Integer>();
	List present_report=new ArrayList();
	List<Integer> Shift_report=new ArrayList<Integer>();
	int idemp=0;
	
	Date date1=date;
	Calendar calendar = Calendar.getInstance();  
calendar.setTime(date1);
int year = calendar.get(Calendar.YEAR);
int month = calendar.get(Calendar.MONTH) + 1;

Criteria cr=session.createCriteria(EmpWorkDetails.class);
Projection pr=Projections.property("idEmployees");
cr.setProjection(pr);
Common_list=cr.list();

	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
if(!Shift.isEmpty())
{
 		Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("Name", Shift )).uniqueResult();
	   int idshift=e1.getIdShift();

	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date1));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   Common_list.retainAll(Shift_report);
	   		
}

float TotalWorkingHR=0.0f;
float totalDayConverted=0.0f;
float totalBasicSal=0.0f;
float totalPaidLeaveSal=0.0f;
int totalispaid=0;


List<Object[]> presen = this.BasicSalaryReport(date1, Group, Department, Catagory, Designation, Shift, Employee_Code);
int noofemp=presen.size();
for(int i=0;i<presen.size();i++)
{
		Map abc=new HashMap();
		List<Object[]> codeHR=new ArrayList<Object[]>();
		Query r=session.createQuery("select a.employeeCode,b.hours from Employees a join EmpWorkDetails b on a.idEmployees=b.idEmployees where a.idEmployees= :idemp");
		r.setParameter("idemp", Common_list.get(i));
		codeHR=r.list();
		
		String empcode=(String) presen.get(i)[2];

		int minutes = (int) presen.get(i)[6];
		int Hours = (int) presen.get(i)[7];
		float HR=(float)(Float.parseFloat(String.valueOf(minutes))/60);
		float workhr=HR+Hours;
		

		float WorkHR=(float) presen.get(i)[10];
		
		TotalWorkingHR=TotalWorkingHR+Hours;
		
		float DayConverted=(Hours/WorkHR);
		
		totalDayConverted += DayConverted;
		
	  
	    
		float BasicSal=bsmanager.basicsal1(empcode, date);
		float netprDaySal=BasicSal;
		totalBasicSal=totalBasicSal+netprDaySal;
		abc=bsdao.paidLeaveSal1(empcode, date);
		int ispaid=(int) abc.get("isPaid");
		float PaidLeaveSal=(float) abc.get("totalPaidLeaveSal");
		totalPaidLeaveSal=totalPaidLeaveSal+PaidLeaveSal;
		totalispaid=totalispaid+ispaid;

}



present_report.add(noofemp);
present_report.add(TotalWorkingHR);
present_report.add(totalDayConverted);
present_report.add(totalBasicSal);
present_report.add(totalispaid);
present_report.add(totalPaidLeaveSal);
session.close();
	return present_report;
}

public WagesDayFilter Wagesdayreport(String date1,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	String end[]=date1.split("-");
	int day=Integer.valueOf(end[2]);
	int month2=Integer.valueOf(end[1]);
	int year2=Integer.valueOf(end[0]);
	Calendar calendar = Calendar.getInstance();  
	//String dt=String.valueOf(year2)+"/"+String.valueOf(month2)+"/"+String.valueOf(day);
	calendar.set(year2, month2, day);
System.err.println(date1);
	//Date date=calendar.getTime();
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Date date = sdf.parse(String.valueOf(date1));
	WagesDayFilter WDfilter = new WagesDayFilter();
	WDfilter.setLeaveDay(this.LeaveSalaryReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code));
	WDfilter.setOvertimeday(this.overtimeSalaryReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code));
	WDfilter.setSalday(this.BasicSalaryReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code));
	WDfilter.setTotalday(this.TotalSalaryReportday(date, Group, Department, Catagory, Designation, Shift, Employee_Code));

	return WDfilter;
	
}




public List TotalSalarybetDays(Date strtdate,Date enddate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	List<Integer> From_dept=new ArrayList<Integer>();
	List<Integer> From_group=new ArrayList<Integer>();
	List<Integer> From_Category=new ArrayList<Integer>();
	List<Integer> From_designation=new ArrayList<Integer>();
	List<Integer> from_employeecode=new ArrayList<Integer>();
	List<Integer> Common_list=new ArrayList<Integer>();
	List present_report=new ArrayList();
	List<Integer> Shift_report=new ArrayList<Integer>();
	int idemp=0;

	
Calendar calendar = Calendar.getInstance();  
calendar.setTime(strtdate);
int year = calendar.get(Calendar.YEAR);
int month = calendar.get(Calendar.MONTH) + 1;

Criteria cr=session.createCriteria(EmpWorkDetails.class);
Projection pr=Projections.property("idEmployees");
cr.setProjection(pr);
Common_list=cr.list();

	 if(!Group.isEmpty())
       {
		 
       	Query g=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in "
       			+ "(select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from Employees where idEmpType = (select idEmpType from Emptype  where name = :Group)))");
       	g.setParameter("Group", Group);
       	From_group=g.list();
       	Common_list.retainAll(From_group);
      		

       }
	 if(!Employee_Code.isEmpty())
       {
		 Employees emp=(Employees)employeeDAO.get(Employee_Code);
			idemp=emp.getIdEmployees();
				        	
       	from_employeecode.add(idemp);
       	Common_list.retainAll(from_employeecode);
      		

       }
	 else if(!Designation.isEmpty())
	 {
		 Designation ds=(Designation) designationDAO.get(Designation);
		 int iddes=ds.getIdDesignation();
		 Query d=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from EmpWorkDetails where idDesignation in (select idDesignation from Designation where name = :Designation))");
		 d.setParameter("Designation", Designation);
		 From_designation=d.list();;
		 Common_list.retainAll(From_designation);


	 }
	 else if(!Catagory.isEmpty())
       {
       	Query c=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from EmpWorkDetails where idDesignation in (select distinct idDesignation from Designation where idCatagory in(select idCatagory from catagory where name = :Catagory)))");
       	c.setParameter("Catagory", Catagory);
       	From_Category=c.list();
       	Common_list.retainAll(From_Category);


       }
	 else if(!Department.isEmpty())
{
		 Department dept = (Department) departmentDAO.get(Department);
			int idDept=dept.getIdDepartment();
			
	Query dept1=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from EmpWorkDetails where idDesignation in (select distinct idDesignation from Designation where idDepartment in(select idDepartment from Department where name =:Department)))");
	dept1.setParameter("Department", Department);
	From_dept=dept1.list();
	Common_list.retainAll(From_dept);


}
	
else
{
	
}
	 
	int noofemp=Common_list.size();
		
		float TotalWorkingHR=0.0f;
		float totalDayConverted=0.0f;
		float totalBasicSal=0.0f;
		float totalPaidLeaveSal=0.0f;
		int totalispaid=0;
		
while(!calendar.getTime().after(enddate))
	{
			
		Date date = calendar.getTime();
			 
	 
	 
		if(!Shift.isEmpty())
		{
	 		Shift e1=new Shift();
		  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("Name", Shift )).uniqueResult();
		   int idshift=e1.getIdShift();
		
		   Criteria a1=(Criteria) session.createCriteria(Attendance.class);
		   a1.add(Restrictions.eq("idShift", idshift));
		   a1.add(Restrictions.eq("Date", date));
		   Projection projection = Projections.property("idEmplyees"); 
		   a1.setProjection(projection); 
		   Shift_report=a1.list();
		 
		   Common_list.retainAll(Shift_report);
	   		
		}
		
		List present=this.BasicSalaryReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code);

	
		
		present_report.add(this.overtimeSalaryReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code));
		present_report.add(this.LeaveSalaryReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code));
		present_report.add(noofemp);
		present_report.add(TotalWorkingHR);
		present_report.add(totalDayConverted);
		present_report.add(totalBasicSal);
		present_report.add(totalispaid);
		present_report.add(totalPaidLeaveSal);
		
	}
session.close();

			return present_report;

}


 public List commonEmployees(String design,String dept,String catagory,String empcode) 
{
	
	Session s = (Session) hipernateConfg.getSession();
	
		String base = "SELECT Distinct emp.idEmployees FROM Employees AS emp";
		
		String bycatagory = " JOIN EmpWorkDetails AS ewd1 ON emp.idEmployees in"
	   		+ "(select idEmployees from EmpWorkDetails where idDesignation in"
	   		+ "(select idDesignation from Designation where idCatagory = "
	   		+ "(select idCatagory from Catagory where name = :Catg)))";
		
		String bydepartment = " JOIN EmpWorkDetails AS ewd2 ON emp.idEmployees in"
	   		+ "(select idEmployees from EmpWorkDetails where idDesignation in"
	   		+ "(select idDesignation from Designation where idDepartment = "
	   		+ "(select idDepartment from Department where name = :Dept)))";
		
		String bydesignation = " JOIN EmpWorkDetails AS ewd3 ON emp.idEmployees in"
	   		+ "(select idEmployees from EmpWorkDetails where idDesignation = "
	   		+ "(select idDesignation from Designation where name = :Design))";
		
		String byempcode = " JOIN EmpWorkDetails AS ewd4 ON emp.idEmployees in"
		   		+ "(select idEmployees from Employees where employeeCode = :EmpCode)";
		
		
		
		Query qx;
		if(!empcode.isEmpty()) 
		{
			base = base.concat(byempcode);
			
		}
		else if(!design.isEmpty()) 
		{
			base = base.concat(bydesignation);
		}
		else if(!catagory.isEmpty()) 
		{
			base = base.concat(bycatagory);	
		}
		else if(!dept.isEmpty()) 
		{	
			base = base.concat(bydepartment);
		}
		
		qx = s.createQuery(base);
		
		if(!empcode.isEmpty()) 
		{
			 qx.setParameter("EmpCode", String.valueOf(empcode));
		}
		else if(!design.isEmpty()) 
		{	
			 qx.setParameter("Design", design);
		}
		else if(!catagory.isEmpty()) 
		{
			 qx.setParameter("Catg", catagory);
		}
		else if(!dept.isEmpty()) 
		{
			qx.setParameter("Dept", dept);
		}
		
		List<Object[]> ax = qx.list();
		
		s.close();
	return ax;
}

 
 public List commonDesignation(String design,String dept,String catagory,String empcode) 
{
	
	Session s = (Session) hipernateConfg.getSession();
	/*
		String base = "SELECT Distinct des.idDesignation FROM Designation AS des";
		
		String byDepartment="JOIN Department AS ewd1 ON des.idDesignation in "
				+ "(Select idDesignation from Designation where idCatagory in "
				
				+ "(Select idCategory from Catagory where idDepartment in"
				+ "(Select idDepartment from Department where Name=:Department)))";
		
	String byCategory="JOIN Catagory AS ewd2 ON des.idDesignation in "
						+ "(Select idDesignation from Designation where idCatagory in "
						
						+ "(Select idCatagory from Catagory where Name=:Catagory))";
	
	
	String byDesignation="JOIN Designation AS ewd3 ON des.idDesignation in"
			+ "(Select idDesignation from Designation where Name =:Designation)";
		
		*/
	String base = "SELECT Distinct des.idDesignation FROM Designation AS des";
	
	String bycatagory = " JOIN EmpWorkDetails AS ewd1 ON des.idDesignation in"
   		+ "(select idDesignation from Designation where idCatagory = "
   		+ "(select idCatagory from Catagory where name = :Catg))";
	
	String bydepartment = " JOIN EmpWorkDetails AS ewd2 ON des.idDesignation in"
   		+ "(select idDesignation from Designation where idDepartment = "
   		+ "(select idDepartment from Department where name = :Dept))";
	
	String bydesignation = " JOIN EmpWorkDetails AS ewd3 ON des.idDesignation in"
   		+ "(select idDesignation from Designation where name = :Design)";
	
		Query qx;
		 if(!design.isEmpty()) 
		{
			base = base.concat(bydesignation);
		}
		else if(!catagory.isEmpty()) 
		{
			base = base.concat(bycatagory);	
		}
		else if(!dept.isEmpty()) 
		{	
			base = base.concat(bydepartment);
		}
		
		qx = s.createQuery(base);
		
		if(!design.isEmpty()) 
		{	
			 qx.setParameter("Design", design);
		}
		else if(!catagory.isEmpty()) 
		{
			 qx.setParameter("Catg", catagory);
		}
		else if(!dept.isEmpty()) 
		{
			qx.setParameter("Dept", dept);
		}
		
		List<Object[]> ax = qx.list();
		
		s.close();
		System.err.println(ax);
	

	return ax;
}
 
 public List WagesPresentbetDate(Date strtdate,Date endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	
 	Session session = (Session) hipernateConfg.getSession();  

 
 	List<Integer> Common_list=new ArrayList<Integer>();
 	List<Integer> Shift_report=new ArrayList<Integer>();
 	

 	 Calendar calendar = Calendar.getInstance();  
 	calendar.setTime(strtdate);
 Common_list=this.commonDesignation(Designation, Department, Catagory, Employee_Code);
 	
float TotalSalary=0.0f;

List finl=new ArrayList();

float totalSal=0.0f;
float totalHR=0.0f;
long totalcount=0;
String sft=null;
String desname="";
String catag="";
String emptypename="";
String dept="";
int month=calendar.get(calendar.MONTH);

while(!calendar.getTime().after(endDate))
{
	List present_report=new ArrayList();
	Date date = calendar.getTime();
 
 if(!Shift.isEmpty())
 {
   Shift e1=new Shift();
 	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
 	   int idshift=e1.getIdShift();
 	 
 	  Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date));
	   Projection p=Projections.property("idDesignation");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   
 }	
 Common_list.retainAll(Shift_report);
System.err.println("##########commonlist"+Common_list);
 for(int i=0;i<Common_list.size();i++)
 {
	 
	 int idDesignation=Common_list.get(i);
	
	 List<Object[]> info=new ArrayList<Object[]>();
	 List<Object[]> info1=new ArrayList<Object[]>();
	 List<Object[]> desinfo=new ArrayList<Object[]>();
	
	 Criteria cr=session.createCriteria(Designation.class);
	 cr.add(Restrictions.eq("idDesignation", idDesignation));
	 Projection b=Projections.property("name");
	 Projection b1=Projections.property("idDepartment");
	 Projection b2=Projections.property("salary");
	 Projection b3=Projections.property("idCatagory");
	 ProjectionList plList=Projections.projectionList();
	 plList.add(b);
	 plList.add(b1);
	 plList.add(b2);
	 plList.add(b3);
	 cr.setProjection(plList);
	 desinfo=cr.list();
	 
	 
	 desname=(String) desinfo.get(0)[0];
	 int idDept=(int) desinfo.get(0)[1];
	 float Salary=(float) desinfo.get(0)[2];
	 System.err.println(desname+" iddept"+idDept+" sal"+Salary);
	 totalSal=totalSal+Salary;
	 int idcat=(int) desinfo.get(0)[3];

	Criteria v=session.createCriteria(Catagory.class);
	v.add(Restrictions.eq("idCatagory", idcat));
	Projection l=Projections.property("name");
	v.setProjection(l);
	  catag=(String) v.uniqueResult();
	
	 Criteria y=session.createCriteria(Department.class);
		y.add(Restrictions.eq("idDepartment", idDept));
		Projection g=Projections.property("name");
		y.setProjection(g);
	  dept=(String) y.uniqueResult();
	 
	 Criteria crw=(Criteria) session.createCriteria(Attendance.class);
	   crw.add(Restrictions.eq("idDesignation", idDesignation));
	   crw.add(Restrictions.eq("date", date));
	   Projection projection1 = Projections.property("idEmployees"); 
	   Projection projection2 = Projections.property("idAttendance"); 
	   
     Projection projection3 = Projections.rowCount();
     Projection projection4 = Projections.property("idShift");
     
     ProjectionList pList = Projections.projectionList();
     pList.add(projection1);
     pList.add(projection2);
     pList.add(projection3);
     pList.add(projection4);
     crw.setProjection(pList);
     info=crw.list();
     int idEmployees=0;
		int idAttendance=0;
		long count=0;
		int idShift=0;
		int minutes =0; 
		int Hours =0;
		
   
		   
		  idEmployees=(int) info.get(0)[0];
		  idAttendance=(int) info.get(0)[1];
		  count=(long) info.get(0)[2];
		 totalcount=totalcount+count;
		 idShift=(int) info.get(0)[3];
		 
		 
		 Criteria c=session.createCriteria(Employees.class);
		 c.add(Restrictions.eq("idEmployees", idEmployees));
		 Projection gp=Projections.property("idEmpType");
		 c.setProjection(gp);
		 int idemptype=(int) c.uniqueResult();
		 
		 
		 Criteria cz=session.createCriteria(Emptype.class);
		 cz.add(Restrictions.eq("idEmpType", idemptype));
		 Projection gpz=Projections.property("name");
		 cz.setProjection(gpz);
		  emptypename=(String) cz.uniqueResult();
		 
		 
		 
		 
		 Query t=session.createQuery("SELECT  MINUTE(TIMEDIFF(outtime,intime )),Hour(TIMEDIFF(outtime,intime )) FROM Workhours where idAttendance = :idAttendance");
		 t.setParameter("idAttendance", idAttendance);
		 info1=t.list();
		 if(!info1.isEmpty())
		 {
		 minutes = (int) info1.get(0)[0];
		 Hours = (int) info1.get(0)[1];
		 }
		 
   Criteria as=session.createCriteria(Shift.class);
   as.add(Restrictions.eq("idShift", idShift));
   Projection ps=Projections.property("name");
   as.setProjection(ps);
   sft=(String) as.uniqueResult();

	 
	
		float HR=(float)(Float.parseFloat(String.valueOf(minutes))/60);
		float workhr=HR+Hours;
		totalHR=totalHR+workhr;
		 
		
 }


 calendar.add(Calendar.DATE, 1);
 present_report.add(date);
 present_report.add(sft);

 present_report.add(dept);
 present_report.add(catag);
 present_report.add(desname);
 present_report.add(totalcount);
 present_report.add(totalHR);
 present_report.add(totalSal);
 present_report.add(emptypename);

 finl.add(present_report);
	
 }


return finl;
 
 }
 public List WagesleavebetDate(Date strtdate,Date endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	
 	Session session = (Session) hipernateConfg.getSession();  

 
 	List<Integer> Common_list=new ArrayList<Integer>();
 	List<Integer> Shift_report=new ArrayList<Integer>();
 	int idemp=0;

 	 Calendar calendar = Calendar.getInstance();  
 	calendar.setTime(strtdate);
 Common_list=this.commonDesignation(Designation, Department, Catagory, Employee_Code);
 	
float TotalSalary=0.0f;
List pr=new ArrayList();
String emptypename="";

while(!calendar.getTime().after(endDate))
{
 	

	Date date = calendar.getTime();
 
 if(!Shift.isEmpty())
 {
   Shift e1=new Shift();
 	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
 	   int idshift=e1.getIdShift();
 	  Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date));
	   Projection p=Projections.property("idDesignation");
	   ca.setProjection(p);
	   Shift_report=ca.list();
 	   
 	   Common_list.retainAll(Shift_report);
 	   
 }	 
 float totalSal=0.0f;
 float totalHR=0.0f;
 long totalcount=0;
 for(int i=0;i<Common_list.size();i++)
 {
	 List present_report=new ArrayList();
	 Map abc=new HashMap<>();
	 int idDesignation=Common_list.get(i);
	 List<Object[]> info=new ArrayList<Object[]>();
	 List<Object[]> info1=new ArrayList<Object[]>();
	 List<Object[]> desinfo=new ArrayList<Object[]>();
	 Criteria cr=session.createCriteria(Designation.class);
	 cr.add(Restrictions.eq("idDesignation", idDesignation));
	 Projection b=Projections.property("name");
	 Projection b1=Projections.property("idDepartment");
	 Projection b2=Projections.property("salary");
	 Projection b3=Projections.property("idCatagory");
	 ProjectionList plList=Projections.projectionList();
	 plList.add(b);
	 plList.add(b1);
	 plList.add(b2);
	 plList.add(b3);
	 cr.setProjection(plList);
	 desinfo=cr.list();
	 String name=(String) desinfo.get(0)[0];
	 int idDept=(int) desinfo.get(0)[1];
	 float Salary=(float) desinfo.get(0)[2];
	
	 int idcat=(int) desinfo.get(0)[3];


	 
		Criteria v=session.createCriteria(Catagory.class);
		v.add(Restrictions.eq("idCatagory", idcat));
		Projection l=Projections.property("name");
		v.setProjection(l);
		  String catagory=(String) v.uniqueResult();
	 
			 Criteria y=session.createCriteria(Department.class);
				y.add(Restrictions.eq("idDepartment", idDept));
				Projection g=Projections.property("name");
				y.setProjection(g);
			 String department=(String) y.uniqueResult();
	 
		Criteria bn=session.createCriteria(Attendance.class);
		bn.add(Restrictions.eq("idDesignation", idDesignation));
		bn.add(Restrictions.eq("date", date));
		Projection q=Projections.property("idEmployees");
		Projection q1=Projections.property("idAttendance");
		Projection q2=Projections.rowCount();
		Projection q3=Projections.property("idShift");
		ProjectionList pl=Projections.projectionList();
		pl.add(q);
		pl.add(q1);
		pl.add(q2);
		pl.add(q3);
		bn.setProjection(pl);
		 info=bn.list();
		int idEmployees=0;
		int idAttendance=0;
		long count=0;
		int idShift=0;
	try {
	  idEmployees=(int) info.get(0)[0];
	  idAttendance=(int) info.get(0)[1];
	  count=(long) info.get(0)[2];
	
	  idShift=(int) info.get(0)[3];
	}
	
	catch(Exception ex)
	{
		
	}
	
	 Criteria c=session.createCriteria(Employees.class);
	 c.add(Restrictions.eq("idEmployees", idEmployees));
	 Projection gp=Projections.property("idEmpType");
	 c.setProjection(gp);
	 int idemptype=(int) c.uniqueResult();
	 
	 
	 Criteria cz=session.createCriteria(Emptype.class);
	 cz.add(Restrictions.eq("idEmpType", idemptype));
	 Projection gpz=Projections.property("name");
	 cz.setProjection(gpz);
	  emptypename=(String) cz.uniqueResult();
	 
	 Criteria as=session.createCriteria(Shift.class);
	   as.add(Restrictions.eq("idShift", idShift));
	   Projection ps=Projections.property("name");
	   as.setProjection(ps);
	   String shift=(String) as.uniqueResult();
	   int idlv=0;
	   int PaidLeaves=0;
	 try {
		 Criteria pr1=session.createCriteria(Empleave.class);
		 pr1.add(Restrictions.eq("idEmployees", idEmployees));
		 pr1.add(Restrictions.eq("date", date));
		 Projection s=Projections.property("idLeave");
		 pr1.setProjection(s);
		  idlv=(int) pr1.uniqueResult();
		  Criteria p=session.createCriteria(TblLeave.class);
			 p.add(Restrictions.eq("idLeave", idlv));
			
			 Projection sa=Projections.property("isPaid");
			 p.setProjection(sa);
			 PaidLeaves=(int) p.uniqueResult();
	 }
	 catch(Exception e)
	 {
		 
	 }
		
		
	float paidLeaveSal=PaidLeaves*Salary;
		 present_report.add(date);
		 present_report.add(shift);
		 
		 present_report.add(department);
		 present_report.add(catagory);
		 present_report.add(Designation);
		 present_report.add(PaidLeaves);
		 present_report.add(paidLeaveSal);
		 present_report.add(emptypename);
		 pr.add(present_report);
 }

 calendar.add(Calendar.DATE, 1);
	
 }
session.close();
return pr;
 
 }

 public List WagesTotalSalaryReportbetDates(Date strtdate,Date endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	Session session = (Session) hipernateConfg.getSession();  
 	 Calendar calendar = Calendar.getInstance();  
 	List<Integer> Common_list=new ArrayList<Integer>();
 	List filnlist=new ArrayList();
  	calendar.setTime(strtdate);
 	 List<List> present=new ArrayList<List>();
	 List<List> leave=new ArrayList<List>();
	 List<Object[]> Hours=new ArrayList<Object[]>();
	 float totalWorkhr=0.0f;
	 float totalDaycon=0.0f;
	 float totalSal=0.0f;
	 int TotalPaidlv=0;
	 float totalLvSal=0.0f;
	 long idempcount=0;
	 Common_list= this.commonDesignation(Designation, Department, Catagory, Employee_Code);
	
	 while(!calendar.getTime().after(endDate))
	 {
		 Date date = calendar.getTime();
		 
	 	
		 for(int i=0;i<Common_list.size();i++)
		 {
			 int idDesignation=Common_list.get(i);
			 float Salary=0.0f;
			 try {
			 Criteria sd=session.createCriteria(EmpWorkDetails.class);
			 sd.add(Restrictions.eq("idDesignation", idDesignation));
			 Projection d=Projections.max("hours");
			 Projection s=Projections.count("idEmployees");
			 ProjectionList plList=Projections.projectionList();
			 plList.add(d);
			 plList.add(s);
			 sd.setProjection(plList);
			  Hours=sd.list();
			 }
			 catch (Exception e) {
				// TODO: handle exception
			}
			  float hours=0.0f;
if(!Hours.isEmpty())
{
				   hours=(float) Hours.get(0)[0];
				   idempcount=(long) Hours.get(0)[1];
}				  
				
			 present=this.WagesPresentbetDate(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code);
			 leave=this.WagesleavebetDate(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code);

			 float workhr=Float.parseFloat(String.valueOf(present.get(0).get(6)));
			 totalWorkhr=totalWorkhr+workhr;
			 float dayconv=workhr/hours;
			 totalDaycon=totalDaycon+dayconv;
			 Salary=Float.parseFloat(String.valueOf(present.get(0).get(7)));
			 totalSal=totalSal+Salary;
			 int paidLeaves=Integer.parseInt(String.valueOf(leave.get(0).get(5)));
			 TotalPaidlv=TotalPaidlv+paidLeaves;
			 float paidLvSal=Float.parseFloat(String.valueOf(leave.get(0).get(6)));
			 totalLvSal=totalLvSal+paidLvSal;
			
		 }
		 calendar.add(Calendar.DATE, 1);
		 
		 
	 }
	 System.err.println("totalSal"+totalSal);
	 filnlist.add(idempcount);
	 filnlist.add(totalWorkhr);
	 filnlist.add(totalDaycon);
	 filnlist.add(totalSal);
	 filnlist.add(TotalPaidlv);
	 filnlist.add(totalLvSal);
		session.close();

	 return filnlist;
 } 
 
 
 public wagesDateBtwn Wagesdatebetweenreport(String strtdate1,String endDate1,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	
 	List<wagesDateBtwn> wagesdayfilter=new ArrayList<wagesDateBtwn>(); 
 	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	Date strtdate = sdf.parse(String.valueOf(strtdate1));
	Date endDate = sdf.parse(String.valueOf(endDate1));
 	wagesDateBtwn WDfilter = new wagesDateBtwn();
 	WDfilter.setPresent(this.WagesPresentbetDate(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
 	WDfilter.setLeave(this.WagesleavebetDate(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
 	WDfilter.setTotal(this.WagesTotalSalaryReportbetDates(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
 	return WDfilter;
 	
 }

 
 public List WagesTotalSalaryReportbetmonths(Date strtmonth,Date endmonth,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	Session session = (Session) hipernateConfg.getSession();  
 	 Calendar calendar = Calendar.getInstance();  
 	List<Integer> Common_list=new ArrayList<Integer>();
 	List filnlist=new ArrayList();
 	Date fd=strtmonth;
 	Date ld=endmonth;
 	 List present=new ArrayList();
	 List<Object[]> leave=new ArrayList<Object[]>();
	 List<Object[]> Hours=new ArrayList<Object[]>();
	 float totalWorkhr=0.0f;
	 float totalDaycon=0.0f;
	 float totalSal=0.0f;
	 int TotalPaidlv=0;
	 float totalLvSal=0.0f;
	 long idempcount=0;
	 int paidLeaves=0;
	 float paidLvSal=0.0f;
	 float hours=0.0f;
	 Common_list= this.commonDesignation(Designation, Department, Catagory, Employee_Code);
	
	 calendar.setTime(fd);
	 

	 float workhr=0.0f;
	 present=this.WagesPresentbetmonth1(strtmonth, endmonth, Group, Department, Catagory, Designation, Shift, Employee_Code);

     float basic1=(float) present.get(7);
     totalSal=totalSal+basic1;
      workhr=(float) present.get(6);
     totalWorkhr=totalWorkhr+workhr;
	 while(!calendar.getTime().after(ld))
	 {
	 
		 
		 
		 
		 Date date = calendar.getTime();
		 
		
		 for(int i=0;i<Common_list.size();i++)
		 {
			 int idDesignation=Common_list.get(i);
			 float Salary=0.0f;
			 
			 Criteria sd=session.createCriteria(EmpWorkDetails.class);
			 sd.add(Restrictions.eq("idDesignation", idDesignation));
			 Projection d=Projections.max("hours");
			 Projection s=Projections.count("idEmployees");
			 ProjectionList plList=Projections.projectionList();
			 plList.add(d);
			 plList.add(s);
			 sd.setProjection(plList);
			  Hours=sd.list();
			 hours=(float) Hours.get(0)[0];
			idempcount=(long) Hours.get(0)[1];
			
			
			try {
			 present=this.WagesPresentbetDate(date, date, Group, Department, Catagory, Designation, Shift, Employee_Code);
			 leave=this.WagesleavebetDate(date, date, Group, Department, Catagory, Designation, Shift, Employee_Code);
			
			
			// workhr=Float.parseFloat(String.valueOf(present.get(0).get(6)));
			// Salary=Float.parseFloat(String.valueOf(present.get(0).get(7)));
			 paidLeaves=Integer.parseInt(String.valueOf(leave.get(5)));
			 paidLvSal=Float.parseFloat(String.valueOf(leave.get(6)));
			
			}
			catch(Exception ex)
			{
				
			}
			
		
			
			
			
			
			
		 }
		 calendar.add(Calendar.DATE, 1);
		 
		
	 }
	 float dayconv=workhr/hours;
	 totalDaycon=totalDaycon+dayconv;
	
	 TotalPaidlv=TotalPaidlv+paidLeaves;
		
	 totalLvSal=totalLvSal+paidLvSal;
	
	
	 filnlist.add(idempcount);
	 filnlist.add(totalWorkhr);
	 filnlist.add(totalDaycon);
	 filnlist.add(totalSal);
	 filnlist.add(TotalPaidlv);
	 filnlist.add(totalLvSal);
		session.close();

	 return filnlist;
 } 
 
 
 
 
 
 public List WagesPresentbetmonth1(Date strtdate,Date endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	
 	Session session = (Session) hipernateConfg.getSession();  

 System.err.println("sstrtdate "+strtdate+"\n enddate"+endDate);
 	List Common_list=new ArrayList();
 	List Shift_report=new ArrayList();
	List fnl=new ArrayList();
 	int idemp=0;

 	 Calendar calendar = Calendar.getInstance();  
 	calendar.setTime(strtdate);
 Common_list=this.commonDesignation(Designation, Department, Catagory, Employee_Code);
 	
float TotalSalary=0.0f;


int month=calendar.get(calendar.MONTH)+1;
String shift=null;

String department=null;
String catagory=null;
String Designation1=null;
String emptypename="";
float totalSal=0.0f;
float totalHR=0.0f;
long totalcount=0;
List present_report=new ArrayList();
while(!calendar.getTime().after(endDate))
{
	

	Date date = calendar.getTime();
 
 if(!Shift.isEmpty())
 {
	
   Shift e1=new Shift();
 	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
 	   int idshift=e1.getIdShift();
 	  
  	  Criteria ca=session.createCriteria(Attendance.class);
 	   ca.add(Restrictions.eq("idShift", idshift));
 	   ca.add(Restrictions.eq("date", date));
 	   Projection p=Projections.property("idDesignation");
 	   ca.setProjection(p);
 	   Shift_report=ca.list();
 	   Common_list.retainAll(Shift_report);
 	   
 }	 
 
 for(int i=0;i<Common_list.size();i++)
 {
	
	 int idDesignation=(int) Common_list.get(i);
	 List<Object[]> info=new ArrayList<Object[]>();
	 List<Object[]> info1=new ArrayList<Object[]>();
	 List<Object[]> desinfo=new ArrayList<Object[]>();
	 Criteria cr=session.createCriteria(Designation.class);
	 cr.add(Restrictions.eq("idDesignation", idDesignation));
	 Projection b=Projections.property("name");
	 Projection b1=Projections.property("idDepartment");
	 Projection b2=Projections.property("salary");
	 Projection b3=Projections.property("idCatagory");
	 ProjectionList plList=Projections.projectionList();
	 plList.add(b);
	 plList.add(b1);
	 plList.add(b2);
	 plList.add(b3);
	 cr.setProjection(plList);
	 desinfo=cr.list();
	 Designation1=(String) desinfo.get(0)[0];
	 int idDept=(int) desinfo.get(0)[1];
	 float Salary=(float) desinfo.get(0)[2];
	
	 int idcat=(int) desinfo.get(0)[3];
	

		Criteria v=session.createCriteria(Catagory.class);
		v.add(Restrictions.eq("idCatagory", idcat));
		Projection l=Projections.property("name");
		v.setProjection(l);
		  catagory=(String) v.uniqueResult();
	 
			 Criteria y=session.createCriteria(Department.class);
				y.add(Restrictions.eq("idDepartment", idDept));
				Projection g=Projections.property("name");
				y.setProjection(g);
			  department=(String) y.uniqueResult();
	
//	 Query q=session.createQuery("SELECT Distinct idEmployees,idAttendance,count(*),idShift FROM Attendance where idDesignation = :iddes and Date =:dt");
	 
	 Criteria crd=(Criteria) session.createCriteria(Attendance.class);
	   crd.add(Restrictions.eq("idDesignation", idDesignation));
	   crd.add(Restrictions.eq("date", date));
	   Projection projection1 = Projections.property("idEmployees"); 
	   Projection projection2 = Projections.property("idAttendance"); 
	   
       Projection projection3 = Projections.rowCount();
       Projection projection4 = Projections.property("idShift");
       
       ProjectionList pList = Projections.projectionList();
       pList.add(projection1);
       pList.add(projection2);
       pList.add(projection3);
       pList.add(projection4);
       crd.setProjection(pList);
       
	   info=crd.list();
	   int idEmployees=0;
		int idAttendance=0;
		long count=0;
		int idShift=0;
		int minutes =0;
		int Hours = 0;
		try {
	   
		  idEmployees=(int) info.get(0)[0];
		  idAttendance=(int) info.get(0)[1];
		  count=(long) info.get(0)[2];
		 totalcount=totalcount+count;
		  idShift=(int) info.get(0)[3];
			 
			 Criteria c=session.createCriteria(Employees.class);
			 c.add(Restrictions.eq("idEmployees", idEmployees));
			 Projection gp=Projections.property("idEmpType");
			 c.setProjection(gp);
			 int idemptype=(int) c.uniqueResult();
			 
			 
			 Criteria cz=session.createCriteria(Emptype.class);
			 cz.add(Restrictions.eq("idEmpType", idemptype));
			 Projection gpz=Projections.property("name");
			 cz.setProjection(gpz);
			  emptypename=(String) cz.uniqueResult();
			 
			 
		  Query t=session.createQuery("SELECT  MINUTE(TIMEDIFF(Outtime,Intime )),Hour(TIMEDIFF(Outtime,Intime )) FROM Workhours where idAttendance = :idAttendance");
			 t.setParameter("idAttendance", idAttendance);
			 info1=t.list();
			  minutes = (int) info1.get(0)[0];
				 Hours = (int) info1.get(0)[1];
		}
		catch(Exception ex)
		{
			
		}
		
		 Query m=session.createQuery("select name from Shift where idShift = :idShift");
		 m.setParameter("idShift", idShift);
		  shift=(String) m.uniqueResult();
		  totalSal=totalcount*Salary;
		float HR=(float)(Float.parseFloat(String.valueOf(minutes))/60);
		float workhr=HR+Hours;
		totalHR=totalHR+workhr;
		
		
 }
 
 calendar.add(Calendar.DATE, 1);

 }

	present_report.add(month);
	present_report.add(shift);

	present_report.add(department);
	present_report.add(catagory);
	present_report.add(Designation1);
	present_report.add(totalcount);
	present_report.add(totalHR);
	present_report.add(totalSal);
	present_report.add(emptypename);
	
session.close();

return present_report;
 
 }
 public List Wagesleavebetmonth1(Date strtdate,Date endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
 	
 	Session session = (Session) hipernateConfg.getSession();  

 
 	List<Integer> Common_list=new ArrayList<Integer>();
 	List<Integer> Shift_report=new ArrayList<Integer>();
 	int idemp=0;

 	 Calendar calendar = Calendar.getInstance();  
 	calendar.setTime(strtdate);
 	int month=calendar.get(calendar.MONTH)+1;
 Common_list=this.commonDesignation(Designation, Department, Catagory, Employee_Code);
 	
float TotalSalary=0.0f;
List present_report=new ArrayList();
String shift=null;
String department=null;
String catagory=null;
String emptypename="";
String lvtype="";
String Designation1=null;
float totalSal=0.0f;
float totalHR=0.0f;
long totalcount=0;
int PaidLeaves=0;
float Salary=0.0f;
while(!calendar.getTime().after(endDate))
{
 	
	Date date = calendar.getTime();
 
 if(!Shift.isEmpty())
 {
   Shift e1=new Shift();
 	  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("Name", Shift )).uniqueResult();
 	   int idshift=e1.getIdShift();
  	  Criteria ca=session.createCriteria(Attendance.class);
 	   ca.add(Restrictions.eq("idShift", idshift));
 	   ca.add(Restrictions.eq("date", date));
 	   Projection p=Projections.property("idDesignation");
 	   ca.setProjection(p);
 	   Shift_report=ca.list();
 	   Common_list.retainAll(Shift_report);
 	   
 }	 

 for(int i=0;i<Common_list.size();i++)
 {
	 int idDesignation=Common_list.get(i);
	 List<Object[]> info=new ArrayList<Object[]>();
	 List<Object[]> info1=new ArrayList<Object[]>();
	 List<Object[]> desinfo=new ArrayList<Object[]>();
	 Criteria cr=session.createCriteria(Designation.class);
	 cr.add(Restrictions.eq("idDesignation", idDesignation));
	 Projection b=Projections.property("name");
	 Projection b1=Projections.property("idDepartment");
	 Projection b2=Projections.property("salary");
	 Projection b3=Projections.property("idCatagory");
	 ProjectionList plList=Projections.projectionList();
	 plList.add(b);
	 plList.add(b1);
	 plList.add(b2);
	 plList.add(b3);
	 cr.setProjection(plList);
	 desinfo=cr.list();
	  Designation1=(String) desinfo.get(0)[0];
	 int idDept=(int) desinfo.get(0)[1];
	  Salary=(float) desinfo.get(0)[2];
	
	 int idcat=(int) desinfo.get(0)[3];
	
		Criteria v=session.createCriteria(Catagory.class);
		v.add(Restrictions.eq("idCatagory", idcat));
		Projection l=Projections.property("name");
		v.setProjection(l);
		  catagory=(String) v.uniqueResult();
	 
			 Criteria y=session.createCriteria(Department.class);
				y.add(Restrictions.eq("idDepartment", idDept));
				Projection g=Projections.property("name");
				y.setProjection(g);
			  department=(String) y.uniqueResult();
	 
	  Criteria crs=(Criteria) session.createCriteria(Attendance.class);
	   crs.add(Restrictions.eq("idDesignation", idDesignation));
	   crs.add(Restrictions.eq("date", date));
	   Projection projection1 = Projections.property("idEmployees"); 
	   Projection projection2 = Projections.property("idAttendance"); 
	   
      Projection projection3 = Projections.rowCount();
      Projection projection4 = Projections.property("idShift");
      
      ProjectionList pList = Projections.projectionList();
      pList.add(projection1);
      pList.add(projection2);
      pList.add(projection3);
      pList.add(projection4);
      crs.setProjection(pList);
      
	   info=crs.list();
	   int idEmployees=0;
	   int idAttendance=0;
	   long count=0;
	   int idShift=0;
	 try {
	  idEmployees=(int) info.get(0)[0];
	  idAttendance=(int) info.get(0)[1];
	  count=(long) info.get(0)[2];
	
	  idShift=(int) info.get(0)[3];
	  
	  Criteria c=session.createCriteria(Employees.class);
		 c.add(Restrictions.eq("idEmployees", idEmployees));
		 Projection gp=Projections.property("idEmpType");
		 c.setProjection(gp);
		 int idemptype=(int) c.uniqueResult();
		 
		 
		 Criteria cz=session.createCriteria(Emptype.class);
		 cz.add(Restrictions.eq("idEmpType", idemptype));
		 Projection gpz=Projections.property("name");
		 cz.setProjection(gpz);
		  emptypename=(String) cz.uniqueResult();
	 }
	 catch(NullPointerException ex)
	 {
		 
	 }
	 System.err.println("idEmployees= "+idEmployees);
	 
	
	 
	 
	   Criteria as=session.createCriteria(Shift.class);
	   as.add(Restrictions.eq("idShift", idShift));
	   Projection ps=Projections.property("name");
	   as.setProjection(ps);
	   shift=(String) as.uniqueResult();

	 try {
		 Criteria pr=session.createCriteria(Empleave.class);
		 pr.add(Restrictions.eq("idEmployees", idEmployees));
		 pr.add(Restrictions.eq("date", date));
		 Projection s=Projections.property("idLeave");
		 pr.setProjection(s);
		 int idlv=(int) pr.uniqueResult();
		 
		 Criteria p=session.createCriteria(TblLeave.class);
		 p.add(Restrictions.eq("idLeave", idlv));
		
		 Projection sa=Projections.property("isPaid");
		 p.setProjection(sa);
		 PaidLeaves=(int) p.uniqueResult();
		 Criteria pq=session.createCriteria(TblLeave.class);
		 pq.add(Restrictions.eq("idLeave", idlv));
		
		 Projection saq=Projections.property("name");
		 pq.setProjection(saq);
		 lvtype=(String) pq.uniqueResult();

	 }
	 catch(NullPointerException ex)
	 {
	
	 }
	  /*
	    Criteria cr=(Criteria) session.createCriteria(TblLeave.class);
	   cr.add(Restrictions.eq("idEmployees", idEmployees));
	   cr.add(Restrictions.eq("date", date));
	  
	  Projection projection = Projections.property("isPaid");
      
      ProjectionList pList = Projections.projectionList();

      pList.add(projection);
      cr.setProjection(pList);
      
      PaidLeaves=(int) cr.uniqueResult();
	   */
	float paidLeaveSal=PaidLeaves*Salary;
		
 }


 
 calendar.add(Calendar.DATE, 1);

 }
float paidLeaveSal=PaidLeaves*Salary;
present_report.add(month);
present_report.add(shift);

present_report.add(department);
present_report.add(catagory);
present_report.add(Designation);
present_report.add(PaidLeaves);
present_report.add(paidLeaveSal);
present_report.add(lvtype);
present_report.add(emptypename);
session.close();


return present_report;
 
 }
 
 
 
 public wagesBetMonths Totalsalfilterreport(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {
	// Calendar calendar = Calendar.getInstance();  
	// calendar.setTime(strtdate);
	 wagesBetMonths wb=new wagesBetMonths();
	 
	 
	Calendar gcal = new GregorianCalendar();
	
	
	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
	 Date start = sdf.parse(strtdate);
	 
	 
	 Date end = sdf.parse(endDate);
	  gcal.setTime(end);
	  int month1=gcal.get(gcal.MONTH);
	     int year1=gcal.get(gcal.YEAR);
	     gcal.set(year1, month1, gcal.getActualMaximum(Calendar.DAY_OF_MONTH));
	  Date end1=gcal.getTime();
	 gcal.setTime(start);
	long totnoofemp=0;
	float totalWH=0.0f;
	float totdaycon=0.0f;
	float totbasic=0.0f;
	int totpaidlv=0;
	float totlvsal=0.0f;
	 List total=new ArrayList();
	List finl=new ArrayList();
	List lvfinl=new ArrayList();

	while (!gcal.getTime().after(end1)) {
		 List totalsalmonth=new ArrayList();
		
	     Date d = gcal.getTime();
	     int month=gcal.get(gcal.MONTH);
	     int year=gcal.get(gcal.YEAR);
	     gcal.set(year, month, 1);
	     List present1=new ArrayList();
		 List pres=new ArrayList();
	
	     Date firstdate=gcal.getTime();
	  
	     gcal.add(Calendar.MONTH, 1);  
	     gcal.set(Calendar.DAY_OF_MONTH, 1);  
	     gcal.add(Calendar.DATE, -1); 
	     Date lstDate=gcal.getTime();

	     present1=(this.WagesPresentbetmonth1(firstdate, lstDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	     pres=(this.Wagesleavebetmonth1(firstdate, lstDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	 
	     totalsalmonth=this.WagesTotalSalaryReportbetmonths(firstdate, lstDate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	   
	     long noofemp=(long) totalsalmonth.get(0);
	     totnoofemp=totnoofemp+noofemp;
	     float workHR=(float) totalsalmonth.get(1);
	     totalWH=totalWH+workHR;
	     float daycon=(float) totalsalmonth.get(2);
	     totdaycon=totdaycon+daycon;
	     float basic=(float) totalsalmonth.get(3);
	     totbasic=totbasic+basic;
	    
	     int paidlv=(int) totalsalmonth.get(4);
	     totpaidlv=totpaidlv+paidlv;
	     float lvsal=(float) totalsalmonth.get(5);
	     totlvsal=totlvsal+lvsal;
	     finl.add(present1);
	     lvfinl.add(pres);
	     
	     gcal.add(Calendar.MONTH, 1);
	 }
	  wb.setPresent(finl);
	  wb.setLeave(lvfinl);
	 total.add(totnoofemp);
     total.add(totalWH);
     total.add(totdaycon);
     total.add(totbasic);
     total.add(totpaidlv);
     total.add(totlvsal);
   
	 wb.setTotal(total);

	return wb;
	 
 }
 
 
 
 
 
 
 
 
 //salary report on filter******************************************
 public List SalaryReportfilter(String date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
	{
	 
	 
		Session session = (Session) hipernateConfg.getSession();  

		String str[] = date.split("-");
	 	int year = Integer.parseInt(str[0]);
	 	int month = Integer.parseInt(str[1]);
		
		
		
		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
		 
		List<Map> MainTablePerDay=new ArrayList<Map>();
		Map Designation_Days=new HashMap();
		List commonlist=new ArrayList();
		commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
		int noofemp=commonlist.size();
	 List<Object> Totalsal=new ArrayList<Object>();
	 List<List> finl=new ArrayList<List>();
	 
	for(int i=0;i<commonlist.size();i++)
	{
		List Salary=new ArrayList();
		//List<Object[]> bonnus=new ArrayList<Object[]>();
		int idEmployees=(int) commonlist.get(i);
		
		String group="";
		String Design="";
		String catag="";
		String dept="";
		try {
	
		List<Object[]> present_report=new ArrayList<Object[]>();
		Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
				+ "cat.name as Catagory, dept.name as Department  "
				+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
				"	  		 where  " + 
				"	  		 emp.idEmployees in :idEmployees " + 
				"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
				"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
				"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
				"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

			r.setParameter("idEmployees", idEmployees);
			
			present_report=r.list();
			 group=(String) present_report.get(0)[0];
			 Design=(String) present_report.get(0)[1];
			 catag=(String) present_report.get(0)[2];
			 dept=(String) present_report.get(0)[3];
		}
		catch(Exception e)
		{
			
		}
			Criteria a=session.createCriteria(Employees.class);
			a.add(Restrictions.eq("idEmployees", idEmployees));
			Projection p=Projections.property("employeeCode");
			a.setProjection(p);
			String empcode=(String) a.uniqueResult();
		Map Info=new HashMap();
		Info=bsdao.info(empcode);//Emp_id& Emp_Name
		String EmpName=(String) Info.get("EmployeeName");
	
		
		float PaidSalLeavs=bsdao.paidLeaveSal(empcode, month, year);
		
		
		
		
		List<Object[]> ern=new ArrayList<Object[]>();
		Criteria x=session.createCriteria(Salary.class);
		x.add(Restrictions.eq("idEmployees", idEmployees));
		x.add(Restrictions.eq("month", month));
		x.add(Restrictions.eq("year", year));
		Projection f=Projections.property("idSalary");
		Projection f1=Projections.property("totalEarning");
		Projection f2=Projections.property("totalDeduction");
		Projection f3=Projections.property("netSalary");
		ProjectionList pl=Projections.projectionList();
		pl.add(f);
		pl.add(f1);
		pl.add(f2);
		pl.add(f3);
		x.setProjection(pl);
		ern=x.list();
		int idsal=0;
		float totalErn=0;
		double totalded=0;
		double netpay=0;
		
	try {
		 idsal=(int) ern.get(0)[0];
		 totalErn=(float) ern.get(0)[1];
		 totalded=(double) ern.get(0)[2];
		 netpay=(double) ern.get(0)[3];
		 
	}
	catch(Exception e)
	{
		
	}
		float incentive=0.0f;
		float ThirdShift=0.0f;
		float mOvertime=0.0f;
		float BasicSalary=0.0f;
		float other=0.0f;
		String Shiftname="";
try {
	
	Criteria x1=session.createCriteria(SalaryEarning.class);
	x1.add(Restrictions.eq("idSalary", idsal));
	x1.add(Restrictions.eq("earningType", "Basic"));
	Projection pm=Projections.property("earningAmount");
	x1.setProjection(pm);
	BasicSalary=(float) x1.uniqueResult();

	
	Criteria xa1=session.createCriteria(SalaryEarning.class);
	xa1.add(Restrictions.eq("idSalary", idsal));
	xa1.add(Restrictions.eq("earningType", "Incentive"));
	Projection pam=Projections.property("earningAmount");
	xa1.setProjection(pam);
	incentive=(float) xa1.uniqueResult();

	Criteria xa12=session.createCriteria(SalaryEarning.class);
	xa12.add(Restrictions.eq("idSalary", idsal));
	xa12.add(Restrictions.eq("earningType", "Third Shift Allownce"));
	Projection pam2=Projections.property("earningAmount");
	xa12.setProjection(pam2);
	ThirdShift=(float) xa12.uniqueResult();
	
	Criteria xa2=session.createCriteria(SalaryEarning.class);
	xa2.add(Restrictions.eq("idSalary", idsal));
	xa2.add(Restrictions.eq("earningType", "Overtime"));
	Projection pm2=Projections.property("earningAmount");
	xa2.setProjection(pm2);
	mOvertime=(float) xa2.uniqueResult();
	
	
	 Criteria x11=session.createCriteria(EmpWorkDetails.class);
		x11.add(Restrictions.eq("idEmployees", idEmployees));

		Projection f11=Projections.property("idShift");
		x11.setProjection(f11);
		int idshift=(int) x11.uniqueResult();
	
		Criteria x111=session.createCriteria(Shift.class);
		x111.add(Restrictions.eq("idShift", idshift));

		Projection f112=Projections.property("name");
		x111.setProjection(f112);
		 Shiftname=(String) x111.uniqueResult();
	
	}
	catch(NullPointerException ex)
	{
		
		incentive=0.0f;
		 ThirdShift=0.0f;
		 mOvertime=0.0f;
		
	}
		float totalEarn=BasicSalary+incentive+ThirdShift+mOvertime;

		float pf=0.0f;
	
		float pt=0.0f;
	
		float esi=0.0f;
	try {
		Criteria x1=session.createCriteria(SalaryDeduction.class);
		x1.add(Restrictions.eq("idSalary", idsal));
		x1.add(Restrictions.eq("deductionType", "PF"));
		Projection pm=Projections.property("deductionAmount");
		x1.setProjection(pm);
		pf=(float) x1.uniqueResult();

		
		Criteria y8=session.createCriteria(SalaryDeduction.class);
		y8.add(Restrictions.eq("idSalary", idsal));
		y8.add(Restrictions.eq("deductionType", "PT"));
		Projection m=Projections.property("deductionAmount");
		y8.setProjection(m);
		pt=(float) y8.uniqueResult();

		
		Criteria y18=session.createCriteria(SalaryDeduction.class);
		y18.add(Restrictions.eq("idSalary", idsal));
		y18.add(Restrictions.eq("deductionType", "ESI"));
		Projection m1=Projections.property("deductionAmount");
		y18.setProjection(m1);
		esi=(float) y18.uniqueResult();
		
		Criteria y18s=session.createCriteria(SalaryDeduction.class);
		y18s.add(Restrictions.eq("idSalary", idsal));
		y18s.add(Restrictions.eq("deductionType", "Other"));
		Projection m1s=Projections.property("deductionAmount");
		y18s.setProjection(m1s);
		other=(float) y18s.uniqueResult();
	}
	catch(NullPointerException e)
	{
		
	}
	
	float AllTaxDeductions=pf+pt+esi;
	
	float LeavHRsal=bsdao.LeaveHR(empcode, month, year);
	
	double Alldeduction=ODdao.AllDeduction(empcode, month, year);
	
	float welfare=ESdao.Welfare(empcode, month);
	
	double TotalDeduction=Alldeduction+AllTaxDeductions+welfare;
	
	double NetPay=totalEarn+LeavHRsal-TotalDeduction;
	Salary.add(group);
	Salary.add(Design);
	Salary.add(catag);
	Salary.add(Shiftname);
	Salary.add(dept);
	Salary.add(EmpName);
	Salary.add(empcode);
	Salary.add(BasicSalary);
	Salary.add(mOvertime);
	Salary.add(incentive);
	Salary.add(ThirdShift);
	Salary.add(totalEarn);
	Salary.add(pf);
	Salary.add(pt);
	Salary.add(esi);
	Salary.add(TotalDeduction);
	Salary.add(NetPay);
	Salary.add(other);

	 
	  //bonnus.add(Salary);
	  finl.add(Salary);
	}
	

	
	session.close();

		return finl;
		
	}
	
 
 
 
 
 
 
 public List TotalSalaryReportfilter(String date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
	{
		Session session = (Session) hipernateConfg.getSession();  
	 List<Object> Totalsal=new ArrayList<Object>();
	 List<List> finl=new ArrayList<List>();
	 float totalbasic=0.0f;
	 float totalovrAmount=0.0f;
	 float totalincentive=0.0f;
	 float totalAllownce=0.0f;
	 float totalern=0.0f;
	 float totalpf=0.0f;
	 float totalpt=0.0f;
	 float totalesi=0.0f;
	 double totaldeduction=0.0f;
	 double totalnetpay=0.0f;
	 float totalother=0.0f;
	 
	 
	
	
	 List commonlist=new ArrayList();
		commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
		 int noofemp=commonlist.size();
		for(int i=0;i<commonlist.size();i++)
	 {
			int idemp=(int) commonlist.get(i);
			
		Criteria cs=session.createCriteria(Employees.class);
		cs.add(Restrictions.eq("idEmployees", idemp));
		Projection pd=Projections.property("employeeCode");
		cs.setProjection(pd);
		Employee_Code=(String) cs.uniqueResult();
				
			 finl=this.SalaryReportfilter(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	 float BasicSalary=(float) finl.get(0).get(7);
	 float mOvertime=(float) finl.get(0).get(8);
	 float incentive=(float) finl.get(0).get(9);
	 float ThirdShift=(float) finl.get(0).get(10);
	 float totalEarn=(float) finl.get(0).get(11);
	 float pf=(float) finl.get(0).get(12);
	 float pt=(float) finl.get(0).get(13);
	 float esi=(float) finl.get(0).get(14);
	 double TotalDeduction=(double) finl.get(0).get(15);
	 double NetPay=(double) finl.get(0).get(16);
	 float other=(float) finl.get(0).get(17);
	 
	
		 totalbasic=totalbasic+BasicSalary;
		  totalovrAmount=totalovrAmount+mOvertime;
		  totalincentive=totalincentive+incentive;
		  totalAllownce=totalAllownce+ThirdShift;
		  totalern=totalern+totalEarn;
		  totalpf=totalpf+pf;
		  totalpt=totalpt+pt;
		  totalesi=totalesi+esi;
		  totalother=totalother+other;
		  totaldeduction=totaldeduction+TotalDeduction;
		  totalnetpay=totalnetpay+NetPay;
	 }  
		  
			Totalsal.add(noofemp);
			Totalsal.add(totalbasic);
			Totalsal.add(totalovrAmount);
			Totalsal.add(totalincentive);
			Totalsal.add(totalAllownce);
			Totalsal.add(totalern);
			Totalsal.add(totalpf);
			Totalsal.add(totalpt);
			Totalsal.add(totalesi);
			Totalsal.add(totalother);
			Totalsal.add(totaldeduction);
			Totalsal.add(totalnetpay);
			
		  return Totalsal;
	}
 
 
 
 public salaryFilterMonth SalaryReportfilter1(String date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
	{
	 
	 salaryFilterMonth sfm=new salaryFilterMonth();
	 sfm.setPresent(this.SalaryReportfilter(date, Group, Department, Catagory, Designation, Shift, Employee_Code));
	sfm.setTotal(this.TotalSalaryReportfilter(date, Group, Department, Catagory, Designation, Shift, Employee_Code));	
	 
	 
	 return sfm;
	 
	}
 public List presentbonusfilter(String year,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
 {
	 Session session = (Session) hipernateConfg.getSession();  
	 List<Object[]> months1=new ArrayList<Object[]>();
		
		List commonlist=new ArrayList();
	
		commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);


	List tBonus=new ArrayList();
	
	for(int i=0;i<commonlist.size();i++)
	{
		Map Bonus1=new HashMap();
		List<Object[]> bonus=new ArrayList<Object[]>(); 
		int idEmployees=(int) commonlist.get(i);
		float Bonus=0.0f;
	
		List<Object[]> present_report=new ArrayList<Object[]>();
		Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
				+ "cat.name as Catagory, dept.name as Department  "
				+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
				"	  		 where  " + 
				"	  		 emp.idEmployees in :idEmployees " + 
				"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
				"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
				"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
				"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

			r.setParameter("idEmployees", idEmployees);
			
			present_report=r.list();
			if(!present_report.isEmpty())
			{
			String group=(String) present_report.get(0)[0];
			String Design=(String) present_report.get(0)[1];
			String catag=(String) present_report.get(0)[2];
			String dept=(String) present_report.get(0)[3];
			Criteria a=session.createCriteria(Employees.class);
			a.add(Restrictions.eq("idEmployees", idEmployees));
			Projection p9=Projections.property("employeeCode");
			a.setProjection(p9);
			String empcode=(String) a.uniqueResult();
			Criteria cr=session.createCriteria(BonusSetting.class);
			Projection p0=Projections.property("startmonth");
			Projection p1=Projections.property("endmonth");
			Projection pa=Projections.distinct(p0);
		
			ProjectionList ps=Projections.projectionList();
			ps.add(pa);
			ps.add(p1);
			cr.setProjection(ps);
			months1=cr.list();
				int Month1 =(int) months1.get(0)[0];
				int Month2=(int) months1.get(0)[1];
			
				int day=1;
				String years[]=year.split("-");
				int year1=Integer.valueOf(years[0]);
			
				int year2=Integer.valueOf(years[1]);
				
				Calendar calendar = Calendar.getInstance();  
		        calendar.set(year1,Month1,day);  
		        Date fd1 = calendar.getTime();
		        day=calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		        calendar.set(year2,Month2,day);  
		        Date ld1 = calendar.getTime();

		        List Empid=new ArrayList();
		        List<Map<String,Object>> months=new ArrayList<Map<String,Object>>();
		        List<Map<String,Object>> AllBonus=new ArrayList<Map<String,Object>>();
		    	Empid= bsdao.Empid();
		    	int loop=12;
		    
		    		calendar.set(year1,Month1,day); 
		    		 
		    		for(int p=0;p<=loop;p++)
		    		{
		    			Map MandY=new HashMap();
		    			int m = calendar.get(Calendar.MONTH);
		    			int y = calendar.get(Calendar.YEAR);
		    			MandY.put("Month", m);
		    			MandY.put("Year", y);
		    			months.add(MandY);
		    			calendar.add(Calendar.MONTH,1);
		    		}
		    	
		    		Map Info=new HashMap();
		    		List<Object[]> BonusSetting=new ArrayList<Object[]>();
		    		Info=bsdao.info(empcode);//Emp_id& Emp_Name
		    		String EmpName=(String) Info.get("EmployeeName");
		    		 Criteria cx=session.createCriteria(BonusSetting.class);
		    		 Projection ads=Projections.property("condition1");
		    		 Projection adsa=Projections.property("percent");
		    		 ProjectionList pl=Projections.projectionList();
		    		 pl.add(ads);
		    		 pl.add(adsa);
		    		 cx.setProjection(pl);
		    		 BonusSetting=cx.list();
		    		List<Float> prescons=new ArrayList<Float>();
		    		
		    		float PresentDays=0.0f;
		    	    float BasicSal=0.0f;
		    	    Float Con = 0.0f;
					float percent =0.0f;
		    	     
		    		for(int m=0;m<=loop;m++)
		    	     { 
		    			int monthx=(int) months.get(m).get("Month");
		    			int yearx=(int) months.get(m).get("Year");
		 
		    			PresentDays+=bsdao.PresentDays(empcode, monthx, yearx);
		
		    			BasicSal+=bsmanager.basicsal(empcode, monthx, yearx);
		    	     }
		    		HashMap<String,String> per = new HashMap<String,String>();
		    		int x=0;
		    		for(Object[] row: BonusSetting)
		    		{
		    			float condition = (float) row[0];
		    			prescons.add((float) condition);			
		    			per.put(String.valueOf(condition), String.valueOf(row[1]));
		    			
		    			x++;
		    		}
		    		Collections.sort(prescons);
		    		for(int t = 0;t < prescons.size();t++ ) 
		    		{
		    			
		    			if(PresentDays >= prescons.get(t))
		    			{
		    				Con = prescons.get(t);
		    				
		    				percent = Float.valueOf(per.get(String.valueOf(Con)) );
		    			}
		    			
		    		}
		    
		    		if(percent>0)
		    		{
		    			
		    			Bonus=(float) ((BasicSal/100)*percent);
		    			Bonus1.put("group", group);
		    			Bonus1.put("Design", Design);
		    			Bonus1.put("catag", catag);
		    			Bonus1.put("dept", dept);
		    			Bonus1.put("Bonus", Bonus);
		    			Bonus1.put("empcode", empcode);
		    			Bonus1.put("PresentDays", PresentDays);
		    			Bonus1.put("BasicSal", BasicSal);
		    			Bonus1.put("EmpName", EmpName);
		    			Bonus1.put("percent", percent);
		    			
				    	tBonus.add(Bonus1);
		    		}
			}
		    		}


	
	return tBonus;
	 
 }
 
 public Map Summarybonusfilter(String year,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
 {
	 
	 List idemp=new ArrayList();
	 Map finl=new HashMap();
	 idemp=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
	 List<Map> bonus=new ArrayList();
	 float totalbasic=0.0f;
	 float totalbonus=0.0f;
	 float bonuspercent=0.0f;
	 int noofemp=idemp.size();
	 int count=0;
	 for(int i=0;i<idemp.size();i++)
	 {
		bonus=this.presentbonusfilter(year, Group, Department, Catagory, Designation, Shift, Employee_Code);
		
		if(!bonus.isEmpty())
		{
			count=count+1;
		bonuspercent= (float) bonus.get(0).get("percent");
		
		
		float basicsal= (float) bonus.get(0).get("BasicSal");
		totalbasic=totalbasic+basicsal;
		
		float bonus1= (float) bonus.get(0).get("Bonus");
		totalbonus=totalbonus+bonus1;
		}
		}

	 if(bonuspercent>0)
	 {
		 
	 finl.put("bonuspercent", bonuspercent);
	 finl.put("count", count);
	 finl.put("totalbasic", totalbasic);
	 finl.put("totalbonus", totalbonus);
	
	 return finl;
	 }
	
 return null;
	 
 }
 
 
 public Map Totalbonusfilter(String year,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
 {
	 
	 List idemp=new ArrayList();
	 Map finl=new HashMap();
	 idemp=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
	 List<Map> bonus=new ArrayList();
	 float totalbasic=0.0f;
	 float totalbonus=0.0f;
	 int noofemp=0;
	 float bonuspercent=0.0f;
	 int count=0;
	 for(int i=0;i<idemp.size();i++)
	 {
		bonus=this.presentbonusfilter(year, Group, Department, Catagory, Designation, Shift, Employee_Code);
		
		if(!bonus.isEmpty())
		{
			count=count+1;
		bonuspercent= (float) bonus.get(0).get("percent");
		float basicsal= (float) bonus.get(0).get("BasicSal");
		totalbasic=totalbasic+basicsal;
		float bonus1= (float) bonus.get(0).get("Bonus");
		totalbonus=totalbonus+bonus1;
		}
	 }
	 if(bonuspercent>0)
	 {
		 
		 
	 finl.put("count", count);
	 finl.put("totalbasic", totalbasic);
	 finl.put("totalbonus", totalbonus);
	return finl;
	 }
	 return null;
	 
 }
 public bonusSalaryFilter bonusfilter(String year,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code)
 {
	 bonusSalaryFilter bsf =new bonusSalaryFilter();
	 bsf.setPresent(this.presentbonusfilter(year, Group, Department, Catagory, Designation, Shift, Employee_Code));
	 bsf.setSummary(this.Summarybonusfilter(year, Group, Department, Catagory, Designation, Shift, Employee_Code));
	 bsf.setTotal(this.Totalbonusfilter(year, Group, Department, Catagory, Designation, Shift, Employee_Code));
 
 return bsf;
 }

 public List TaxBetmonthsReportfilter(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
	 
	 Session session = (Session) hipernateConfg.getSession();  
	 GregorianCalendar gcal = new GregorianCalendar();
	
	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
	 Date start = sdf.parse(strtdate);
	 Date end = sdf.parse(endDate);
	 List info1=new ArrayList();
	
	gcal.setTime(start);
	
	
	while (!gcal.getTime().after(end)) 
	{
		
		List commonlist=new ArrayList();
		
		commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);

		int month=gcal.get(Calendar.MONTH)+1;
		int year=gcal.get(Calendar.YEAR);
	
	
	for(int i=0;i<commonlist.size();i++)
	{
		TAXbetpresent taxpresent=new TAXbetpresent();
		
		Map info=new HashMap();
		List Bonus1=new ArrayList();
		List<Object[]> bonus=new ArrayList<Object[]>(); 
		int idEmployees=(int) commonlist.get(i);
		float Bonus=0.0f;
		
		String group="";
		String Design="";
		String catag="";
		String dept="";
	try {
		List<Object[]> present_report=new ArrayList<Object[]>();
		Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
				+ "cat.name as Catagory, dept.name as Department  "
				+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
				"	  		 where  " + 
				"	  		 emp.idEmployees in :idEmployees " + 
				"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
				"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
				"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
				"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

			r.setParameter("idEmployees", idEmployees);
			
			present_report=r.list();
		 group=(String) present_report.get(0)[0];
			 Design=(String) present_report.get(0)[1];
			 catag=(String) present_report.get(0)[2];
			 dept=(String) present_report.get(0)[3];
		
	}
	catch(Exception e)
	{
		
	}
			
			Criteria a=session.createCriteria(Employees.class);
			a.add(Restrictions.eq("idEmployees", idEmployees));
			Projection p=Projections.property("employeeCode");
			a.setProjection(p);
			String empcode=(String) a.uniqueResult();
			
			int idsal=0;
			float pf=0.0f;
			float other=0.0f;
			float pt=0.0f;
			float esi=0.0f;
			String Shiftname="";
			Map Info=new HashMap();
			Info=bsdao.info(empcode);//Emp_id& Emp_Name
			String EmpName=(String) Info.get("EmployeeName");
		
		try {
			 
			Criteria x1=session.createCriteria(Salary.class);
				x1.add(Restrictions.eq("idEmployees", idEmployees));
				x1.add(Restrictions.eq("month", month));
				x1.add(Restrictions.eq("year", year));
				Projection f=Projections.property("idSalary");
				x1.setProjection(f);
				 idsal=(int) x1.uniqueResult();
			
				 Criteria x11=session.createCriteria(EmpWorkDetails.class);
					x11.add(Restrictions.eq("idEmployees", idEmployees));
			
					Projection f1=Projections.property("idShift");
					x11.setProjection(f1);
					int idshift=(int) x11.uniqueResult();
				
					Criteria x111=session.createCriteria(Shift.class);
					x111.add(Restrictions.eq("idShift", idshift));
			
					Projection f11=Projections.property("name");
					x111.setProjection(f11);
					 Shiftname=(String) x111.uniqueResult();
		
				Criteria x=session.createCriteria(SalaryDeduction.class);
				x.add(Restrictions.eq("idSalary", idsal));
				x.add(Restrictions.eq("deductionType", "PF"));
				Projection pm=Projections.property("deductionAmount");
				x.setProjection(pm);
				pf=(float) x.uniqueResult();
			
				Criteria y8=session.createCriteria(SalaryDeduction.class);
				y8.add(Restrictions.eq("idSalary", idsal));
				y8.add(Restrictions.eq("deductionType", "PT"));
				Projection m=Projections.property("deductionAmount");
				y8.setProjection(m);
				pt=(float) y8.uniqueResult();
				
				Criteria y18=session.createCriteria(SalaryDeduction.class);
				y18.add(Restrictions.eq("idSalary", idsal));
				y18.add(Restrictions.eq("deductionType", "ESI"));
				Projection m1=Projections.property("deductionAmount");
				y18.setProjection(m1);
				esi=(float) y18.uniqueResult();
			
				Criteria y118=session.createCriteria(SalaryDeduction.class);
				y118.add(Restrictions.eq("idSalary", idsal));
				y118.add(Restrictions.eq("deductionType", "Other"));
				Projection m11=Projections.property("deductionAmount");
				y118.setProjection(m11);
				other=(float) y118.uniqueResult();
		}
		catch(Exception e)
		{
			
		}
			float totaltax=pf+pt+esi+other;
			taxpresent.setMonth(month);
			taxpresent.setGroup(group);
			taxpresent.setDept(dept);
			taxpresent.setShiftname(Shiftname);
			taxpresent.setDesign(Design);
			taxpresent.setCatag(catag);
			taxpresent.setEmpcode(empcode);
			taxpresent.setEmpName(EmpName);
			taxpresent.setPf(pf);
			taxpresent.setPt(pt);
			taxpresent.setEsi(esi);
			taxpresent.setOther(other);
			taxpresent.setTotaltax(totaltax);
			info1.add(taxpresent);
	}
		
		gcal.add(Calendar.MONTH, 1);
		
	}
	session.close();

		return info1;
	 
	 
	 
	}
	 
 public TOTALTAXbet TotalTaxBetmonthsReportfilter(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		 float Totalpf=0.0f;	 
		 float Totalpt=0.0f;
		 float totalother=0.0f;
		 float fnltotal=0.0f;
		 
		 Session session = (Session) hipernateConfg.getSession();  
		 GregorianCalendar gcal = new GregorianCalendar();
		
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		 Date start = sdf.parse(strtdate);
		 Date end = sdf.parse(endDate);
		 Map info1=new HashMap();
		
		gcal.setTime(start);
		
		TOTALTAXbet totalt=new TOTALTAXbet();
		while (!gcal.getTime().after(end)) 
		{
			
			List commonlist=new ArrayList();
			
			commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);

			int month=gcal.get(Calendar.MONTH)+1;
			int year=gcal.get(Calendar.YEAR);
		
		int noofemp=commonlist.size();
		for(int i=0;i<commonlist.size();i++)
		{
			List info=new ArrayList();
			List Bonus1=new ArrayList();
			List<Object[]> bonus=new ArrayList<Object[]>(); 
			int idEmployees=(int) commonlist.get(i);
			
				int idsal=0;
				float pf=0.0f;
				float other=0.0f;
				float pt=0.0f;
				float esi=0.0f;
		try {
				Criteria x1=session.createCriteria(Salary.class);
				x1.add(Restrictions.eq("idEmployees", idEmployees));
				x1.add(Restrictions.eq("month", month));
				x1.add(Restrictions.eq("year", year));
				Projection f=Projections.property("idSalary");
				x1.setProjection(f);
				idsal=(int) x1.uniqueResult();;

				Criteria m8=session.createCriteria(SalaryDeduction.class);
				m8.add(Restrictions.eq("idSalary", idsal));
				m8.add(Restrictions.eq("deductionType", "PF"));
				Projection mm=Projections.property("deductionAmount");
				m8.setProjection(mm);
				pf=(float) m8.uniqueResult();
				
				
					Criteria y8=session.createCriteria(SalaryDeduction.class);
					y8.add(Restrictions.eq("idSalary", idsal));
					y8.add(Restrictions.eq("deductionType", "PT"));
					Projection m=Projections.property("deductionAmount");
					y8.setProjection(m);
					pt=(float) y8.uniqueResult();

					Criteria y18=session.createCriteria(SalaryDeduction.class);
					y18.add(Restrictions.eq("idSalary", idsal));
					y18.add(Restrictions.eq("deductionType", "ESI"));
					Projection m1=Projections.property("deductionAmount");
					y18.setProjection(m1);
					esi=(float) y18.uniqueResult();
			
				Criteria y158=session.createCriteria(SalaryDeduction.class);
				y158.add(Restrictions.eq("idSalary", idsal));
				y158.add(Restrictions.eq("deductionType", "Other"));
				Projection m51=Projections.property("deductionAmount");
				y158.setProjection(m51);
				other=(float) y158.uniqueResult();
		}
		catch(Exception e)
		{
			
		}
				float totaltax=pf+pt+esi+other;
				Totalpf=Totalpf+pf;
				Totalpt=Totalpt+pt;
				totalother=totalother+other;
				fnltotal=fnltotal+totaltax;
				
		}
		
		totalt.setNoofemp(noofemp);
		totalt.setTotalpf(Totalpf);
		totalt.setTotalpt(Totalpt);
		totalt.setTotalother(totalother);
		totalt.setFnltotal(fnltotal);
		
		gcal.add(Calendar.MONTH, 1);
			
		}
		session.close();

			return totalt;
	 
	}
 
 //TaxDedReportFilter
 public TaxDedReportFilter TaxDedReportFilter1(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
 {

	 TaxDedReportFilter a= new TaxDedReportFilter();
	 a.setTaxded(this.TaxBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	
	 
	 a.setTotaltax(this.TotalTaxBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	
	 return a;
	 
	 
	 
	 
	 
 }
 
 
 
 
 
 
 //****************other deduction ***********************
 
 
 
 public List OtherBetmonthsReportfilter(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
	 
	 Session session = (Session) hipernateConfg.getSession();  
	 GregorianCalendar gcal = new GregorianCalendar();
	
	 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
	 Date start = sdf.parse(strtdate);
	 Date end = sdf.parse(endDate);
	 List info1=new ArrayList();
	
	gcal.setTime(start);
	
	
	while (!gcal.getTime().after(end)) 
	{
		
		List commonlist=new ArrayList();
		
		commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);

		int month=gcal.get(Calendar.MONTH)+1;
		int year=gcal.get(Calendar.YEAR);
	
	
	for(int i=0;i<commonlist.size();i++)
	{
		Map info=new HashMap();
		List Bonus1=new ArrayList();
		List<Object[]> bonus=new ArrayList<Object[]>(); 
		int idEmployees=(int) commonlist.get(i);
		float Bonus=0.0f;
		String group="";
		String Design="";
		String catag="";
		String dept="";
	try {
		List<Object[]> present_report=new ArrayList<Object[]>();
		Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
				+ "cat.name as Catagory, dept.name as Department  "
				+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
				"	  		 where  " + 
				"	  		 emp.idEmployees in :idEmployees " + 
				"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
				"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
				"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
				"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

			r.setParameter("idEmployees", idEmployees);
			
			present_report=r.list();
			 group=(String) present_report.get(0)[0];
			 Design=(String) present_report.get(0)[1];
			 catag=(String) present_report.get(0)[2];
			 dept=(String) present_report.get(0)[3];
			
			
	}
	catch(Exception e)
	{
		
	}
			
			Criteria a=session.createCriteria(Employees.class);
			a.add(Restrictions.eq("idEmployees", idEmployees));
			Projection p=Projections.property("employeeCode");
			a.setProjection(p);
			String empcode=(String) a.uniqueResult();
			int idsal=0;
			float buschrg=0.0f;
			float phonebill=0.0f;
			float advance=0.0f;
			float canteen=0.0f;
			float house=0.0f;
			float loan=0.0f;
			 
			Map Info=new HashMap();
			Info=bsdao.info(empcode);//Emp_id& Emp_Name
			String EmpName=(String) Info.get("EmployeeName");
		
	String Shiftname="";
		try {
			Criteria x1=session.createCriteria(Salary.class);
			x1.add(Restrictions.eq("idEmployees", idEmployees));
			x1.add(Restrictions.eq("month", month));
			x1.add(Restrictions.eq("year", year));
			Projection f=Projections.property("idSalary");
			x1.setProjection(f);
			 idsal=(int) x1.uniqueResult();
			
				Criteria y18=session.createCriteria(SalaryDeduction.class);
				y18.add(Restrictions.eq("idSalary", idsal));
				y18.add(Restrictions.eq("deductionType", "Bus Charge"));
				Projection m1=Projections.property("deductionAmount");
				y18.setProjection(m1);
				buschrg=(float) y18.uniqueResult();	
		
				Criteria y8=session.createCriteria(SalaryDeduction.class);
				y8.add(Restrictions.eq("idSalary", idsal));
				y8.add(Restrictions.eq("deductionType", "Phone Bills"));
				Projection m=Projections.property("deductionAmount");
				y8.setProjection(m);
				phonebill=(float) y8.uniqueResult();	
		
				Criteria y=session.createCriteria(SalaryDeduction.class);
				y.add(Restrictions.eq("idSalary", idsal));
				y.add(Restrictions.eq("deductionType", "Advance"));
				Projection m4=Projections.property("deductionAmount");
				y.setProjection(m4);
				advance=(float) y.uniqueResult();	
			
				
				Criteria yt=session.createCriteria(SalaryDeduction.class);
				yt.add(Restrictions.eq("idSalary", idsal));
				yt.add(Restrictions.eq("deductionType", "Loan"));
				Projection mt4=Projections.property("deductionAmount");
				yt.setProjection(mt4);
				loan=(float) yt.uniqueResult();	
		
				Criteria yat=session.createCriteria(SalaryDeduction.class);
				yat.add(Restrictions.eq("idSalary", idsal));
				yat.add(Restrictions.eq("deductionType", "canteen Deduction"));
				Projection t4=Projections.property("deductionAmount");
				yat.setProjection(t4);
				canteen=(float) yat.uniqueResult();	
		
				Criteria at=session.createCriteria(SalaryDeduction.class);
				at.add(Restrictions.eq("idSalary", idsal));
				at.add(Restrictions.eq("deductionType", "House Rent"));
				Projection t=Projections.property("deductionAmount");
				at.setProjection(t);
				house=(float) at.uniqueResult();	
				
				
				 Criteria x11=session.createCriteria(EmpWorkDetails.class);
					x11.add(Restrictions.eq("idEmployees", idEmployees));
			
					Projection f1=Projections.property("idShift");
					x11.setProjection(f1);
					int idshift=(int) x11.uniqueResult();
				
					Criteria x111=session.createCriteria(Shift.class);
					x111.add(Restrictions.eq("idShift", idshift));
			
					Projection f11=Projections.property("name");
					x111.setProjection(f11);
					 Shiftname=(String) x111.uniqueResult();
		}
		catch(Exception e)
		{
			
		}
	
			float totalded=buschrg+phonebill+advance+loan+canteen+house;
			
			info.put("month", month);
			info.put("group", group);
			info.put("dept", dept);
			info.put("Design", Design);
			info.put("catag", catag);
			info.put("empcode", empcode);	
			info.put("EmpName", EmpName);
			info.put("shift", Shiftname);
			info.put("buschrg", buschrg);
			info.put("phonebill", phonebill);
			info.put("advance", advance);
			info.put("loan", loan);
			info.put("canteen", canteen);
			info.put("house", house);
			info.put("totalded", totalded);
			
			info1.add(info);
	}
		
		gcal.add(Calendar.MONTH, 1);
		
	}
	session.close();

		return info1;
	 
	 
	 
	}
	 
public Map TotalOtherBetmonthsReportfilter(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		float tbuschrg=0.0f;
		float tphonebill=0.0f;
		float tadvance=0.0f;
		float tcanteen=0.0f;
		float thouse=0.0f;
		float tloan=0.0f;
		float fnltotal=0.0f;	 
		 Session session = (Session) hipernateConfg.getSession();  
		 GregorianCalendar gcal = new GregorianCalendar();
		
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
		 Date start = sdf.parse(strtdate);
		 Date end = sdf.parse(endDate);
		
		 Map info1=new HashMap();
		gcal.setTime(start);
		
		while (!gcal.getTime().after(end)) 
		{
			
			List commonlist=new ArrayList();
			
			commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);

			int month=gcal.get(Calendar.MONTH)+1;
			int year=gcal.get(Calendar.YEAR);
		
		int noofemp=commonlist.size();
		for(int i=0;i<commonlist.size();i++)
		{
			
			List Bonus1=new ArrayList();
			List<Object[]> bonus=new ArrayList<Object[]>(); 
			int idEmployees=(int) commonlist.get(i);
		
			float buschrg=0.0f;
			float phonebill=0.0f;
			float advance=0.0f;
			float canteen=0.0f;
			float house=0.0f;
			float loan=0.0f;
			int idsal=0;
			
			try {
			Criteria x1=session.createCriteria(Salary.class);
			x1.add(Restrictions.eq("idEmployees", idEmployees));
			x1.add(Restrictions.eq("month", month));
			x1.add(Restrictions.eq("year", year));
			Projection f=Projections.property("idSalary");
			x1.setProjection(f);
			 idsal=(int) x1.uniqueResult();

				Criteria y18=session.createCriteria(SalaryDeduction.class);
				y18.add(Restrictions.eq("idSalary", idsal));
				y18.add(Restrictions.eq("deductionType", "Bus Charge"));
				Projection m1=Projections.property("deductionAmount");
				y18.setProjection(m1);
				buschrg=(float) y18.uniqueResult();	
		
				Criteria y8=session.createCriteria(SalaryDeduction.class);
				y8.add(Restrictions.eq("idSalary", idsal));
				y8.add(Restrictions.eq("deductionType", "Phone Bills"));
				Projection m=Projections.property("deductionAmount");
				y8.setProjection(m);
				phonebill=(float) y8.uniqueResult();	
		
				Criteria y=session.createCriteria(SalaryDeduction.class);
				y.add(Restrictions.eq("idSalary", idsal));
				y.add(Restrictions.eq("deductionType", "Advance"));
				Projection m4=Projections.property("deductionAmount");
				y.setProjection(m4);
				advance=(float) y.uniqueResult();	
			
				
				Criteria yt=session.createCriteria(SalaryDeduction.class);
				yt.add(Restrictions.eq("idSalary", idsal));
				yt.add(Restrictions.eq("deductionType", "Loan"));
				Projection mt4=Projections.property("deductionAmount");
				yt.setProjection(mt4);
				loan=(float) yt.uniqueResult();	
		
				Criteria yat=session.createCriteria(SalaryDeduction.class);
				yat.add(Restrictions.eq("idSalary", idsal));
				yat.add(Restrictions.eq("deductionType", "canteen Deduction"));
				Projection t4=Projections.property("deductionAmount");
				yat.setProjection(t4);
				canteen=(float) yat.uniqueResult();	
		
				Criteria at=session.createCriteria(SalaryDeduction.class);
				at.add(Restrictions.eq("idSalary", idsal));
				at.add(Restrictions.eq("deductionType", "House Rent"));
				Projection t=Projections.property("deductionAmount");
				at.setProjection(t);
				house=(float) at.uniqueResult();	
			}
			catch(Exception e)
			{
				
			}
					float totalded=buschrg+phonebill+advance+loan+canteen+house;
					
				tbuschrg=tbuschrg+buschrg;
				tphonebill=tphonebill+phonebill;
				tadvance=tadvance+advance;
				tloan=tloan+loan;
				tcanteen=tcanteen+canteen;
				thouse=thouse+house;
				fnltotal=+fnltotal+totalded;
		}
		info1.put("noofemp", noofemp);
		info1.put("tbuschrg", tbuschrg);
		info1.put("tphonebill", tphonebill);
		info1.put("tadvance", tadvance);
		info1.put("tloan", tloan);
		info1.put("tcanteen", tcanteen);
		info1.put("thouse", thouse);
		info1.put("fnltotal", fnltotal);
		

		gcal.add(Calendar.MONTH, 1);
			
		}
		session.close();

			return info1;
	 
	}

//TaxDedReportFilter
public otherDedBetMonthFilter otherDedBetMonthFilter1(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	otherDedBetMonthFilter odrf=new otherDedBetMonthFilter();
	 odrf.setOtherded(this.OtherBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	 odrf.setTotal(this.TotalOtherBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	return odrf;
	 	 
}


//***********************INCENTIVE FILTER*************************
public List IncentiveBetmonthsReportfilter(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
 
 Session session = (Session) hipernateConfg.getSession();  
 GregorianCalendar gcal = new GregorianCalendar();

 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
 Date start = sdf.parse(strtdate);
 Date end = sdf.parse(endDate);
 List info1=new ArrayList();

gcal.setTime(start);


while (!gcal.getTime().after(end)) 
{
	
	List commonlist=new ArrayList();
	
	commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);

	int month=gcal.get(Calendar.MONTH)+1;
	int year=gcal.get(Calendar.YEAR);


	for(int i=0;i<commonlist.size();i++)
	{
	Map info=new HashMap();
	List Bonus1=new ArrayList();
	List<Object[]> bonus=new ArrayList<Object[]>(); 
	int idEmployees=(int) commonlist.get(i);
	float Bonus=0.0f;
	String group="";
	String Design="";
	String catag="";
	String dept="";
try {
	List<Object[]> present_report=new ArrayList<Object[]>();
	Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
			+ "cat.name as Catagory, dept.name as Department  "
			+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
			"	  		 where  " + 
			"	  		 emp.idEmployees in :idEmployees " + 
			"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
			"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
			"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
			"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

		r.setParameter("idEmployees", idEmployees);
		
		present_report=r.list();
		 group=(String) present_report.get(0)[0];
		 Design=(String) present_report.get(0)[1];
		 catag=(String) present_report.get(0)[2];
		 dept=(String) present_report.get(0)[3];
}
catch(Exception e) {
	
	
}
		Criteria a=session.createCriteria(Employees.class);
		a.add(Restrictions.eq("idEmployees", idEmployees));
		Projection p=Projections.property("employeeCode");
		a.setProjection(p);
		String empcode=(String) a.uniqueResult();
		int idsal=0;
	
		Map Info=new HashMap();
		Info=bsdao.info(empcode);//Emp_id& Emp_Name
		String EmpName=(String) Info.get("EmployeeName");
		String Shiftname="";
		try {
		Criteria x1=session.createCriteria(Salary.class);
		x1.add(Restrictions.eq("idEmployees", idEmployees));
		x1.add(Restrictions.eq("month", month));
		x1.add(Restrictions.eq("year", year));
		Projection f=Projections.property("idSalary");
		x1.setProjection(f);
		 idsal=(int) x1.uniqueResult();
			
		 Criteria x11=session.createCriteria(EmpWorkDetails.class);
			x11.add(Restrictions.eq("idEmployees", idEmployees));
	
			Projection f1=Projections.property("idShift");
			x11.setProjection(f1);
			int idshift=(int) x11.uniqueResult();
		
			Criteria x111=session.createCriteria(Shift.class);
			x111.add(Restrictions.eq("idShift", idshift));
	
			Projection f11=Projections.property("name");
			x111.setProjection(f11);
			 Shiftname=(String) x111.uniqueResult();
			float PresentDays=bsdao.PresentDays(empcode, month, year);
			
			
			Query w=session.createQuery("SELECT earningAmount FROM SalaryEarning where idSalary= :idsal and earningType='Incentive'");
			w.setParameter("idsal", idsal);
			float incAmount=(float) w.uniqueResult();
			float incPerDay=incAmount/PresentDays;
			
			info.put("month", month);
			info.put("group", group);
			info.put("dept", dept);
			info.put("catag", catag);
			info.put("shift", Shiftname);
			info.put("Design", Design);
			info.put("empcode", empcode);
			info.put("EmpName", EmpName);
			info.put("PresentDays", PresentDays);
			info.put("incPerDay", incPerDay);
			info.put("incAmount", incAmount);
	
			info1.add(info);
		}
		catch(Exception e)
		{
			
		}
		}
	gcal.add(Calendar.MONTH, 1);
   	}
session.close();

return info1;
   }
 

public Map TotalIncentiveBetmonthsReportfilter(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	List<List> inc=new ArrayList<List>();
	Map fnl=new HashMap();
inc=this.IncentiveBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code);
float totalpresntds=0.0f;
float tincperday=0.0f;
float tincAmount=0.0f;
int noofemp=inc.size();



Session session = (Session) hipernateConfg.getSession();  
GregorianCalendar gcal = new GregorianCalendar();

SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
Date start = sdf.parse(strtdate);
Date end = sdf.parse(endDate);
List info1=new ArrayList();

gcal.setTime(start);


while (!gcal.getTime().after(end)) 
{
	
	List commonlist=new ArrayList();
	
	commonlist=this.commonEmployees(Designation, Department, Catagory, Employee_Code);

	int month=gcal.get(Calendar.MONTH)+1;
	int year=gcal.get(Calendar.YEAR);


	for(int i=0;i<commonlist.size();i++)
	{
	List info=new ArrayList();
	List Bonus1=new ArrayList();
	List<Object[]> bonus=new ArrayList<Object[]>(); 
	int idEmployees=(int) commonlist.get(i);
	Criteria a=session.createCriteria(Employees.class);
	a.add(Restrictions.eq("idEmployees", idEmployees));
	Projection p=Projections.property("employeeCode");
	a.setProjection(p);
	String empcode=(String) a.uniqueResult();
		int idsal=0;
	
		try {
		Criteria x1=session.createCriteria(Salary.class);
		x1.add(Restrictions.eq("idEmployees", idEmployees));
		x1.add(Restrictions.eq("month", month));
		x1.add(Restrictions.eq("year", year));
		Projection f=Projections.property("idSalary");
		x1.setProjection(f);
		 idsal=(int) x1.uniqueResult();
			float PresentDays=bsdao.PresentDays(empcode, month, year);
			
			
			Criteria xa1=session.createCriteria(SalaryEarning.class);
			xa1.add(Restrictions.eq("idSalary", idsal));
			xa1.add(Restrictions.eq("earningType", "Incentive"));
			Projection pam=Projections.property("earningAmount");
			xa1.setProjection(pam);
			float incAmount=(float) xa1.uniqueResult();
			
			float incPerDay=incAmount/PresentDays;
		
			totalpresntds=totalpresntds+PresentDays;
			
			tincperday=tincperday+incPerDay;
			
			tincAmount=tincAmount+incAmount;
		}
	
	catch(Exception e)
	{
		
	}
	}
	gcal.add(Calendar.MONTH, 1);
  	}

	fnl.put("noofemp", noofemp);
	fnl.put("totalpresntds", totalpresntds);
	fnl.put("tincperday", tincperday);
	fnl.put("tincAmount", tincAmount);
	
	session.close();
	return fnl;

	
	
}

public incentiveFilter incentiveFilter1(String strtdate,String endDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	incentiveFilter odrf=new incentiveFilter();
	 odrf.setInc(this.IncentiveBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	 odrf.setTotal(this.TotalIncentiveBetmonthsReportfilter(strtdate, endDate, Group, Department, Catagory, Designation, Shift, Employee_Code));
	return odrf;
	 	 
}
public Overtimebetdates overtimebetdatesReport(String Strtdate,String enddate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	
	List<Integer> Common_list=new ArrayList<Integer>();
	List<Object[]> present_report=new ArrayList<Object[]>();
	List<Integer> Shift_report=new ArrayList<Integer>();
	Calendar calendar = Calendar.getInstance();  
	int idemp=0;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date start = sdf.parse(Strtdate);
			Date end = sdf.parse(enddate);
	String str[] = Strtdate.split("-");
	int day=Integer.parseInt(str[2]);
 	int year = Integer.parseInt(str[0]);
 	int month = Integer.parseInt(str[1])-1;
 	
 	String str1[] = enddate.split("-");
	int day1=Integer.parseInt(str1[2]);
 	int year1 = Integer.parseInt(str1[0]);
 	int month1 = Integer.parseInt(str1[1])-1;
 	calendar.setTime(start);
 	Date enddate1=calendar.getTime();
	Overtimebetdates otr=new Overtimebetdates();
	

  calendar.set(year, month, day);
  Map total=new HashMap();
  float totalhr=0.0f;
  float totaldaycon=0.0f;
  float totalsal=0.0f;
  List inf=new ArrayList();
  System.err.println("**************first date "+calendar.getTime()+"enddate "+enddate1);
  while(!calendar.getTime().after(end))
	{
			
		Date date = calendar.getTime();
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		//Date start = sdf.parse(String.valueOf(date));
		//Date end = sdf.parse(endDate);
		System.err.println("date in loop"+date);
		Criteria cr=session.createCriteria(EmpWorkDetails.class);
		Projection pr=Projections.property("idEmployees");
		cr.setProjection(pr);
		Common_list=cr.list();

	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
if(!Shift.isEmpty())
{
		Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add(Restrictions.eq("name", Shift )).uniqueResult();
	   int idshift=e1.getIdShift();

	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   Common_list.retainAll(Shift_report);
	   System.err.println("Common_list"+Common_list);
   		
}


for(int i=0;i<Common_list.size();i++)
{
	List Salary=new ArrayList();
	//List<Object[]> bonnus=new ArrayList<Object[]>();
	int idEmployees=(int) Common_list.get(i);
	System.err.println("idEmployees"+idEmployees);
	Map fnl=new HashMap();
	Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
			+ "cat.name as Catagory, dept.name as Department  "
			+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
			"	  		 where  " + 
			"	  		 emp.idEmployees = :idEmployees " + 
			"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
			"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
			"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
			"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

		r.setParameter("idEmployees", idEmployees);
		
		present_report=r.list();
		
	
		String group=(String) present_report.get(0)[0];
		String Design=(String) present_report.get(0)[1];
		
		String catag=(String) present_report.get(0)[2];
		String dept=(String) present_report.get(0)[3];

		Criteria a=session.createCriteria(Employees.class);
		a.add(Restrictions.eq("idEmployees", idEmployees));
		Projection p=Projections.property("employeeCode");
		a.setProjection(p);
		String empcode=(String) a.uniqueResult();
	
		Criteria va=session.createCriteria(Designation.class);
		va.add(Restrictions.eq("name", Design));
		Projection vp=Projections.property("salary");
		va.setProjection(vp);
		float salary=(float) va.uniqueResult();
		
		Criteria b=session.createCriteria(EmpWorkDetails.class);
		b.add(Restrictions.eq("idEmployees", idEmployees));
		Projection np=Projections.property("idShift");
		Projection pd=Projections.property("hours");
		ProjectionList pf=Projections.projectionList();
		pf.add(np);
		pf.add(pd);
		b.setProjection(pf);
		
		List<Object[]>shifthr= b.list();
		int idShift= (int) shifthr.get(0)[0];
		float wkhours= (float) shifthr.get(0)[1];
		
		Criteria bs=session.createCriteria(Shift.class);
		bs.add(Restrictions.eq("idShift", idShift));
		Projection nps=Projections.property("name");
		bs.setProjection(nps);
		String Shiftname=(String) bs.uniqueResult();	

	Map Info=new HashMap();
	Info=bsdao.info(empcode);//Emp_id& Emp_Name
	String EmpName=(String) Info.get("EmployeeName");
	float hours=0.0f;
	try {
	Criteria qb=session.createCriteria(Overtime.class);
	qb.add(Restrictions.eq("idEmployees", idEmployees));
	qb.add(Restrictions.eq("date", date));
	Projection npq=Projections.property("hours");
	qb.setProjection(npq);
	 hours=(float) qb.uniqueResult();
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	
	System.err.println("Hours ########"+hours);
	totalhr=totalhr+hours;
	float daycon=hours/wkhours;
	totaldaycon=totaldaycon+daycon;
	float tsalary=daycon*salary;
	totalsal=totalsal+tsalary;
	fnl.put("date", date);
	fnl.put("group", group);
	fnl.put("Design", Design);
	fnl.put("catag", catag);
	fnl.put("dept", dept);
	fnl.put("Shiftname", Shiftname);
	fnl.put("empcode", empcode);
	fnl.put("EmpName", EmpName);
	fnl.put("hours", hours);
	fnl.put("daycon", daycon);
	fnl.put("tsalary", tsalary);
	inf.add(fnl);
	
	System.err.println("TotalHours "+totalhr);
	}
otr.setDay(inf);
total.put("noofemployees", Common_list.size());
total.put("totalhr", totalhr);
total.put("totaldaycon", totaldaycon);
total.put("totalsal", totalsal);
otr.setTotal(total);

calendar.add(Calendar.DATE, 1);

 }
return otr;
}



public overtimedayreport overtimedayReport(String date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	
	List abc=new ArrayList();
	List<Integer> Common_list=new ArrayList<Integer>();
	List<Object[]> present_report=new ArrayList<Object[]>();
	List<Integer> Shift_report=new ArrayList<Integer>();
	int idemp=0;
	String end[]=date.split("-");
	
	int day=Integer.valueOf(end[2]);
	int month2=Integer.valueOf(end[1])-1;
	int year2=Integer.valueOf(end[0]);
	
	Calendar calendar = Calendar.getInstance();  
  calendar.set(year2, month2, day);
  Date Fd1=calendar.getTime();
	SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	Date Fd=format.parse(format.format(Fd1));
  System.err.println("first date = "+Fd);
  int year = calendar.get(Calendar.YEAR);
  int month = calendar.get(Calendar.MONTH)+1;
System.err.println("year"+year+"    month"+month);
  Criteria cr=session.createCriteria(EmpWorkDetails.class);
  Projection pr=Projections.property("idEmployees");
  cr.setProjection(pr);
  Common_list=cr.list();


	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
if(!Shift.isEmpty())
{
   Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add(Restrictions.eq("name", Shift )).uniqueResult();
	   int idshift=e1.getIdShift();

	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", Fd));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   Common_list.retainAll(Shift_report);
   		
}
Map total=new HashMap();
float totalhr=0.0f;
float totaldaycon=0.0f;
float totalsal=0.0f;
overtimedayreport otr=new overtimedayreport();
for(int i=0;i<Common_list.size();i++)
{
	List Salary=new ArrayList();
	//List<Object[]> bonnus=new ArrayList<Object[]>();
	int idEmployees=(int) Common_list.get(i);
	Map fnl=new HashMap();
	String group="";
	String Design="";
	String catag="";
	String dept="";
	String empcode="";
	float salary=0.0f;
	int idShift=0;
	float wkhours=0.0f;
	String Shiftname="";
	try {
	
	Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
			+ "cat.name as Catagory, dept.name as Department  "
			+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
			"	  		 where  " + 
			"	  		 emp.idEmployees in :idEmployees " + 
			"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
			"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
			"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
			"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

		r.setParameter("idEmployees", idEmployees);
		
		present_report=r.list();
		 group=(String) present_report.get(0)[0];
		 Design=(String) present_report.get(0)[1];
		
		 catag=(String) present_report.get(0)[2];
		 dept=(String) present_report.get(0)[3];
		 
		 
		 Criteria a=session.createCriteria(Employees.class);
			a.add(Restrictions.eq("idEmployees", idEmployees));
			Projection p=Projections.property("employeeCode");
			a.setProjection(p);
			 empcode=(String) a.uniqueResult();
		
			Criteria va=session.createCriteria(Designation.class);
			va.add(Restrictions.eq("name", Design));
			Projection vp=Projections.property("salary");
			va.setProjection(vp);
			 salary=(float) va.uniqueResult();
			
				Criteria b=session.createCriteria(EmpWorkDetails.class);
				b.add(Restrictions.eq("idEmployees", idEmployees));
				Projection np=Projections.property("idShift");
				Projection pd=Projections.property("hours");
				ProjectionList pf=Projections.projectionList();
				pf.add(np);
				pf.add(pd);
				b.setProjection(pf);
				
				List<Object[]>shifthr= b.list();
				 idShift= (int) shifthr.get(0)[0];
				 wkhours= (float) shifthr.get(0)[1];
				
				Criteria bs=session.createCriteria(Shift.class);
				bs.add(Restrictions.eq("idShift", idShift));
				Projection nps=Projections.property("name");
				bs.setProjection(nps);
				 Shiftname=(String) bs.uniqueResult();	
	}
	catch(Exception e) {
		
	}
		
		
	Map Info=new HashMap();
	Info=bsdao.info(empcode);//Emp_id& Emp_Name
	String EmpName=(String) Info.get("EmployeeName");
	float hours=0.0f;
	try {
	Criteria qb=session.createCriteria(Overtime.class);
	qb.add(Restrictions.eq("idEmployees", idEmployees));
	qb.add(Restrictions.eq("date", Fd));
	Projection npq=Projections.property("hours");
	qb.setProjection(npq);
	 hours=(float) qb.uniqueResult();
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	totalhr=totalhr+hours;
	float daycon=hours/wkhours;
	totaldaycon=totaldaycon+daycon;
	float tsalary=daycon*salary;
	totalsal=totalsal+tsalary;
	fnl.put("group", group);
	fnl.put("Design", Design);
	fnl.put("catag", catag);
	fnl.put("dept", dept);
	fnl.put("Shiftname", Shiftname);
	fnl.put("empcode", empcode);
	fnl.put("EmpName", EmpName);
	fnl.put("hours", hours);
	fnl.put("daycon", daycon);
	fnl.put("tsalary", tsalary);
	
	abc.add(fnl);
	otr.setDay(abc);
}
total.put("noofemp", abc.size());
total.put("totalhr", totalhr);
total.put("totaldaycon", totaldaycon);
total.put("totalsal", totalsal);
otr.setTotal(total);
return otr;
}


public Map overtimebetmonthReport(Date Strtdate,Date enddate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	List<Integer> Common_list=new ArrayList<Integer>();
	List<Object[]> present_report=new ArrayList<Object[]>();
	List<Integer> Shift_report=new ArrayList<Integer>();
	
Calendar calendar = Calendar.getInstance();  
  calendar.setTime(Strtdate);

  System.err.println("time########"+calendar.getTime());
  int month = calendar.get(Calendar.MONTH)+1;
  System.err.println("Startdate "+Strtdate+"enddate "+enddate);
  String group="";
  String Design="";
  String catag="";
  String dept="";
  String Shiftname="";
  Map total=new HashMap();
  float totalhr=0.0f;
  float totaldaycon=0.0f;
  float totalsal=0.0f;
  List inf=new ArrayList();
  while(!calendar.getTime().after(enddate))
	{	
		Date date = calendar.getTime();
	
		Criteria cr=session.createCriteria(EmpWorkDetails.class);
		Projection pr=Projections.property("idEmployees");
		cr.setProjection(pr);
		Common_list=cr.list();
	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
if(!Shift.isEmpty())
	{
		Shift e1=new Shift();
	  	e1 = (Shift)session.createCriteria(Shift.class).add(Restrictions.eq("name", Shift )).uniqueResult();
	  	int idshift=e1.getIdShift();
	   Criteria ca=session.createCriteria(Attendance.class);
	   ca.add(Restrictions.eq("idShift", idshift));
	   ca.add(Restrictions.eq("date", date));
	   Projection p=Projections.property("idEmployees");
	   ca.setProjection(p);
	   Shift_report=ca.list();
	   Common_list.retainAll(Shift_report);
	
}


for(int i=0;i<Common_list.size();i++)
{
	List Salary=new ArrayList();
	//List<Object[]> bonnus=new ArrayList<Object[]>();
	int idEmployees=(int) Common_list.get(i);

	Map fnl=new HashMap();
	Query r=session.createQuery("select empt.name as Emptype,desg.name as Designation, "
			+ "cat.name as Catagory, dept.name as Department  "
			+ "from  Emptype as empt,Employees as emp,Designation as desg, Catagory as cat, Department as dept " + 
			"	  		 where  " + 
			"	  		 emp.idEmployees = :idEmployees " + 
			"	  		 and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees)  " + 
			"	  		  and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees)  " + 
			"	  		  and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation)  " + 
			"	  		  and dept.idDepartment = (select idDepartment from Catagory where idCatagory = cat.idCatagory )");

		r.setParameter("idEmployees", idEmployees);
		
		present_report=r.list();
		
	
		 group=(String) present_report.get(0)[0];
		 Design=(String) present_report.get(0)[1];
		
		 catag=(String) present_report.get(0)[2];
		 dept=(String) present_report.get(0)[3];

		Criteria a=session.createCriteria(Employees.class);
		a.add(Restrictions.eq("idEmployees", idEmployees));
		Projection p=Projections.property("employeeCode");
		a.setProjection(p);
		String empcode=(String) a.uniqueResult();
	
		Criteria va=session.createCriteria(Designation.class);
		va.add(Restrictions.eq("name", Design));
		Projection vp=Projections.property("salary");
		va.setProjection(vp);
		float salary=(float) va.uniqueResult();
		
		Criteria b=session.createCriteria(EmpWorkDetails.class);
		b.add(Restrictions.eq("idEmployees", idEmployees));
		Projection np=Projections.property("idShift");
		Projection pd=Projections.property("hours");
		ProjectionList pf=Projections.projectionList();
		pf.add(np);
		pf.add(pd);
		b.setProjection(pf);
		
		List<Object[]>shifthr= b.list();
		int idShift= (int) shifthr.get(0)[0];
		float wkhours= (float) shifthr.get(0)[1];
		
		Criteria bs=session.createCriteria(Shift.class);
		bs.add(Restrictions.eq("idShift", idShift));
		Projection nps=Projections.property("name");
		bs.setProjection(nps);
		Shiftname=(String) bs.uniqueResult();	

	Map Info=new HashMap();
	Info=bsdao.info(empcode);//Emp_id& Emp_Name
	String EmpName=(String) Info.get("EmployeeName");
	float hours=0.0f;
	try {
		Criteria qb=session.createCriteria(Overtime.class);
		qb.add(Restrictions.eq("idEmployees", idEmployees));
		qb.add(Restrictions.eq("date", date));
		Projection npq=Projections.property("hours");
		qb.setProjection(npq);
		hours=(float) qb.uniqueResult();
		}
	catch(Exception e)
	{
		
	}
	totalhr=totalhr+hours;
	float daycon=hours/wkhours;
	totaldaycon=totaldaycon+daycon;
	float tsalary=daycon*salary;
	totalsal=totalsal+tsalary;
	
System.err.println("++++++++++totalsal"+totalsal);

	}
calendar.add(Calendar.DATE, 1);

 }
 
  total.put("month", month);
  total.put("group", group);
  total.put("Design", Design);
  total.put("catag", catag);
  total.put("dept", dept);
  total.put("Shiftname", Shiftname);
  total.put("noofemployees", Common_list.size());
  total.put("totalhr", totalhr);
  total.put("totaldaycon", totaldaycon);
  total.put("totalsal", totalsal);

  
  
return total;
}


public overtimebetmonth totalovertimebetmonthReport(String Strtdate,String enddate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
{
	
	Session session = (Session) hipernateConfg.getSession();  
	List<Integer> Common_list=new ArrayList<Integer>();

	String start[]=Strtdate.split("-");
	int month=Integer.valueOf(start[1])-1;
	int year=Integer.valueOf(start[0]);
	
	String end[]=enddate.split("-");
	int month2=Integer.valueOf(end[1])-1;
	int year2=Integer.valueOf(end[0]);
	
	overtimebetmonth otr=new overtimebetmonth();
	
	Calendar calendar = Calendar.getInstance();  
	
	calendar.set(year2, month2, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
	Date ld=calendar.getTime();
	int day1=1;
calendar.set(year, month, day1);
  Map total=new HashMap();
  float totalhr=0.0f;
  float totaldaycon=0.0f;
  float totalsal=0.0f;
  int totalemp=0;
  List inf=new ArrayList();
	Common_list=this.commonEmployees(Designation, Department, Catagory, Employee_Code);
List list=new ArrayList();

  while(!calendar.getTime().after(ld))
	{	
	  
	  Date date1=calendar.getTime();
	  int month1 = calendar.get(Calendar.MONTH);
	  int year1 = calendar.get(Calendar.YEAR);
	  
	  int day=calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
	  calendar.set(year1, month1, day);
	  Date date2=calendar.getTime();
	  System.err.println("date first  "+date1+"\n date second"+date2);
	  Map mp=new HashMap();
	  
	  SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		Date Fd=format.parse(format.format(date1));
		Date Ld=format.parse(format.format(date2));
	  mp=this.overtimebetmonthReport(Fd, Ld, Group, Department, Catagory, Designation, Shift, Employee_Code);
	  list.add(mp);

	 float hr=(float) mp.get("totalhr");
	 totalhr=totalhr+hr;
	 float daycon=(float) mp.get("totaldaycon");
	 totaldaycon=totaldaycon+daycon;
	 float sal=(float) mp.get("totalsal");
	 totalsal=totalsal+sal; 
	 int emp=(int) mp.get("noofemployees");
	 totalemp=totalemp+emp;
	 calendar.add(Calendar.MONTH, 1); 
	int m= calendar.get(calendar.MONTH);
	int y= calendar.get(calendar.YEAR);
	int d=1;
	calendar.set(y, m, d);
	}
  otr.setDay(list);
  total.put("noofemployees", totalemp);
  
  total.put("totalhr", totalhr);
  total.put("totaldaycon", totaldaycon);
  total.put("totalsal", totalsal);
  otr.setTotal(total);
return otr;
}
}