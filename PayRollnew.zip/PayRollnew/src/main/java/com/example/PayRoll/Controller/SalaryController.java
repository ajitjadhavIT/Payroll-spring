package com.example.PayRoll.Controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.SalaryManager;
import com.example.PayRoll.POJO.Salary;
@Component
@Controller
@RequestMapping("/Salary")

public class SalaryController 
{
	@Autowired
	SalaryManager salaryman;
	
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("empcode")String empcode)
	{
		return salaryman.get(empcode);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/getall")
	public Object getall()
	{
		return salaryman.getall();
	}

}
