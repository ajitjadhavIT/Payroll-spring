package com.example.PayRoll.Manager;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.PayRoll.DAO.AbsentDAO;
import com.example.PayRoll.DAO.DesignationDAO;
import com.example.PayRoll.DAO.EmployeeDAO;
import com.example.PayRoll.DAO.ShiftDAO;

@Component
@Controller

public class AbsentManager 
{
	@Autowired
	AbsentDAO absentdao;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	EmployeeDAO employeeDAO;
	@Autowired
	DesignationDAO designationDAO;
	public Object save(int idabsent,Date date,String shift,String des,String empcode,String Reason ) 
	{
			
		return absentdao.save(idabsent,date,shift,des,empcode,Reason);
		
	}
	public Object get(@RequestParam("Empcode")String empcode,@RequestParam("Date")Date date)
	{
		return absentdao.get(empcode,date );
	}

}
