package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.BasicSalaryDAO;
import com.example.PayRoll.DAO.ReportDAO;


/**
 * 
 * @author HP
 *
 */
@Component
@Controller
public class ReportManager {

	@Autowired
	ReportDAO RDAO;
	@Autowired
	BasicSalaryDAO bsDAO;
	
	
}
