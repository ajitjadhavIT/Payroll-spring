package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="incentive")
public class Incentive
{
	@Id
	int idincentive;
	String incentive_type;
	public int getIdincentive() {
		return idincentive;
	}
	public void setIdincentive(int idincentive) {
		this.idincentive = idincentive;
	}
	public String getIncentive_type() {
		return incentive_type;
	}
	public void setIncentive_type(String incentive_type) {
		this.incentive_type = incentive_type;
	}
	@Override
	public String toString() {
		return "Incentive [idincentive=" + idincentive + ", incentive_type=" + incentive_type + "]";
	}
	
	
}
