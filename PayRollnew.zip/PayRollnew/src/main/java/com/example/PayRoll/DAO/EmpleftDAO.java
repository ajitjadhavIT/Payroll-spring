package com.example.PayRoll.DAO;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Empleft;
import com.example.PayRoll.POJO.Employees;


@Component
@Controller
public class EmpleftDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	
	
@Autowired
EmployeeDAO EmployeeDAO;

	public Empleft save(int idleft,String empcode,String date1,String reason) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date date = sdf.parse(date1);
		
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		Empleft empl=new Empleft();
		empl.setIdempleft(idleft);
		empl.setDate(date);
		empl.setIdEmployees(id);
		empl.setReason(reason);
		session.saveOrUpdate(empl);
		t.commit();
		session.close();
		return empl;
	}

	public List get(String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		Criteria cr=session.createCriteria(Empleft.class);
		cr.add(Restrictions.eq("idEmployees", id));
		
		
		return cr.list();
		
		
	}
	public List getall() 
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		Criteria cr=session.createCriteria(Empleft.class);

		
		
		return cr.list();
		
		
	}
	public List Monthly_left_report(String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//Department, Date , Employee Code, Employee name, Designation, Address, Contact.
		Calendar calendar = Calendar.getInstance();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		calendar.set(year, month-1, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		
		Date Datef= FirstDate;
		Date Datel= LastDate;

		List<Object[]> idEmployees_date=new ArrayList<Object[]>();
		List<Map<String,Object>> Empdata_leftdate=new ArrayList<Map<String,Object>>();
		
		Criteria cr=session.createCriteria(Empleft.class);
		cr.add(Restrictions.ge("date", Datef));
		cr.add(Restrictions.lt("date", Datel));
		Projection p=Projections.property("idEmployees");
		Projection p1=Projections.property("date");
		ProjectionList pt=Projections.projectionList();
		pt.add(p);
		pt.add(p1);
		cr.setProjection(pt);
		idEmployees_date=cr.list();
	
		
		for(Object[] row:idEmployees_date)
		{
			Map x=new HashMap();
			int idEmp=(int) row[0];
			Date leftdate=(Date) row[1];

			
			Criteria c=session.createCriteria(EmpWorkDetails.class);
			c.add(Restrictions.eq("idEmployees", idEmp));
			Projection ap=Projections.property("idDesignation");
			c.setProjection(ap);
			int idDes=((int)c.uniqueResult());
			
			
			Criteria cs=session.createCriteria(Designation.class);
			cs.add(Restrictions.eq("idDesignation", idDes));
			Projection pd=Projections.property("name");
			Projection pd1=Projections.property("idDepartment");
			ProjectionList tp=Projections.projectionList();
			tp.add(pd);
			tp.add(pd1);
			cs.setProjection(tp);
			List<Object[]> des=cs.list();
			String Desname=(String) des.get(0)[0];
			
			Criteria ct=session.createCriteria(Department.class);
			ct.add(Restrictions.eq("idDepartment", des.get(0)[1]));
			Projection a=Projections.property("name");
			ct.setProjection(a);
			String Department_Name=((String)ct.uniqueResult());
			
		Criteria cp=session.createCriteria(Employees.class);
		cp.add(Restrictions.eq("idEmployees", idEmp));
		Projection a3=Projections.property("employeeCode");
		Projection as=Projections.property("emp_First_Name");
		Projection a1=Projections.property("emp_Middle_Name");
		Projection a2=Projections.property("emp_Last_Name");
		Projection a4=Projections.property("address");
		Projection a5=Projections.property("contact_No");
		ProjectionList pa=Projections.projectionList();
		pa.add(a3);
		pa.add(as);
		pa.add(a1);
		pa.add(a2);
		pa.add(a4);
		pa.add(a5);
		cp.setProjection(pa);
		List<Object[]> empdata=cp.list();
		
		String empname=String.valueOf(empdata.get(0)[0])+String.valueOf(empdata.get(0)[1])+String.valueOf(empdata.get(0)[2]);
			
		String EmpCode=(String) empdata.get(0)[3];
			
		String Address=(String) empdata.get(0)[4];
			
		long ContacNO=(long) empdata.get(0)[5];
			x.put("Department", Department_Name);
			x.put("Date", leftdate);
			x.put("Employee Code", EmpCode);
			x.put("Employee name", empname);
			x.put("Designation", Desname);
			x.put("Address", Address);
			x.put("Contact", ContacNO);
			Empdata_leftdate.add(x);
		}
		return Empdata_leftdate;
		
	}
	public List yearly_left_report(String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//Department, Date , Employee Code, Employee name, Designation, Address, Contact.
		Calendar calendar = Calendar.getInstance();
		int year=Integer.parseInt(year1);
		calendar.set(year, 0, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.YEAR, 1);  
	    //calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		Date Datef= FirstDate;
		Date Datel= LastDate;
	
				List<Object[]> idEmployees_date=new ArrayList<Object[]>();
		List<Map<String,Object>> Empdata_leftdate=new ArrayList<Map<String,Object>>();
		
		Criteria cr=session.createCriteria(Empleft.class);
		cr.add(Restrictions.ge("date", Datef));
		cr.add(Restrictions.lt("date", Datel));
		Projection p=Projections.property("idEmployees");
		Projection p1=Projections.property("date");
		ProjectionList pt=Projections.projectionList();
		pt.add(p);
		pt.add(p1);
		cr.setProjection(pt);
		idEmployees_date=cr.list();
	for(Object[] row:idEmployees_date)
		{
			Map x=new HashMap();
			int idEmp=(int) row[0];
			Date leftdate=(Date) row[1];
		
			Criteria c=session.createCriteria(EmpWorkDetails.class);
			c.add(Restrictions.eq("idEmployees", idEmp));
			Projection ap=Projections.property("idDesignation");
			c.setProjection(ap);
			int idDes=((int)c.uniqueResult());
		
			Criteria cs=session.createCriteria(Designation.class);
			cs.add(Restrictions.eq("idDesignation", idDes));
			Projection pd=Projections.property("name");
			Projection pd1=Projections.property("idDepartment");
			ProjectionList tp=Projections.projectionList();
			tp.add(pd);
			tp.add(pd1);
			cs.setProjection(tp);
			List<Object[]> des=cs.list();
			String Desname=(String) des.get(0)[0];
			
			Criteria ct=session.createCriteria(Department.class);
			ct.add(Restrictions.eq("idDepartment", des.get(0)[1]));
			Projection a=Projections.property("name");
			ct.setProjection(a);
			String Department_Name=((String)ct.uniqueResult());
			
		Criteria cp=session.createCriteria(Employees.class);
		cp.add(Restrictions.eq("idEmployees", idEmp));
		Projection a3=Projections.property("employeeCode");
		Projection as=Projections.property("emp_First_Name");
		Projection a1=Projections.property("emp_Middle_Name");
		Projection a2=Projections.property("emp_Last_Name");
		Projection a4=Projections.property("address");
		Projection a5=Projections.property("contact_No");
		ProjectionList pa=Projections.projectionList();
		
		pa.add(as);
		pa.add(a1);
		pa.add(a2);
		pa.add(a3);
		pa.add(a4);
		pa.add(a5);
		cp.setProjection(pa);
		List<Object[]> empdata=cp.list();
		
			String empname=String.valueOf(empdata.get(0)[0])+String.valueOf(empdata.get(0)[1])+String.valueOf(empdata.get(0)[2]);
			long EmpCode=(long) empdata.get(0)[3];
			String Address=(String) empdata.get(0)[4];
			long ContacNO=(long) empdata.get(0)[5];
			x.put("Department", Department_Name);
			x.put("Date", leftdate);
			x.put("Employee Code", EmpCode);
			x.put("Employee name", empname);
			x.put("Designation", Desname);
			x.put("Address", Address);
			x.put("Contact", ContacNO);
			Empdata_leftdate.add(x);
		}
		return Empdata_leftdate;
		
	}

	public List delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Empleft d = (Empleft ) session.createCriteria(Empleft.class)
                 .add(Restrictions.eq("idempleft", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
}
