package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Overtimebetdates {

	
	List day=new ArrayList();
	Map total=new HashMap();
	public List getDay() {
		return day;
	}
	public void setDay(List day) {
		this.day = day;
	}
	public Map getTotal() {
		return total;
	}
	public void setTotal(Map total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "Overtimebetdates [day=" + day + ", total=" + total + "]";
	}
	
	
	
}
