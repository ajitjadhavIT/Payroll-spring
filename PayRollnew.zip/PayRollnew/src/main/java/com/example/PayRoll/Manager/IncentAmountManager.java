package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.IncentAmountDAO;
import com.example.PayRoll.POJO.IncentAmount;
@Component
@Controller
public class IncentAmountManager
{	@Autowired
	IncentAmountDAO incamodao;

	public IncentAmount save(int idinca,String inc,int con,float amount,String emptype) {
		// TODO Auto-generated method stub
		return incamodao.save(idinca,inc,con,amount,emptype);
	}
	public Object get(String empcode) {
		// TODO Auto-generated method stub
		return incamodao.get(empcode);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return incamodao.getall();
	}
	public Object delete(int id) {
		// TODO Auto-generated method stub
		return incamodao.delete(id);
	}
}
