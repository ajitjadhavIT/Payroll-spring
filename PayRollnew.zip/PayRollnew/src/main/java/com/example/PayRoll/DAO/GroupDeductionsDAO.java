package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Deductions;
import com.example.PayRoll.POJO.GroupDeductions;
@Component
public class GroupDeductionsDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmptypeDAO emptypedao;
	@Autowired
	DeductionsDAO deductions;
	
	public GroupDeductions save(int idGroupDeduction,String emptype,String deduction) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		int idemptype=emptypedao.get(emptype).getIdEmpType();
		int idded=(int) deductions.get(deduction);
		GroupDeductions gd=new GroupDeductions();
		gd.setIdGroupDeduction(idGroupDeduction);
		gd.setIdDeductions(idded);
		gd.setIdEmpType(idemptype);
	
		session.saveOrUpdate(gd);
		t.commit();  
		
		session.close();
		
		return gd;
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		Criteria cr=session.createCriteria(GroupDeductions.class);
		
		return cr.list();
	}

}
