package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;

public class salaryFilterMonth {

	List present=new ArrayList();
	List total=new ArrayList();
	public List getPresent() {
		return present;
	}
	public void setPresent(List present) {
		this.present = present;
	}
	public List getTotal() {
		return total;
	}
	public void setTotal(List total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "salaryFilterMonth [present=" + present + ", total=" + total + "]";
	}

	
	
}
