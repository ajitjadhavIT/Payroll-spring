package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="esi")
public class ESI {
//idESI, idEmpType, fromAmount, toAmount, percent
	@Id
	int idESI;
	int idEmpType;
	float fromAmount;
	float toAmount;
	float percent;
	public int getIdESI() {
		return idESI;
	}
	public void setIdESI(int idESI) {
		this.idESI = idESI;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public float getfromAmount() {
		return fromAmount;
	}
	public void setfromAmount(float fromAmount) {
		fromAmount = fromAmount;
	}
	public float gettoAmount() {
		return toAmount;
	}
	public void settoAmount(float toAmount) {
		toAmount = toAmount;
	}
	public float getpercent() {
		return percent;
	}
	public void setpercent(float percent) {
		percent = percent;
	}
	@Override
	public String toString() {
		return "ESI [idESI=" + idESI + ", idEmpType=" + idEmpType + ", fromAmount=" + fromAmount + ", toAmount="
				+ toAmount + ", percent=" + percent + "]";
	}
	
	
}
