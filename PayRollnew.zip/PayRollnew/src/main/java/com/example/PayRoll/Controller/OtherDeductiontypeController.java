package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.OtherDeductiontypeManager;
import com.example.PayRoll.POJO.OtherDeductiontype;
//OtherDeductiontype
@Controller
@RequestMapping("/OtherDeductiontype")
public class OtherDeductiontypeController {

	@Autowired
	OtherDeductiontypeManager odmanager;
	
	@RequestMapping("/save")
	@CrossOrigin()
	@PostMapping

	@ResponseBody
	public OtherDeductiontype save(@RequestParam("id")int id,@RequestParam("name")String name)
	{
		return odmanager.save(id,name);
	}
	
	@RequestMapping("/getall")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object getall()
	{
		return odmanager.getall();
	}
	@RequestMapping("/delete")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("name")String name)
	{
		
			return odmanager.delete(name); 
	
		
	}
}
