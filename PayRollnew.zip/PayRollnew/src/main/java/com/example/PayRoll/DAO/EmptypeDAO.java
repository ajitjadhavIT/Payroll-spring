package com.example.PayRoll.DAO;


import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Emptype;


@Component
@Controller
public class EmptypeDAO 
{	
	@Autowired
	HipernateConfg hipernateConfg;
	
	public Emptype save(int id,String name ) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Emptype empt=new Emptype();
		empt.setIdEmpType(id);
		empt.setName(name);
		session.saveOrUpdate(empt);
		t.commit();
		session.close();
		return empt;
	}

	public Emptype get(String Name)
	{
	Session session = (Session) hipernateConfg.getSession();  
	
	//@SuppressWarnings("deprecation")
			Criteria cr = session.createCriteria(Emptype.class);
			cr.add(Restrictions.eq("name", Name));
			return (Emptype) cr.uniqueResult();
		
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
	
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(Emptype.class);
				
				return cr.list();
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Emptype d = (Emptype ) session.createCriteria(Emptype.class)
                 .add(Restrictions.eq("idEmpType", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
	
}
