package com.example.PayRoll.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.ShiftAllownceDAO;
import com.example.PayRoll.POJO.ShiftAllownce;

@Component
@Controller
@RequestMapping("/shiftallownce")
public class ShiftAllownceController {

	@Autowired
	ShiftAllownceDAO sadao;
	@RequestMapping("/get")
	@GetMapping
	@ResponseBody
	public Object get(@RequestParam("emptype")String emptype)
	{
		return sadao.get(emptype);
	}
	@RequestMapping("/getall")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public List getall()
	{
		return sadao.getall();
	}
	@RequestMapping("/save")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public ShiftAllownce save(@RequestParam("id")int id,@RequestParam("shift")String shift,@RequestParam("allownce")float allownce,@RequestParam("emptype")String emptype)
	{
		return sadao.save(id,shift,allownce,emptype);
	}
	@RequestMapping("/delete")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id") int id)
	{
		return sadao.delete(id);
	}
	
	
}
