package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Table;


public class SalaryDetails {

	int Srno;
	int month;
	int year;
	int date;

	String Designation;
	float PresentDays;
	int Leaves;
	String Shifts;
	float Basic;
	float Allownce;
	float Overtime;
	float Deduction;
	float Salary;
	int Fdesignation;
	int Fworkingdays;
	
	List PerDayInfo=new ArrayList();

	float FBasic;
	float Incentive;
	float FAllownce;
	float FOvertime;
	float PF;
	float PT;
	float ESI;
	float TDS;
	float Welfare;
	float Society;
	float BusCharge;
	float HouseRent;
	float PhoneBill;
	float CanteenDeduction;
	float Advance;
	float Loan;
	float LWP;
	double FinalSalary;
	public int getSrno() {
		return Srno;
	}
	public void setSrno(int srno) {
		Srno = srno;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getDate() {
		return date;
	}
	public void setDate(int date) {
		this.date = date;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public float getPresentDays() {
		return PresentDays;
	}
	public void setPresentDays(float presentDays) {
		PresentDays = presentDays;
	}
	public int getLeaves() {
		return Leaves;
	}
	public void setLeaves(int leaves) {
		Leaves = leaves;
	}
	public String getShifts() {
		return Shifts;
	}
	public void setShifts(String shifts) {
		Shifts = shifts;
	}
	public float getBasic() {
		return Basic;
	}
	public void setBasic(float basic) {
		Basic = basic;
	}
	public float getAllownce() {
		return Allownce;
	}
	public void setAllownce(float allownce) {
		Allownce = allownce;
	}
	public float getOvertime() {
		return Overtime;
	}
	public void setOvertime(float overtime) {
		Overtime = overtime;
	}
	public float getDeduction() {
		return Deduction;
	}
	public void setDeduction(float deduction) {
		Deduction = deduction;
	}
	public float getSalary() {
		return Salary;
	}
	public void setSalary(float salary) {
		Salary = salary;
	}
	public int getFdesignation() {
		return Fdesignation;
	}
	public void setFdesignation(int fdesignation) {
		Fdesignation = fdesignation;
	}
	public int getFworkingdays() {
		return Fworkingdays;
	}
	public void setFworkingdays(int fworkingdays) {
		Fworkingdays = fworkingdays;
	}
	public List<Map> getPerDayInfo() {
		return PerDayInfo;
	}
	public void setPerDayInfo(List perDayInfo) {
		PerDayInfo = perDayInfo;
	}
	public float getFBasic() {
		return FBasic;
	}
	public void setFBasic(float fBasic) {
		FBasic = fBasic;
	}
	public float getIncentive() {
		return Incentive;
	}
	public void setIncentive(float incentive) {
		Incentive = incentive;
	}
	public float getFAllownce() {
		return FAllownce;
	}
	public void setFAllownce(float fAllownce) {
		FAllownce = fAllownce;
	}
	public float getFOvertime() {
		return FOvertime;
	}
	public void setFOvertime(float fOvertime) {
		FOvertime = fOvertime;
	}
	public float getPF() {
		return PF;
	}
	public void setPF(float pF) {
		PF = pF;
	}
	public float getPT() {
		return PT;
	}
	public void setPT(float pT) {
		PT = pT;
	}
	public float getESI() {
		return ESI;
	}
	public void setESI(float eSI) {
		ESI = eSI;
	}
	public float getTDS() {
		return TDS;
	}
	public void setTDS(float tDS) {
		TDS = tDS;
	}
	public float getWelfare() {
		return Welfare;
	}
	public void setWelfare(float welfare) {
		Welfare = welfare;
	}
	public float getSociety() {
		return Society;
	}
	public void setSociety(float society) {
		Society = society;
	}
	public float getBusCharge() {
		return BusCharge;
	}
	public void setBusCharge(float busCharge) {
		BusCharge = busCharge;
	}
	public float getHouseRent() {
		return HouseRent;
	}
	public void setHouseRent(float houseRent) {
		HouseRent = houseRent;
	}
	public float getPhoneBill() {
		return PhoneBill;
	}
	public void setPhoneBill(float phoneBill) {
		PhoneBill = phoneBill;
	}
	public float getCanteenDeduction() {
		return CanteenDeduction;
	}
	public void setCanteenDeduction(float canteenDeduction) {
		CanteenDeduction = canteenDeduction;
	}
	public float getAdvance() {
		return Advance;
	}
	public void setAdvance(float advance) {
		Advance = advance;
	}
	public float getLoan() {
		return Loan;
	}
	public void setLoan(float loan) {
		Loan = loan;
	}
	public float getLWP() {
		return LWP;
	}
	public void setLWP(float lWP) {
		LWP = lWP;
	}
	public double getFinalSalary() {
		return FinalSalary;
	}
	public void setFinalSalary(double finalSalary) {
		FinalSalary = finalSalary;
	}
	@Override
	public String toString() {
		return "SalaryDetails [Srno=" + Srno + ", month=" + month + ", year=" + year + ", date=" + date
				+ ", Designation=" + Designation + ", PresentDays=" + PresentDays + ", Leaves=" + Leaves + ", Shifts="
				+ Shifts + ", Basic=" + Basic + ", Allownce=" + Allownce + ", Overtime=" + Overtime + ", Deduction="
				+ Deduction + ", Salary=" + Salary + ", Fdesignation=" + Fdesignation + ", Fworkingdays=" + Fworkingdays
				+ ", PerDayInfo=" + PerDayInfo + ", FBasic=" + FBasic + ", Incentive=" + Incentive + ", FAllownce="
				+ FAllownce + ", FOvertime=" + FOvertime + ", PF=" + PF + ", PT=" + PT + ", ESI=" + ESI + ", TDS=" + TDS
				+ ", Welfare=" + Welfare + ", Society=" + Society + ", BusCharge=" + BusCharge + ", HouseRent="
				+ HouseRent + ", PhoneBill=" + PhoneBill + ", CanteenDeduction=" + CanteenDeduction + ", Advance="
				+ Advance + ", Loan=" + Loan + ", LWP=" + LWP + ", FinalSalary=" + FinalSalary + "]";
	}
	
	
}
