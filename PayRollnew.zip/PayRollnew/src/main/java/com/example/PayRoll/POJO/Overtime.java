package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="overtime")
public class Overtime 
{//idOverTime, Date, idShift, idDesignation, idEmoployees, hours
	@Id
	int idOvertime;
	Date date;
	int idShift;
	int idDesignation;
	int idEmployees;
	float hours;
	public int getIdOvertime() {
		return idOvertime;
	}
	public void setIdOvertime(int idOvertime) {
		this.idOvertime = idOvertime;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public int getIdDesignation() {
		return idDesignation;
	}
	public void setIdDesignation(int idDesignation) {
		this.idDesignation = idDesignation;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public float getHours() {
		return hours;
	}
	public void setHours(float hours) {
		this.hours = hours;
	}
	@Override
	public String toString() {
		return "Overtime [idOvertime=" + idOvertime + ", date=" + date + ", idShift=" + idShift + ", idDesignation="
				+ idDesignation + ", idEmployees=" + idEmployees + ", hours=" + hours + "]";
	}
	
	
	
	
	
	
}
