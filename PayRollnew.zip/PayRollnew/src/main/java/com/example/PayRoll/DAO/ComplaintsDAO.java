package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Catagory;
import com.example.PayRoll.POJO.Complaints;
@Component
@Controller
public class ComplaintsDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmployeeDAO empdao;
	public String save(int idcom,String empcode,Date date,String reason,String complaintby)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int idemp=empdao.get(empcode).getIdEmployees();
		Complaints c=new Complaints();
		c.setIdComplaints(idcom);
		c.setComplaintBy(complaintby);
		c.setDate(date);
		c.setIdEmployees(idemp);
		c.setReason(reason);
		session.saveOrUpdate(c);
		t.commit();  
		session.close();
		return "Saved Succesfully";
		
	}
	
	public Object get(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Query u=session.createQuery("select idEmployees from Employees where employeeCode = :empcode");
		u.setParameter("empcode", empcode);
		int idEmployee=(int) u.uniqueResult();
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Complaints.class);
		cr.add(Restrictions.eq("idEmployees", idEmployee));
		return (Complaints) cr.uniqueResult();
		
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		Criteria cr = session.createCriteria(Complaints.class);
		
		return  cr.list();
	
	}
}
