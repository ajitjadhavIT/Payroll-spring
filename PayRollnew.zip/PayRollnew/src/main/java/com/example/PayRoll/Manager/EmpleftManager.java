package com.example.PayRoll.Manager;



import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.EmpleftDAO;
import com.example.PayRoll.POJO.Empleft;
@Component
@Controller
public class EmpleftManager 
{
	@Autowired
	EmpleftDAO empldao;
	public Empleft save(int idleft,String empcode,String date,String reason) throws ParseException
	{
		
		return empldao.save(idleft,empcode,date,reason);
	}
	public Object get(String empcode)
	{
		
		return empldao.get(empcode);
	}
	public List getall() {
		// TODO Auto-generated method stub
		return empldao.getall();
	}
	public List delete(int id) {
		// TODO Auto-generated method stub
		return empldao.delete(id);
	}
}
