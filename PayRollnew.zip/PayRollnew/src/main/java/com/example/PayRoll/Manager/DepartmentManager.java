package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.DepartmentDAO;
import com.example.PayRoll.POJO.Department;
@Component
@Controller
public class DepartmentManager
{
	@Autowired
	DepartmentDAO deptdao;
	
	public Department save(int id,String name)
	{
		return deptdao.save(id,name);
	}
	public Object get(String name)
	{
		return deptdao.get(name);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return deptdao.getall();
	}
	public Object delete(String name) {
		// TODO Auto-generated method stub
		return deptdao.delete(name);
	}
}
