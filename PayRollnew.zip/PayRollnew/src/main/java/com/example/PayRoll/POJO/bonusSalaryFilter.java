package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class bonusSalaryFilter {

	List present=new ArrayList();
	Map summary=new HashMap();
	Map total=new HashMap();
	public List getPresent() {
		return present;
	}
	public void setPresent(List present) {
		this.present = present;
	}
	public Map getSummary() {
		return summary;
	}
	public void setSummary(Map summary) {
		this.summary = summary;
	}
	public Map getTotal() {
		return total;
	}
	public void setTotal(Map total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "bonusSalaryFilter [present=" + present + ", summary=" + summary + ", total=" + total + "]";
	}
	
	
	
}
