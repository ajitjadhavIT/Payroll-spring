package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.DeductionTypeDAO;
import com.example.PayRoll.POJO.DeductionType;
@Controller
@Component
public class DeductionTypemanager {

	@Autowired
	DeductionTypeDAO dtDAO;
	
	public DeductionType save(int id,String name) {
		// TODO Auto-generated method stub
		return dtDAO.save(id,name);
	}

	public Object getall() {
		// TODO Auto-generated method stub
		return dtDAO.getall();
	}

	

}
