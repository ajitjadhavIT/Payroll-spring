package com.example.PayRoll.Manager;


import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.AttendanceDAO;
import com.example.PayRoll.POJO.Attendance;

@Component
@Controller
public class AttendanceManager 
{
	@Autowired
	AttendanceDAO attdao;
	
	public String save(int idAttendance,Date date,String shift,String Shortform,String empcode)
	{
		return attdao.save(idAttendance,date,shift,Shortform,empcode);
	}
	public Attendance get(Date dt,String empcode)
	{
		return attdao.get(dt,empcode);
	}
	

}
