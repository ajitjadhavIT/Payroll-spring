package com.example.PayRoll.POJO;

import java.util.Date;

public class OtherDeductions {

	//idOtherDeduction, idEmployees, idOtherDeductionType, Date, amount
	int idOtherDeductions;
	int idEmployee;
	Date date;
	int idOtherDeductionType;
	float amount;
	public int getIdOtherDeductions() {
		return idOtherDeductions;
	}
	public void setIdOtherDeductions(int idOtherDeductions) {
		this.idOtherDeductions = idOtherDeductions;
	}
	public int getIdEmployee() {
		return idEmployee;
	}
	public void setIdEmployee(int idEmployee) {
		this.idEmployee = idEmployee;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getIdOtherDeductionType() {
		return idOtherDeductionType;
	}
	public void setIdOtherDeductionType(int idOtherDeductionType) {
		this.idOtherDeductionType = idOtherDeductionType;
	}
	public float getamount() {
		return amount;
	}
	public void setamount(float amount) {
		amount = amount;
	}
	@Override
	public String toString() {
		return "OtherDeductions [idOtherDeductions=" + idOtherDeductions + ", idEmployee=" + idEmployee + ", date="
				+ date + ", idOtherDeductionType=" + idOtherDeductionType + ", amount=" + amount + "]";
	}
	
}
