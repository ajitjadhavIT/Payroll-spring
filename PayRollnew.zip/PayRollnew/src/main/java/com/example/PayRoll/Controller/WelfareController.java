package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.WelfareManager;
import com.example.PayRoll.POJO.Welfare;
@Controller
@RequestMapping("Wellfare")
public class WelfareController {

		@Autowired
		WelfareManager wfManager;
		
		@RequestMapping("/save")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Welfare save(@RequestParam("id")int id,@RequestParam("emptype")String emptype,@RequestParam("month")int month,@RequestParam("amount")float amount)
		{
			
			return wfManager.save(id,emptype,month,amount); 
		}
		
		
		@RequestMapping("/get")
		@PostMapping
		@ResponseBody
		public Object get(@RequestParam("id")String id)
		{
			
				return wfManager.get(id); 
			
		}
		@RequestMapping("/getall")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Object getall()
		{
			
				return wfManager.getall(); 
			
		}
		
		@RequestMapping("/delete")
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public Object delete(@RequestParam("id")int id)
		{
			
				return wfManager.delete(id); 
			
		}
}
