package com.example.PayRoll.Controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.EmployeeDAO;
import com.example.PayRoll.DAO.ReportDAO;
import com.example.PayRoll.Manager.BasicSalaryManager;
import com.example.PayRoll.Manager.ReportManager;
import com.example.PayRoll.POJO.Salaryreport;

@Controller

@RequestMapping("Report")
public class ReportController {

	@Autowired
	ReportManager RManager;
	@Autowired
	ReportDAO reportDAO;
	@Autowired
	EmployeeDAO empdao;

	@RequestMapping("/SalaryReports")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public List SalaryReports(@RequestParam("empcode") String empcode,@RequestParam("date") String date)
	{
		
		return reportDAO.SalaryReports(empcode,date);
		
	}
	@RequestMapping("/WegeSheet")
	@PostMapping
	@ResponseBody
	public Object wegsheet(@RequestParam("month")String month,@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		String patternDouble = "[-+]?[0-9]*\\.?[0-9]+"; // pattern for int/float/double;
	
	if(!year.matches(patternInt))
	{
		return "Enter valid year";
	}
	else if(!month.matches(patternInt))
	{
		return "Enter valid month";
	}
	
	else {
		return reportDAO.WageSheet(month, year);
	}
	}
	
	@RequestMapping("/SalarySlip")
	@PostMapping
	@ResponseBody
	public Object SalarySlip(@RequestParam("month")String month,@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		String patternDouble = "[-+]?[0-9]*\\.?[0-9]+"; // pattern for int/float/double;
	
	if(!year.matches(patternInt))
	{
		return "Enter valid year";
	}
	else if(!month.matches(patternInt))
	{
		return "Enter valid month";
	}
	
	else {
		return reportDAO.SalarySlip(month, year);
	}
	}
	
	@RequestMapping("/Bonus")
	@PostMapping
	@ResponseBody
	public Object Bonus(@RequestParam("year")String year)
	{
		
		return reportDAO.Bonus(year);
	
	}
	
	
	@RequestMapping("/EmployeeInfo")
	@PostMapping
	@ResponseBody
	public Object EmployeeInfo(@RequestParam("empcode")String empcode)
	{

		String patternInt = "\\d+";
		String patternDouble = "[-+]?[0-9]*\\.?[0-9]+"; // pattern for int/float/double;
		
	if(	empcode.isEmpty())
		return "Enter valid Empcode";
	else
		return reportDAO.EmployeeInfo(empcode);
	}
	
	@RequestMapping("/SalaryReport")
	@PostMapping
	@ResponseBody
	public Object SalaryReport(@RequestParam("Group")String Group,@RequestParam("month")String Month,@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		String patternDouble = "[-+]?[0-9]*\\.?[0-9]+"; // pattern for int/float/double;
		
		if(Group.isEmpty())
		{
			return "Enter valid Group";
		}
		else if(!Month.matches(patternInt))
		{
			return "Enter valid month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else {
		return reportDAO.SalaryReportMonth(Group, Month, year);
		}
	}
	
	//DeductionMonthly
	@RequestMapping("/DeductionMonthly")
	@PostMapping
	@ResponseBody
	public Object DeductionMonthly(@RequestParam("DeductionName")String Dname,@RequestParam("month")String Month,@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		String patternDouble = "[-+]?[0-9]*\\.?[0-9]+"; // pattern for int/float/double;
		
		if(Dname.isEmpty())
		{
			return "Enter valid Group";
		}
		else if(!Month.matches(patternInt))
		{
			return "Enter valid month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else {
		return reportDAO.DeductionMonthly(Dname, Month, year);
		}
	}
	
	
	@RequestMapping("/DayPresentDetails")
	@PostMapping
	@ResponseBody
	public List DayPresentDetails(@RequestParam("date")Date dt)
	{
		return reportDAO.DayPresentDetails(dt);
	}
	
	@RequestMapping("/TotalPF")
	@PostMapping
	@ResponseBody
	public List TotalPF()
	{
		return reportDAO.TotalPF();
	}
	
	@RequestMapping("/TotalEarnReportmonth")
	@PostMapping
	@ResponseBody
	public Object TotalEarnReport(@RequestParam("month")String month,@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		String patternDouble = "[-+]?[0-9]*\\.?[0-9]+"; // pattern for int/float/double;
		
		
		if(!month.matches(patternInt))
		{
			return "Enter valid month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else {
		return reportDAO.TotalEarnReport(month, year);
		}
	}
	
	@RequestMapping("/TotalEarnReportyear")
	@PostMapping
	@ResponseBody
	public Object TotalEarnReportyear(@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else
		{
		return reportDAO.yearlyEarning(year);
		}
	}
	
	@RequestMapping("/TotalDeductionreport")
	@PostMapping
	@ResponseBody
	public Object TotalDeductionreport(@RequestParam("month")String month,@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
	
		if(!month.matches(patternInt))
		{
			return "Enter valid month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else {
		return reportDAO.TotalDeductionReport(month,year);
		}
	}
	
	@RequestMapping("/TotalDeductionyear")
	@PostMapping
	@ResponseBody
	public Object TotalDeductionyear(@RequestParam("year")String year)
	{
		String patternInt = "\\d+";
		if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else
		{
		
		return reportDAO.TotalDeductionyear(year);
		}
	}
	
	@RequestMapping("/TotalMonthlyincentive")
	@PostMapping
	@ResponseBody
	public Object TotalMonthlyinc(@RequestParam("Startdate")String month,@RequestParam("enddate")String year)
	{
		
		
	
		return reportDAO.IncentiveGrpByMonth(month, year);
		
	}
	
	@RequestMapping("/TotalMonthlySalary")
	@PostMapping
	@ResponseBody
	public Object TotalMonthlysal(@RequestParam("Startdate")String month,@RequestParam("enddate")String year)
	{
		
		return reportDAO.SalaryGrpByMonth(month, year);
		
	}
	
	
	@RequestMapping("/Totalyearincentive")
	@PostMapping
	@ResponseBody
	public Object Totalyearinc(@RequestParam("stryear")String stryear,@RequestParam("endyear")String endyear)
	{
		
		return reportDAO.IncentiveGrpByYear(stryear, endyear);
		
	}
	
	@RequestMapping("/TotalyearSalary")
	@PostMapping
	@ResponseBody
	public Object Totalyearsal(@RequestParam("stryear")String stryear,@RequestParam("endyear")String endyear)
	{
		
		return reportDAO.SalaryGrpByYear(stryear, endyear);
		
	}
	
	@RequestMapping("/TotalMonthlydept")
	@PostMapping
	@ResponseBody
	public Object TotalMonthlydept(@RequestParam("month")int month,@RequestParam("year")int year,@RequestParam("Deptname")String Deptname)
	{
		
		return reportDAO.monthSalGrpBydept(month, year, Deptname);
		
	}
	
	@RequestMapping("/TotalyearDept")
	@PostMapping
	@ResponseBody
	public Object TotalyearDept(@RequestParam("year")int year,@RequestParam("Deptname")String Deptname)
	{
		
		return reportDAO.yearSalGrpBydept(year, Deptname);
		
	}
	

	
	@RequestMapping("/YearBonus")
	@PostMapping
	@ResponseBody
	public Object YearBonus(@RequestParam("year") String year)
	{
		if(year.isEmpty())
		{
			return "Enter valid year";
		}
		return reportDAO.YearBonus(year);
	}
	
	

	@RequestMapping("/topBonus")
	@PostMapping
	@ResponseBody
	public Object topBonus(@RequestParam("year") String year,@RequestParam("limit") int limit)
	{
		
		
				return reportDAO.TopEmpBonus(year, limit);
			
		
		}
	
	
	@RequestMapping("/TopEmpAttendance")
	@PostMapping
	@ResponseBody
	public Object TopEmpAttendance(@RequestParam("year") String year,@RequestParam("limit") int limit)
	{
		
				return reportDAO.TopEmpAttendance(year, limit);
			
		
		}
	
	
	
	@RequestMapping("/topFemaleEmp")
	@PostMapping
	@ResponseBody
	public Object topFemaleEmp(@RequestParam("year") String year,@RequestParam("limit") int limit)
	{
		
				return reportDAO.topFemaleEmp(year, limit);
			
		
		}
	
	@RequestMapping("/topAlllownceEmp")
	@PostMapping
	@ResponseBody
	public Object topAlllownceEmp(@RequestParam("year") int year,@RequestParam("limit") int limit)
	{
		
				return reportDAO.TopThirdShiftAllownce(year, limit);
			
		
		}
	
	@GetMapping
	@ResponseBody
	@RequestMapping("/Empticket")
	public Object CardPrint(@RequestParam("empcode")String empcode,@RequestParam("date")Date date)
	{
		if(empcode.isEmpty())
		{
			return "Enter the Empcode";
		}
		else
		{
		return empdao.CardPrint(empcode, date);
		}
	}
	
	
	
	@RequestMapping("/WorstEmpAttendance")
	@PostMapping
	@ResponseBody
	public Object WorstEmpAttendance(@RequestParam("year") String year,@RequestParam("limit") int limit)
	{
		
				return reportDAO.WorstEmpAttendance(year, limit);
			
		
		}
	
	
	

	@RequestMapping("/Bonus_by_GRP")
	@PostMapping
	@ResponseBody
	public Object Bonus_by_GRP(@RequestParam("year") String year,@RequestParam("group") String grp)
	{
		
		return reportDAO.Bonus_by_GRP(year, grp);
		
	}
	
	@RequestMapping("/Bonus_by_Dept")
	@PostMapping
	@ResponseBody
	public Object Bonus_by_Dept(@RequestParam("year") String year,@RequestParam("DeptName") String dept)
	{
		return reportDAO.Bonus_by_Dept(year, dept);
		
	}
	//WageSheet_Grp
	
	@RequestMapping("/WageSheet_Grp")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object WageSheet_Grp(@RequestParam("date") String date,@RequestParam("group") String grp)
	{
		return reportDAO.WageSheet_Grp(date, grp);
		
	}
	
	
	//WageSheet_Dept
	@RequestMapping("/WageSheet_Dept")
	@PostMapping
	@ResponseBody
	public Object WageSheet_Dept(@RequestParam("month") String month1,@RequestParam("Dept") String dept,@RequestParam("year") String year1)
	{
		return reportDAO.WageSheet_Dept(month1, dept, year1);
		
	}
	
	//TotalDeductionReport_Dept
	@RequestMapping("/TotalDeductionReport_Dept")
	@PostMapping
	@ResponseBody
	public Object TotalDeductionReport_Dept(@RequestParam("month") String month1,@RequestParam("Dept") String dept,@RequestParam("year") String year1)
	{
		return reportDAO.TotalDeductionReport_Dept(month1, dept, year1);
		
	}
	
	
	//TotalEarnReport_dept
	
	@RequestMapping("/TotalEarnReport_dept")
	@PostMapping
	@ResponseBody
	public Object TotalEarnReport_dept(@RequestParam("month") String month1,@RequestParam("Dept") String dept,@RequestParam("year") String year1)
	{
		return reportDAO.TotalEarnReport_dept(month1, dept, year1);
		
	}
	
	//Salary
	@CrossOrigin()
	@RequestMapping("/salary")
	@GetMapping
	@ResponseBody
	public List sal(@RequestParam("date") String date,@RequestParam("empcode") String empcode)
	{
		return reportDAO.Salary(empcode,date);
		
	}
	
}
