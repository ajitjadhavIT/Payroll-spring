package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="deductionsetting")
public class DeductionSetting {
	@Id
	int iddeductionsetting;
	int condition1;
	float minimum_condition;
	float maximum_condition;
	int idDeductionType;
	float amount;
	int idDeductions;
	public int getIddeductionsetting() {
		return iddeductionsetting;
	}
	public void setIddeductionsetting(int iddeductionsetting) {
		this.iddeductionsetting = iddeductionsetting;
	}
	public int getCondition1() {
		return condition1;
	}
	public void setCondition1(int condition1) {
		this.condition1 = condition1;
	}
	public float getMinimum_condition() {
		return minimum_condition;
	}
	public void setMinimum_condition(float minimum_condition) {
		this.minimum_condition = minimum_condition;
	}
	public float getMaximum_condition() {
		return maximum_condition;
	}
	public void setMaximum_condition(float maximum_condition) {
		this.maximum_condition = maximum_condition;
	}
	public int getIdDeductionType() {
		return idDeductionType;
	}
	public void setIdDeductionType(int idDeductionType) {
		this.idDeductionType = idDeductionType;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public int getIdDeductions() {
		return idDeductions;
	}
	public void setIdDeductions(int idDeductions) {
		this.idDeductions = idDeductions;
	}
	
	

}
