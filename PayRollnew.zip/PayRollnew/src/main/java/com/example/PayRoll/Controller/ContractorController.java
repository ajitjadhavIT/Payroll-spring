package com.example.PayRoll.Controller;

import java.util.ArrayList;
import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.example.PayRoll.DAO.ContractorDAO;
//import com.example.PayRoll.Manager.ContractorManager;
//import com.example.PayRoll.POJO.Contractor;


//
//@Controller
//
//@RequestMapping("/Contractor")
@SuppressWarnings("rawtypes")
public class ContractorController implements RequestHandler<ContractorDAO,List>
{  

	
//	@GetMapping
//	@CrossOrigin()
//	@ResponseBody
//	@RequestMapping("/save")
//	
//	public Contractor save(@RequestParam("id")int id,@RequestParam("name")String name,@RequestParam("addr")String addr,@RequestParam("contact")int contact,@RequestParam("email")String email)
//	{
//	
//			return cManager.save(id,name,addr,contact,email);
//	
//	}
//	@RequestMapping("/get")
//	@PostMapping
//	@CrossOrigin()
//	@ResponseBody
//	public List get(@RequestParam("Name") String name)
//	{
//		return cManager.get(name);
//	}
//	@CrossOrigin()
//	@RequestMapping("/getall")
//	@PostMapping
//	@ResponseBody
	
	
@Override
public List handleRequest(ContractorDAO c, Context context) {
	List a= new ArrayList<>();
	
	a=c.getall();
	return a;
	

}


	
	
//	@RequestMapping("/delete")
//	@PostMapping
//	@CrossOrigin()
//	@ResponseBody
//	public List delete(@RequestParam("id") int id)
//	{
//		return cManager.delete(id);
//	}
}
