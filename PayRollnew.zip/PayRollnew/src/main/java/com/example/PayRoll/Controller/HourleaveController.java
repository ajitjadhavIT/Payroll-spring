package com.example.PayRoll.Controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.HoursleaveManager;
import com.example.PayRoll.POJO.Hoursleave;
@Component
@Controller
@RequestMapping("/Hourleave")
public class HourleaveController 
{
	@Autowired
	HoursleaveManager hlman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("empcode")String empcode,@RequestParam("date")Date dt)
	{
		return hlman.get(empcode,dt);
	}
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	@RequestMapping("/getall")
	public Object getall()
	{
		return hlman.getall();
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Hoursleave save(@RequestParam("id")int id,@RequestParam("date")Date date,@RequestParam("shift")String shift,@RequestParam("designation")String des,@RequestParam("hours")int hr,@RequestParam("empcode")String empcode)
	{  
		return hlman.save(id,date,shift,des,hr,empcode); 
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id")int id)
	{
		return hlman.delete(id); 
	}
}
