package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.IncentAmount;
import com.example.PayRoll.POJO.Shift;
@Component
@Controller
public class IncentAmountDAO 
{	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmployeeDAO employeeDAO;
    @Autowired
    EmptypeDAO EmptypeDAO;
    @Autowired
    IncentiveDAO incdao;
	public IncentAmount save(int idinca,String inc,int con,float amount,String emptype)
	{	
		Session session = (Session) hipernateConfg.getSession(); 
		Transaction t = session.beginTransaction(); 
		int id1=0;
		int idinc=incdao.get(inc).getIdincentive();
		int idEmpType=EmptypeDAO.get(emptype).getIdEmpType();
		
		IncentAmount incentAmount=new IncentAmount();
		incentAmount.setIdIncentiveamount(idinca);
		incentAmount.setIdincentive(idinc);
		incentAmount.setCondition1(con);
		incentAmount.setAmount(amount);
		incentAmount.setIdEmpType(idEmpType);
		session.saveOrUpdate(incentAmount);
		t.commit();  
		session.close();
		
		return incentAmount;
		
	}

	public List get(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession(); 
		Transaction t = session.beginTransaction(); 
		Employees emp=(Employees) employeeDAO.get(empcode);
		int idemptype=emp.getIdEmpType();
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(IncentAmount.class);
		cr.add(Restrictions.eq("idEmpType", idemptype));
		return  cr.list();
		
		}
	
	public List getall()
	{
		Session session = (Session) hipernateConfg.getSession(); 
	
		Criteria cr = session.createCriteria(IncentAmount.class);
	
		return  cr.list();
		
		}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		IncentAmount d = (IncentAmount ) session.createCriteria(IncentAmount.class)
                 .add(Restrictions.eq("idIncentiveamount", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
