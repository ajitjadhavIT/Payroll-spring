package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.BonusSetting;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.ShiftAllownce;
import com.example.PayRoll.POJO.Welfare;
@Component
public class ShiftAllownceDAO {
	

	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	EmptypeDAO emptypedao;
	
	public List get(String emptype) {
		Session session = (Session) hipernateConfg.getSession();
		int idemptype=emptypedao.get(emptype).getIdEmpType();
		System.err.println(idemptype);
		Criteria cr=session.createCriteria(ShiftAllownce.class);
		cr.add(Restrictions.eq("idEmpType", idemptype));
		return cr.list();
		
	}
	public List getall() {
		 Session session = (Session) hipernateConfg.getSession();
		 
			Criteria cr=session.createCriteria(ShiftAllownce.class);
		
	
		return cr.list();
		
	}
	public ShiftAllownce save(int id, String shift, float allownce, String emptype) {
	
		 Session session = (Session) hipernateConfg.getSession(); 
			Transaction t = session.beginTransaction();  
			int idemptype=emptypedao.get(emptype).getIdEmpType();
			Criteria cr=session.createCriteria(Shift.class);
			cr.add(Restrictions.eq("name", shift));
			Projection pr=Projections.property("idShift");
			cr.setProjection(pr);
			int idShift=(int) cr.uniqueResult();
				
			ShiftAllownce sa=new ShiftAllownce();
			sa.setIdShiftAllownce(id);
			sa.setIdShift(idShift);
			sa.setIdEmpType(idemptype);
			sa.setAllownce(allownce);
			session.saveOrUpdate(sa);
			t.commit();
		return sa;
	}
	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		ShiftAllownce d = (ShiftAllownce ) session.createCriteria(ShiftAllownce.class)
                 .add(Restrictions.eq("idShiftAllownce", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
	
	
	
	
}
