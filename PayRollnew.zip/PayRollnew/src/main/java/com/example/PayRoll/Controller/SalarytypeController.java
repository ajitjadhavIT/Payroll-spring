package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.SalarytypeManager;
import com.example.PayRoll.POJO.Salarytype;

@Component
@Controller
@RequestMapping("/Salarytype")

public class SalarytypeController
{
	@Autowired
	SalarytypeManager saltman;
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Salarytype get(@RequestParam("Name")String Name)
	{
		return saltman.get(Name);
	}
	@GetMapping
	@ResponseBody
	@RequestMapping("/getall")
	public List getall()
	{
		return saltman.getall();
	}
	@GetMapping
	@ResponseBody
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Salarytype save(@RequestBody Salarytype st)
	{
		
		return saltman.save(st);
	}
}
