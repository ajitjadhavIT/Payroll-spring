package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class Attd_leave_reportbyMonth 
{
	List presentreportBetMonth=new ArrayList();

	List leavereportbetMonth=new ArrayList();
	
	List TotalbetMonth=new ArrayList();

	public List getPresentreportBetMonth() {
		return presentreportBetMonth;
	}

	public void setPresentreportBetMonth(List presentreportBetMonth) {
		this.presentreportBetMonth = presentreportBetMonth;
	}

	public List getLeavereportbetMonth() {
		return leavereportbetMonth;
	}

	public void setLeavereportbetMonth(List leavereportbetMonth) {
		this.leavereportbetMonth = leavereportbetMonth;
	}

	public List getTotalbetMonth() {
		return TotalbetMonth;
	}

	public void setTotalbetMonth(List totalbetMonth) {
		TotalbetMonth = totalbetMonth;
	}

	
}
