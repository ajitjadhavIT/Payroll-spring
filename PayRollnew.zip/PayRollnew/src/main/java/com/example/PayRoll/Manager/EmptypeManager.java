package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.EmptypeDAO;
import com.example.PayRoll.POJO.Emptype;
@Component
@Controller
public class EmptypeManager 
{	@Autowired
	EmptypeDAO empdao;

	public Emptype save( int id,String name)
	{
		return empdao.save(id,name);
	}
	public Object get(String Name)
	{
		return empdao.get(Name);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return  empdao.getall();
	}
	public Object delete(int id) {
		// TODO Auto-generated method stub
		return  empdao.delete(id);
	}
}
