package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import com.example.PayRoll.DAO.SalaryDAO;
import com.example.PayRoll.POJO.Salary;
@Component
@Controller
public class SalaryManager 
{	@Autowired
	SalaryDAO salarydao;
	public String save(Salary s) {
		// TODO Auto-generated method stub
		return salarydao.save(s);
	}
	public Object get(String empcode) {
		// TODO Auto-generated method stub
		return salarydao.get(empcode);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return salarydao.getall();
	}
}
