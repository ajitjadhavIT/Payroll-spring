package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.EmptypeManager;
import com.example.PayRoll.POJO.Emptype;
@Component
@Controller
@RequestMapping("/Emptype")
public class EmptypeController
{
	@Autowired
	EmptypeManager emptman;
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("name")String name)
	{
		return emptman.get(name) ;
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/save")
	public Emptype save(@RequestParam("id")int id,@RequestParam("name")String name)
	{	
			return emptman.save(id,name);
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public Object getall()
	{
		return emptman.getall() ;
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id")int id)
	{
		return emptman.delete(id); 
	}
}
