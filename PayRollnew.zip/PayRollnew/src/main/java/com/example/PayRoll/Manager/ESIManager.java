package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.PayRoll.DAO.ESIDAO;
import com.example.PayRoll.POJO.ESI;
@Controller
@Component
public class ESIManager {

	@Autowired
	ESIDAO eSIDAO;
	
	public String save(ESI esi) {
		
		
		
		return eSIDAO.save(esi);
	}

	public Object get() {
		// TODO Auto-generated method stub
		return eSIDAO.get();
	}

}
