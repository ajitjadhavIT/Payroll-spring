package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Catagory;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Shift;

@Component
@Controller
public class DesignationDAO
{
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	CategoryDAO catagoryDAO;
	@Autowired
	DepartmentDAO deptdao;
	public Designation save(int iddes,String name,String sft,String deptName,String CatName,float sal) 
	{	
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
	
			
		int idDept=deptdao.get(deptName).getIdDepartment();
		int idcat=catagoryDAO.get(CatName).getIdCatagory();
		Designation d=new Designation();
		d.setIdDesignation(iddes);
		d.setIdCatagory(idcat);
		d.setIdDepartment(idDept);
		d.setName(name);
		d.setSalary(sal);
		d.setShort_Form(sft);

		session.saveOrUpdate(d);
		t.commit();
		session.close();
		return d;
	}

	public Designation get(String Shortform)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
				Criteria cr = session.createCriteria(Designation.class);
				cr.add(Restrictions.eq("short_Form", Shortform));
				return (Designation) cr.uniqueResult();
		
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		
				Criteria cr = session.createCriteria(Designation.class);
				return  cr.list();
	}

	public Object delete(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Designation d = (Designation ) session.createCriteria(Designation.class)
                 .add(Restrictions.eq("name", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
