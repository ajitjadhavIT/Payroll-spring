package com.example.PayRoll.DAO;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.ProfessionalTax;

@Controller
@Component


public class ProfessionalTaxDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	
	
	
	public String save(ProfessionalTax pt) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		session.saveOrUpdate(pt);
		t.commit();  
		session.close();
		
		return "Saved Successfully";
		
		
	}

	public Object get(String id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(ProfessionalTax.class);
				cr.add(Restrictions.eq("id", id));
				return (ProfessionalTax) cr.uniqueResult();
				
		
	}

}
