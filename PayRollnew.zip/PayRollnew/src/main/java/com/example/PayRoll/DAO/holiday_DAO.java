package com.example.PayRoll.DAO;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.DeductionSetting;
import com.example.PayRoll.POJO.Holiday;
@Controller
@Component
public class holiday_DAO
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	public List get(int Month,int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, Month-1, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		DateFormat df= new SimpleDateFormat("yyyy/MM/dd");
		String Datef= df.format(FirstDate);
		String Datel= df.format(LastDate);
	
		List<HashMap> Holiday=new ArrayList<HashMap>();
		
		Criteria cr=session.createCriteria(Holiday.class);
		cr.add(Restrictions.ge("date", Datef));
		cr.add(Restrictions.lt("date", Datel));
		Projection pr=Projections.rowCount();
		cr.setProjection(pr);
		Holiday=cr.list();
		
	
		session.close(); 
		
		return Holiday;
	}

	public Holiday save(int id,String dt1,String desc,int year) throws ParseException 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date dt = sdf.parse(dt1);
		 
		Holiday hol=new Holiday();
		hol.setIdHoliday(id);
		hol.setDate(dt);
		hol.setDescription(desc);
		hol.setYear(year);
		session.saveOrUpdate(hol);
		t.commit();  
		session.close();
		
		
		return hol;
	}

	public List Holiday_Report(String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Calendar calendar = Calendar.getInstance();
		int year=Integer.parseInt(year1);
		calendar.set(year, 0, 1);
		calendar.add(Calendar.YEAR, 1); 
		calendar.add(Calendar.DATE, -1);  
		List<Object[]> Date_Des =new ArrayList<Object[]>();
		List<Map<String,Object>> holiday =new ArrayList<Map<String,Object>>();
		Criteria cr=session.createCriteria(Holiday.class);
		cr.add(Restrictions.eq("year", year));
		Projection pr=Projections.property("date");
		Projection p=Projections.property("description");
		ProjectionList plList=Projections.projectionList();
		plList.add(pr);
		plList.add(p);
		cr.setProjection(plList);

		Date_Des=cr.list();
		for(Object[] row:Date_Des)
		{
			Map ms=new HashMap();
			ms.put("Date", row[0]);
			ms.put("Holiday", row[1]);
			holiday.add(ms);
		}
		return holiday;
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  

		Criteria cr=session.createCriteria(Holiday.class);

		
		return cr.list();
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Holiday d = (Holiday ) session.createCriteria(Holiday.class)
                 .add(Restrictions.eq("idHoliday", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
}
