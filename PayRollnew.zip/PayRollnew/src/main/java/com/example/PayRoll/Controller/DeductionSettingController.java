package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.DeductionSettingManager;
import com.example.PayRoll.POJO.DeductionSetting;

@Controller
@RequestMapping("/DeductionSetting")
public class DeductionSettingController {
	@Autowired
	DeductionSettingManager DSManager;
	//iddeductionsetting, condition, minimum_condition, maximum_condition, idDeductionType, amount, idDeductions
	@RequestMapping("/save")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public DeductionSetting save(@RequestParam("id")int idded,@RequestParam("condition")int con,@RequestParam("mincondition")float mincon,@RequestParam("maxCondition")float maxcon,@RequestParam("dedtype")String dedtype,@RequestParam("ded")String ded,@RequestParam("Amount")float amount)
	{
		
		return DSManager.save(idded,con,mincon,maxcon,dedtype,ded,amount);
		
	}
	@RequestMapping("/get")
	@PostMapping
	@ResponseBody
	public List get(@RequestParam("Deduction")String con)
	{
		
		return DSManager.get(con);
		
	}

@RequestMapping("/getall")
@PostMapping
@CrossOrigin()
@ResponseBody
public List getall()
{
	
	return DSManager.getall();
	
}

@RequestMapping("/delete")
@GetMapping
@CrossOrigin()
@ResponseBody
public Object delete(@RequestParam("id")int id)
{
	return DSManager.delete(id);
}
}
