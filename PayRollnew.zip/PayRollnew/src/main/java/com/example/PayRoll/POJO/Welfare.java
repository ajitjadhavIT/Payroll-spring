package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="welfare")
public class Welfare {

	@Id
	int idWelfare;
	int idEmpType;
	int month;
	float amount;
	public int getIdWelfare() {
		return idWelfare;
	}
	public void setIdWelfare(int idWelfare) {
		this.idWelfare = idWelfare;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
}
