package com.example.PayRoll.DAO;

import java.sql.Time;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.LateDeduction;
import com.example.PayRoll.POJO.Shift;

@Component
public class LateDeductionDAO {
	@Autowired
	EmptypeDAO emptypedao;
	@Autowired
	HipernateConfg hipernateConfg;
	public List get(String emptype) {
		Session session = (Session) hipernateConfg.getSession();
		int idemptype=emptypedao.get(emptype).getIdEmpType();
	
		Criteria cr=session.createCriteria(LateDeduction.class);
		cr.add(Restrictions.eq("idEmpType", idemptype));
		return cr.list();
	}
	public List getall() {
		Session session = (Session) hipernateConfg.getSession();	
		Criteria cr=session.createCriteria(LateDeduction.class);
		return cr.list();
	}
	public LateDeduction save(int id, Time time, float days, float deddays, String shift, String emptype) {
		Session session = (Session) hipernateConfg.getSession();	

		Transaction t = session.beginTransaction();  

		Criteria cr=session.createCriteria(Shift.class);
		cr.add(Restrictions.eq("name", shift));
		Projection pr=Projections.property("idShift");
		cr.setProjection(pr);
		int idShift=(int) cr.uniqueResult();
		int idemptype=emptypedao.get(emptype).getIdEmpType();

		LateDeduction ld=new LateDeduction();
		ld.setDays(days);
		ld.setDeductDays(deddays);
		ld.setIdEmpType(idemptype);
		ld.setIdLateDeduction(id);
		ld.setIdShift(idShift);
		ld.setTime(time);
		session.saveOrUpdate(ld);
		t.commit();
		
		return ld;
	}
	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		LateDeduction d = (LateDeduction ) session.createCriteria(LateDeduction.class)
                 .add(Restrictions.eq("idLateDeduction", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

	
	
	
	
}
