package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;

@Entity
@Table(name="bankdetails")
public class Bankdetails 
{//idBankDetails, idEmployees, bank_Name, account_Number, branch, account_type, iFSC_Code, PF_No
	@Id
	int idBankDetails;
	int idEmployees;
	String bank_Name;
	long account_Number;
	String branch;
	String account_type;
	String iFSC_Code;
	
	String pF_NO;//PF_No

	public int getIdBankDetails() {
		return idBankDetails;
	}

	public void setIdBankDetails(int idBankDetails) {
		this.idBankDetails = idBankDetails;
	}

	public int getIdEmployees() {
		return idEmployees;
	}

	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}

	public String getBank_Name() {
		return bank_Name;
	}

	public void setBank_Name(String bank_Name) {
		this.bank_Name = bank_Name;
	}

	public long getAccount_Number() {
		return account_Number;
	}

	public void setAccount_Number(long account_Number) {
		this.account_Number = account_Number;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccount_type() {
		return account_type;
	}

	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}

	public String getiFSC_Code() {
		return iFSC_Code;
	}

	public void setiFSC_Code(String iFSC_Code) {
		this.iFSC_Code = iFSC_Code;
	}

	public String getpF_NO() {
		return pF_NO;
	}

	public void setpF_NO(String pF_NO) {
		this.pF_NO = pF_NO;
	}
	
}
