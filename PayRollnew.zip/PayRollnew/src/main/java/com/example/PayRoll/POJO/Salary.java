package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salary")
public class Salary 
{
	@Id
	int idSalary;//idsalary, idEmployees, month, year, totalEarning, totalDeduction, netSalary
	int idEmployees;
	int month;
	int year;
	float totalEarning;
	double totalDeduction;
	double netSalary;
	public int getIdSalary() {
		return idSalary;
	}
	public void setIdSalary(int idSalary) {
		this.idSalary = idSalary;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public float getTotalEarning() {
		return totalEarning;
	}
	public void setTotalEarning(float totalEarning) {
		this.totalEarning = totalEarning;
	}
	public double getTotalDeduction() {
		return totalDeduction;
	}
	public void setTotalDeduction(double totalDeduction) {
		this.totalDeduction = totalDeduction;
	}
	public double getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(double netSalary) {
		this.netSalary = netSalary;
	}
	@Override
	public String toString() {
		return "Salary [idSalary=" + idSalary + ", idEmployees=" + idEmployees + ", month=" + month + ", year=" + year
				+ ", totalEarning=" + totalEarning + ", totalDeduction=" + totalDeduction + ", netSalary=" + netSalary
				+ "]";
	}
	
}
