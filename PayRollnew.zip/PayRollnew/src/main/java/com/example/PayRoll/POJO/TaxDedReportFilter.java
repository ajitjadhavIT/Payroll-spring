package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TaxDedReportFilter {

	List taxded=new ArrayList();
	private TOTALTAXbet totaltax;
	public List getTaxded() {
		return taxded;
	}
	public void setTaxded(List taxded) {
		this.taxded = taxded;
	}
	public TOTALTAXbet getTotaltax() {
		return totaltax;
	}
	public void setTotaltax(TOTALTAXbet totaltax) {
		this.totaltax = totaltax;
	}
	
	
	
	
	
}
