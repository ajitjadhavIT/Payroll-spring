package com.example.PayRoll.Controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.AttendanceDAO;
import com.example.PayRoll.DAO.EmpleaveDAO;
import com.example.PayRoll.DAO.Report1;
import com.example.PayRoll.DAO.ShiftDAO;
import com.example.PayRoll.POJO.Attd_leave_ReportbyDate;
import com.example.PayRoll.POJO.Attd_leave_reportbetweenDates;
import com.example.PayRoll.POJO.Attd_leave_reportbyMonth;
import com.example.PayRoll.POJO.Shift_Reportbetweendates;
import com.example.PayRoll.POJO.Shift_report;

@Controller
@RequestMapping("/Report1")
public class Report1Controller
{
	
	@Autowired
	Shift_Reportbetweendates sft;
	@Autowired
	Shift_report sftre;
	@Autowired
	Attd_leave_reportbyMonth aatm;
	@Autowired
	Report1 attdDao;
	@Autowired
	Attd_leave_ReportbyDate ar;
	@Autowired
	EmpleaveDAO EmpDAO;
	@Autowired
	Attd_leave_reportbetweenDates attd;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	EmpleaveDAO EmpleaveDAO ;
	
	@RequestMapping("/presentReport1")
	@PostMapping
	@ResponseBody
	public List presentReport1(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attdDao.presentReport1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/attd_leave_totalReport")
	@PostMapping
	@ResponseBody
	public Attd_leave_ReportbyDate attd_leave_totalReport(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attdDao.attd_leave_totalReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/presentReportbetweenDates")
	@PostMapping
	@ResponseBody
	public List presentReportbetweenDates(Date Startdate,Date lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	{
		return attdDao.presentReportbetweenDates(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
	}
	@RequestMapping("/presentReportbetweenMonth")
	@PostMapping
	@ResponseBody
	public List presentReportbetweenMonth(String Startdate,String lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	{
		return attdDao.presentReportbetweenMonth(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
	}
	@RequestMapping("/attdReport_GroupbyGender")
	@PostMapping
	@ResponseBody
	public List attdReport_GroupbyGender(int Month,int year)
	{
		return attdDao.attdReport_GroupbyGender(Month, year);
	}
	@RequestMapping("/attdReport_GroupbyGender1")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public List attdReport_GroupbyGender1(String date) throws ParseException
	{
		return attdDao.attdReport_GroupbyGender1(date);
	}
	@RequestMapping("/leaveReport1")
	@PostMapping
	@ResponseBody
	public List leaveReport1(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attdDao.leaveReport1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/leaveReportbetweenDates")
	@PostMapping
	@ResponseBody
	public List leaveReportbetweenDates(Date Startdate,Date lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	{
		return attdDao.leaveReportbetweenDates(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
		
	}
	@RequestMapping("/totalReportbetweenDates")
	@PostMapping
	@ResponseBody
	public Attd_leave_reportbetweenDates totalReportbetweenDates(Date Startdate,Date lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attdDao.totalReportbetweenDates(Startdate, lastDate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/leaveReportbetweenMonth")
	@PostMapping
	@ResponseBody
	 public List leaveReportbetweenMonth(String Startdate,String lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	{
		return attdDao.leaveReportbetweenMonth(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
	}
	@RequestMapping("/totalReportbetweenMonth")
	@PostMapping
	@ResponseBody
	public Attd_leave_reportbyMonth totalReportbetweenMonth(String Startdate,String lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	 {
		return attdDao.totalReportbetweenMonth(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
	 }
	@RequestMapping("/ShiftReportbyday")
	@PostMapping
	@ResponseBody
	 public List ShiftReportbyday(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	 {
		return attdDao.ShiftReportbyday(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	 }
	@RequestMapping("/ShiftwiseReportbyday")
	@PostMapping
	
	@ResponseBody
	public List ShiftwiseReportbyday(@RequestParam("Date")Date date,@RequestParam("Shift")String Shift) throws ParseException
	{
		return attdDao.ShiftwiseReportbyday(date, Shift);
	}
	@RequestMapping("/ShiftReport")
	@PostMapping
	@ResponseBody
	public List ShiftReport(Date date) throws ParseException
	{
		return attdDao.ShiftReport(date);
	}
	@RequestMapping("/ShiftReportbetweenDates")
	@PostMapping
	@ResponseBody
	public List ShiftReportbetweenDates(Date Startdate,Date Enddate,String shift) throws ParseException
	{
		return attdDao.ShiftReportbetweenDates(Startdate, Enddate, shift);
	}
	@RequestMapping("/ShiftReportbetweendates1")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object ShiftReportbetweendates1(String StartDate,String Enddate,String shift) throws ParseException
	{
		return attdDao.ShiftReportbetweendates1(StartDate, Enddate, shift);
	}
	@RequestMapping("/ShiftReport1")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object ShiftReport1(String date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attdDao.ShiftReport1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/ShiftReportbetweenMonth")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object ShiftReportbetweenMonth(String StartDate,String Enddate,String shift) throws ParseException
	{
		return attdDao.ShiftReportbetweenMonth(StartDate, Enddate, shift);
	}
	@RequestMapping("/ShiftReportbetweenMonth1")
	@PostMapping
	
	@ResponseBody
	public List ShiftpReportbetweenMonth1(String Startdate,String Enddate,String shift) throws ParseException
	{
		return attdDao.ShiftpReportbetweenMonth1(Startdate, Enddate, shift);
	}
}
