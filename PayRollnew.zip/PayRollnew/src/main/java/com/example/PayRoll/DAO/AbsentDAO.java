package com.example.PayRoll.DAO;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.DayPresent;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Shift;

@Component
@Controller
public class AbsentDAO 
{ 
	
	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	EmployeeDAO EmployeeDAO;

	@Autowired
	DesignationDAO designationDAO;

	public String save(int idabsent,Date date,String shift,String des,String empcode,String Reason)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
	
		Criteria cr=session.createCriteria(Shift.class);
		cr.add(Restrictions.eq("name", shift));
		Projection pr=Projections.property("idShift");
		cr.setProjection(pr);
	
		int idShift=(int) cr.uniqueResult();
		int idDesignation=designationDAO.get(des).getIdDesignation();
		int idemp=EmployeeDAO.get(empcode).getIdEmployees();
		Absent a=new Absent();
		a.setIdabsent(idabsent);
		a.setDate(date);
		a.setIdDesignation(idDesignation);
		a.setIdEmployees(idemp);
		a.setIdShift(idShift);
		a.setReason(Reason);
		session.saveOrUpdate(a);
		t.commit();  
		session.close();
		return "Saved Succesfully";
	}
	public Absent get(String empcode,Date date) 
	{
		Calendar calendar = Calendar.getInstance();
		Date userdate=calendar.getTime();
		calendar.setTime(date);
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Absent.class);
		cr.add(Restrictions.eq("id", id));
		cr.add(Restrictions.eq("date", date));		
		return (Absent) cr.uniqueResult();		
	}
	public List AbsentReport(Date date)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//shift,Department,Designation,Employee Code,Employee Name,Reason.
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		
		Date userdate=calendar.getTime();
		
		List<Object[]> getempsftleaid=new ArrayList<Object[]>();
		List<Map<String,Object>> Absent_Report=new ArrayList<Map<String,Object>>();
		
		Criteria cr = session.createCriteria(Absent.class);
	
		cr.add(Restrictions.eq("date", date));
		
		  Projection projection1 = Projections.property("idEmployees"); 
		  Projection projection2 = Projections.property("idDesignation");
		  Projection projection3 = Projections.property("idShift");
		  Projection projection4 = Projections.property("reason");
	     ProjectionList pList = Projections.projectionList();
	     pList.add(projection1);
	     pList.add(projection2);
	     pList.add(projection3);
	     pList.add(projection4);
	     cr.setProjection(pList);
	     getempsftleaid=cr.list();
		
		for(Object[] rs:getempsftleaid)
		{
			Map empdata=new HashMap();
			int idEmployees=(int) rs[0];
			System.err.println("idEmployees"+idEmployees);     
			System.err.println("idEmployees"+rs[1]);  
			int idDesignation=(int) rs[1];
			int idShift=(int) rs[2];
			String Reason=(String) rs[3];
		
			Criteria ar = session.createCriteria(Employees.class);
			
			ar.add(Restrictions.eq("idEmployees", idEmployees));
			
			  Projection projection = Projections.property("emp_First_Name"); 
			  Projection projectio = Projections.property("emp_Middle_Name"); 
			  Projection projecti=Projections.property("emp_Last_Name");
			  Projection projection5=Projections.property("employeeCode");
		     ProjectionList pList1 = Projections.projectionList();
		     pList1.add(projection);
		     pList1.add(projectio);
		     pList1.add(projecti);
		     pList1.add(projection5);
		     ar.setProjection(pList1);
		     List<Object[]> name_Code=ar.list();
			
			String EmpName=String.valueOf(name_Code.get(0)[0])+" "+String.valueOf(name_Code.get(0)[1])+" "+String.valueOf(name_Code.get(0)[2]);
			String EmployeeCode= (String) name_Code.get(0)[3];
			
			
			Criteria a=session.createCriteria(Shift.class);
			a.add(Restrictions.eq("idShift", idShift));
			Projection p=Projections.property("name");
			 ProjectionList List1 = Projections.projectionList();
		     List1.add(p);
		     a.setProjection(List1);
		     String shift=(String) a.uniqueResult();
			
			Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
			query3.setParameter("idDesignation", idDesignation);
			List<Object[]> des=query3.list();
		/*
			Criteria c = session.createCriteria(Designation.class, "des");
			c.createAlias("des.Department", "dept");
			c.add(Restrictions.eq("des.idDesignation", idDesignation));
			c.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			Projection p1=Projections.property("des.name");
			Projection p2=Projections.property("des.idDepartment");
			Projection p3=Projections.property("dept.name");
			ProjectionList pl=Projections.projectionList();
			pl.add(p1);
			pl.add(p2);
			pl.add(p3);
			c.setProjection(pl);
			List<Object[]> des=c.list();
			
			*/
			/*
			Criteria c = session.createCriteria(Designation.class, "oi");
			c.createAlias("oi.name", "book");
			c.createAlias("oi.idDepartment", "or");
			c.createAlias("or.user", "usr");

			ProjectionList proList = Projections.projectionList();
			proList.add(Projections.property("oi.quantity"));
			proList.add(Projections.property("book.title"));
			proList.add(Projections.property("or.id"));
			c.setProjection(proList);
			c.add(Restrictions.eq("usr.id", "1"));
			return c.list();
			
			*/
			
			
			String Designation_Name=(String) des.get(0)[0];
			String DeptName=(String) des.get(0)[2];
			System.err.println("Designation_Name"+Designation_Name);
			System.err.println("DeptName"+DeptName);
			empdata.clear();
			empdata.put("shift", shift);
			empdata.put("Department", DeptName);
			empdata.put("Designation_Name",Designation_Name);
			empdata.put("EmployeeCode",EmployeeCode);
			empdata.put("Employee Name", EmpName);
			empdata.put("Reason", Reason);
		
			Absent_Report.add(empdata);
			
		}
			return Absent_Report;
	}
	public List Absent_Monthly_Report(String Month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		List<Map<String,Object>> dept_count=new ArrayList<Map<String,Object>>();
		int Month=Integer.parseInt(Month1);
		int year=Integer.parseInt(year1);
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, Month-1, 1);
		Date FirstDate=calendar.getTime();
		
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		
		Map des_count=new HashMap();
		List<Integer> dept=new ArrayList<Integer>();
		Query query4=session.createQuery("select distinct idDepartment from Department where idDepartment in(select idDepartment from Designation where idDesignation in (select distinct idDesignation from Absent where date between :FirstDate and :LastDate ))"); 
		query4.setParameter("FirstDate", FirstDate);
		query4.setParameter("LastDate", LastDate);
		dept=query4.list();

		/*
		criteria.add(Restrictions.ge("date", FirstDate)); 
		criteria.add(Restrictions.lt("date", LastDate));
		
	*/
		
		
			for(int id:dept)
		{
			int id1= (int )id;
			Map map=new HashMap();
			System.err.println("id"+id1);
			System.err.println("firstdate"+FirstDate);
			System.err.println("lastdate"+LastDate);
		
			Query query5=session.createQuery("select idDesignation,count(*) from Absent where idDesignation in (select idDesignation from Designation where "
					+ "idDepartment = :id1 ) and date between :FirstDate and :LastDate");
			query5.setParameter("id1", id1);
			query5.setParameter("FirstDate", FirstDate);
			query5.setParameter("LastDate", LastDate);
			List<Object[]> descount=query5.list();
			
			
			Criteria a=session.createCriteria(Department.class);
			a.add(Restrictions.eq("idDepartment", id1));
			Projection p=Projections.property("name");
			 ProjectionList List1 = Projections.projectionList();
		     List1.add(p);
		     a.setProjection(List1);
		     String Department_name=(String) a.uniqueResult();
			
		System.err.println("Deptname"+Department_name);
		map.put("DepartmentName", Department_name);
		map.put("Count",descount.get(0)[1]);
		System.err.println("Count"+descount.get(0)[1]);
		dept_count.add(map);
		}
		System.err.println("dept_count"+dept_count);	
		return dept_count;
	}
	public List Absent_yearly_Report(String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> dept_count=new ArrayList<Map<String,Object>>();
		int year=Integer.parseInt(year1);
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, 0, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.YEAR, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		Map des_count=new HashMap();
		List<Integer> dept=new ArrayList<Integer>();
		Criteria a1=session.createCriteria(Department.class);
	
		Projection p1=Projections.property("idDepartment");
		 ProjectionList List = Projections.projectionList();
	     List.add(p1);
	     a1.setProjection(List);
	     dept=(java.util.List<Integer>) a1.uniqueResult();	
		
		for(int id:dept)
		{
			int id1=(int) id;
			Map map=new HashMap();
			System.err.println("id"+id1);
			System.err.println("firstdate"+FirstDate);
			System.err.println("lastdate"+LastDate);
		
			Query query7=session.createQuery("select idDesignation,count(*) from Absent where idDesignation in (select idDesignation from Designation where "
					+ "idDepartment = :id1) and date between :FirstDate and :LastDate");
			query7.setParameter("id1", id1);
			query7.setParameter("FirstDate", FirstDate);
			query7.setParameter("LastDate", LastDate);
			List<Object[]> descount=query7.list();
			
			
			Criteria a=session.createCriteria(Department.class);
			a.add(Restrictions.eq("idDepartment", id1));
			Projection p=Projections.property("name");
			 ProjectionList List1 = Projections.projectionList();
		     List1.add(p);
		     a.setProjection(List1);
		     String Department_name=(String) a.uniqueResult();	
			
		System.err.println("Deptname"+Department_name);
		map.put("DepartmentName", Department_name);
		map.put("Count",descount.get(0)[1]);
		System.err.println("Count"+descount.get(0)[1]);
		dept_count.add(map);
		}
		return dept_count;
	}
	
	public DayPresent Day_Report(Date date1)
	{
		DayPresent dp = new DayPresent();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date1);
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Object[]> Experienced1=new ArrayList<Object[]>();
		List<Object[]> trainee1=new ArrayList<Object[]>();
		DateFormat df=new SimpleDateFormat("yyyy/MM/dd");
		//String datex=df.format();
		//System.err.println("after format"+datex);
		Date date=calendar.getTime();
		
		System.err.println("after parse"+date);
		Query experienced1=session.createQuery("SELECT idShift,count(*) from Absent where idEmployees in (select idEmployees from Employees where idEmpType in"
				+ " (select idEmpType from Emptype where name != 'Trainee'))and date = :date Group by idShift");
		experienced1.setParameter("date", date);
		Experienced1=experienced1.list();
		
		Query Trainee1=session.createQuery("SELECT idShift,count(*) from Absent where idEmployees in (select idEmployees from Employees where idEmpType in"
				+ " (select idEmpType from Emptype where name = 'Trainee'))and date = :date Group by idShift");
		Trainee1.setParameter("date", date);
		trainee1=Trainee1.list();
		
		System.err.println("sizeof(Experienced1)"+Experienced1.size());
		System.err.println("trainee1"+trainee1.size());
		
		dp.setexperienced(Experienced1);
		System.err.print("list"+Experienced1);
		System.err.print("Date"+date);
		dp.setTrainee(trainee1);
		System.err.print("list1"+trainee1);
		
		return dp;
	}
	
}
