package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="approval")
public class Approval {
@Id
	int idApproval;
	int idLeaveapplication;
	String result;
	Date date1;
	public int getIdApproval() {
		return idApproval;
	}
	public void setIdApproval(int idApproval) {
		this.idApproval = idApproval;
	}
	public int getIdLeaveapplication() {
		return idLeaveapplication;
	}
	public void setIdLeaveapplication(int idLeaveapplication) {
		this.idLeaveapplication = idLeaveapplication;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Date getDate1() {
		return date1;
	}
	public void setDate1(Date date1) {
		this.date1 = date1;
	}
	
	
	
}
