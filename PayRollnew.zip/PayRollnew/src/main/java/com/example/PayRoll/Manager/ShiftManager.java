package com.example.PayRoll.Manager;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.ShiftDAO;
import com.example.PayRoll.POJO.Shift;
@Component
@Controller
public class ShiftManager 
{
	@Autowired
	ShiftDAO shiftdao;
	public Shift save(int id,String name,String start,String end,float allownce) throws ParseException 
	{
		// TODO Auto-generated method stub
		return shiftdao.save(id,name,start,end,allownce);
	}
	public Object get(String Name) 
	{
		// TODO Auto-generated method stub
		return shiftdao.get(Name);
	}
}
