package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.Provisional_FundDAO;
import com.example.PayRoll.POJO.Provisional_Fund;
@Controller
@Component
public class Provisional_FundManager {

	@Autowired
	Provisional_FundDAO PFDao;
	public String save(Provisional_Fund pf) {
		return PFDao.save(pf);
	
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public Object get(String id) {
		// TODO Auto-generated method stub
		return PFDao.get(id);
	}

}
