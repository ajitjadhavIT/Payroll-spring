package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="complaints")
public class Complaints 
{
	@Id
	int idComplaints;
	int idEmployees;
	Date date;
	String reason;
	String complaintBy;
	public int getIdComplaints() {
		return idComplaints;
	}
	public void setIdComplaints(int idComplaints) {
		this.idComplaints = idComplaints;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getComplaintBy() {
		return complaintBy;
	}
	public void setComplaintBy(String complaintBy) {
		this.complaintBy = complaintBy;
	}
	@Override
	public String toString() {
		return "Complaints [idComplaints=" + idComplaints + ", idEmployees=" + idEmployees + ", date=" + date
				+ ", reason=" + reason + ", complaintBy=" + complaintBy + "]";
	}
	
	
}
