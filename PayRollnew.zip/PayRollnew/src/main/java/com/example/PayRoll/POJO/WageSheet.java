/**
 * 
 */
package com.example.PayRoll.POJO;

import java.util.HashMap;
import java.util.Map;

/**
 * @author HP
 *
 */
public class WageSheet {

	int srNo;
	String empcode;
	String name;
	float presentdays;
	float basic;
	float incentive;
	float shiftAllownce;
	float totalEarn;
	float pF;
	float pT;
	float eSI;
	float advance;
	float society;
	float loan;
	float phonebill;
	float canteen;
	float houseRent;
	float busCharge;
	float lWP;
	float tDS;
	float other;
	double totalDeduction;
	double netPay;
	String pF_no;
	String dept;
	Map des_PresDays=new HashMap();
	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public String getEmpcode() {
		return empcode;
	}
	public void setEmpcode(String empcode) {
		this.empcode = empcode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPresentdays() {
		return presentdays;
	}
	public void setPresentdays(float presentdays) {
		this.presentdays = presentdays;
	}
	public float getBasic() {
		return basic;
	}
	public void setBasic(float basic) {
		this.basic = basic;
	}
	public float getIncentive() {
		return incentive;
	}
	public void setIncentive(float incentive) {
		this.incentive = incentive;
	}
	public float getShiftAllownce() {
		return shiftAllownce;
	}
	public void setShiftAllownce(float shiftAllownce) {
		this.shiftAllownce = shiftAllownce;
	}
	public float getTotalEarn() {
		return totalEarn;
	}
	public void setTotalEarn(float totalEarn) {
		this.totalEarn = totalEarn;
	}
	public float getpF() {
		return pF;
	}
	public void setpF(float pF) {
		this.pF = pF;
	}
	public float getpT() {
		return pT;
	}
	public void setpT(float pT) {
		this.pT = pT;
	}
	public float geteSI() {
		return eSI;
	}
	public void seteSI(float eSI) {
		this.eSI = eSI;
	}
	public float getAdvance() {
		return advance;
	}
	public void setAdvance(float advance) {
		this.advance = advance;
	}
	public float getSociety() {
		return society;
	}
	public void setSociety(float society) {
		this.society = society;
	}
	public float getLoan() {
		return loan;
	}
	public void setLoan(float loan) {
		this.loan = loan;
	}
	public float getPhonebill() {
		return phonebill;
	}
	public void setPhonebill(float phonebill) {
		this.phonebill = phonebill;
	}
	public float getCanteen() {
		return canteen;
	}
	public void setCanteen(float canteen) {
		this.canteen = canteen;
	}
	public float getHouseRent() {
		return houseRent;
	}
	public void setHouseRent(float houseRent) {
		this.houseRent = houseRent;
	}
	public float getBusCharge() {
		return busCharge;
	}
	public void setBusCharge(float busCharge) {
		this.busCharge = busCharge;
	}
	public float getlWP() {
		return lWP;
	}
	public void setlWP(float lWP) {
		this.lWP = lWP;
	}
	public float gettDS() {
		return tDS;
	}
	public void settDS(float tDS) {
		this.tDS = tDS;
	}
	public float getOther() {
		return other;
	}
	public void setOther(float other) {
		this.other = other;
	}
	public double getTotalDeduction() {
		return totalDeduction;
	}
	public void setTotalDeduction(double totalDeduction) {
		this.totalDeduction = totalDeduction;
	}
	public double getNetPay() {
		return netPay;
	}
	public void setNetPay(double netPay) {
		this.netPay = netPay;
	}
	public String getpF_no() {
		return pF_no;
	}
	public void setpF_no(String pF_no) {
		this.pF_no = pF_no;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public Map getDes_PresDays() {
		return des_PresDays;
	}
	public void setDes_PresDays(Map des_PresDays) {
		this.des_PresDays = des_PresDays;
	}
	@Override
	public String toString() {
		return "WageSheet [srNo=" + srNo + ", empcode=" + empcode + ", name=" + name + ", presentdays=" + presentdays
				+ ", basic=" + basic + ", incentive=" + incentive + ", shiftAllownce=" + shiftAllownce + ", totalEarn="
				+ totalEarn + ", pF=" + pF + ", pT=" + pT + ", eSI=" + eSI + ", advance=" + advance + ", society="
				+ society + ", loan=" + loan + ", phonebill=" + phonebill + ", canteen=" + canteen + ", houseRent="
				+ houseRent + ", busCharge=" + busCharge + ", lWP=" + lWP + ", tDS=" + tDS + ", other=" + other
				+ ", totalDeduction=" + totalDeduction + ", netPay=" + netPay + ", pF_no=" + pF_no + ", dept=" + dept
				+ ", des_PresDays=" + des_PresDays + "]";
	}
	

	
}
