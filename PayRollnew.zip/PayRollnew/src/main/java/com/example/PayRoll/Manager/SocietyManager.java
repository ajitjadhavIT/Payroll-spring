package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.SocietyDAO;
import com.example.PayRoll.POJO.Society;
@Controller
@Component
public class SocietyManager {

	@Autowired
	SocietyDAO societyDAO;
	public Society save(int id,String emptype,float amount) {
		
		return societyDAO.save(id,emptype,amount);
	}

	public Object get() {
		// TODO Auto-generated method stub
		return societyDAO.get();
	}

	public Object delete(int id) {
		
		return societyDAO.delete(id);
	}

}
