package com.example.PayRoll.Controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.BasicSalaryDAO;
import com.example.PayRoll.Manager.BasicSalaryManager;
import com.example.PayRoll.POJO.Attendance;

@Controller
@RequestMapping("Basicsalary")
public class BasicSalaryController {

	@Autowired
	BasicSalaryManager bsManager;
	@Autowired
	BasicSalaryDAO bsDAo;
	
	@RequestMapping("/get")
	@GetMapping
	@ResponseBody
	
	public Object get(@RequestParam("month")int month,@RequestParam("empcode")String empcode,@RequestParam("year")int year)
	{
		return bsDAo.PresentDays(empcode, month, year);
	}
	
}
