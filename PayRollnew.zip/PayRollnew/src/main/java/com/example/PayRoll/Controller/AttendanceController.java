package com.example.PayRoll.Controller;


import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.AttendanceDAO;
import com.example.PayRoll.Manager.AttendanceManager;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.DayPresent;

@Component
@Controller
@RequestMapping("/Attendance")
public class AttendanceController
{
	@Autowired
	AttendanceManager attdman;
	@Autowired
	AttendanceDAO attddao;
	@Autowired
	DayPresent dp;
	
	String patternInt="\\d+";//For String Matching
	String patternDouble="[-+]?[0-9]*\\.?[0-9]+";//for Float,Double,Integer matching
	
	@RequestMapping("/get")
	@GetMapping
	@ResponseBody
	
	public Attendance get(@RequestParam("date")Date date,@RequestParam("empcode")String empcode)
	{
		return (Attendance) attddao.get(date, empcode);
	}
	@RequestMapping("/getall")
	@GetMapping
	@ResponseBody
	
	public List getall()
	{
		return  attddao.getall();
	}
	@PostMapping("/presentReport")
	@ResponseBody
		public List presentReport(@RequestParam("Date")Date date)
	{
		return attddao.presentReport(date);
	}
	@PostMapping("/Monthly_presentReport")
	@ResponseBody
	
	public Object Monthly_presentReport(@RequestParam("Month")String Month,@RequestParam("year")String year)
	{
		if(!Month.matches(patternInt))
		{
			return "Enter the valid Month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter the valid year";
		}
		else
		{
			return attddao.Monthly_presentReport(Month, year);	
		}
		
	}
	@PostMapping("/yearly_present_report")
	@ResponseBody
	
	public Object yearly_present_report(@RequestParam("year")String year)
	{
		if(!year.matches(patternInt))
		{
			return "Enter the valid year";
		}
		else
		{
		return attddao.yearly_present_report(year);
		}
	}
	@RequestMapping("/Day_Report")
	@GetMapping
	@ResponseBody
	public DayPresent Day_Report(Date date)
	{
		return attddao.Day_Report(date);
	}
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	
	
	public String save(@RequestParam("idAttendance")int idAttendance,@RequestParam("date")Date date,@RequestParam("Shift")String shift,@RequestParam("Shortform")String Shortform,@RequestParam("empcode")String empcode)
	{
		
		return attdman.save(idAttendance,date,shift,Shortform,empcode);
		
	}
	@RequestMapping("/attd_Weekly_report")
	@GetMapping
	@ResponseBody
	public Object attd_Weekly_report(@RequestParam("week")String week,@RequestParam("Month")String Month,@RequestParam("year")String year) throws ParseException
	{
		if(!week.matches(patternInt))
		{
			return "Enter valid week";
		}
		else if(!Month.matches(patternInt))
		{
			return "Enter valid Month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter valid year";
		}
		else
		{
		return attddao.attd_Weekly_report(week, Month, year);
		}
	}
	@RequestMapping("/Monthly_pre_groupbyDay")
	@GetMapping
	@ResponseBody
	public Object Monthly_pre_groupbyDay(@RequestParam("Month")String Month,@RequestParam("year")String year) throws ParseException
	{
		if(!Month.matches(patternInt))
		{
			return "Enter the valid Month";
		}
		else if(!year.matches(patternInt))
		{
			return "Enter the valid Year";
		}
		else
		{
		return attddao.Monthly_pre_groupbyDay(Month, year);
		}
	}
	@RequestMapping("/yearly_groupbyMonth")
	@GetMapping
	@ResponseBody
	public Object yearly_groupbyMonth(String year) throws ParseException
	{
		if(!year.matches(patternInt))
		{
			return "Enter the Valid year";
		}
		else 
		{
		return attddao.yearly_groupbyMonth(year);
		}
	}
	@RequestMapping("/Report_groupbyyear")
	@GetMapping
	@ResponseBody
	public Object Report_groupbyyear(int year)
	{
		return attddao.Report_groupbyyear(year);
	}
	@RequestMapping("/attdday_groupbydept")
	@GetMapping
	@ResponseBody
	public Object attdday_groupbydept(@RequestParam("deptName")String deptName,@RequestParam("date")String date)
	{
		if(deptName.isEmpty())
		{
			return "Enter the DeptName";
		}
		else if(date.isEmpty())
		{
			return "Enter the Date";
		}
		else
		{
			return attddao.attdday_groupbydept(deptName, date);
		}
		
	}
	@RequestMapping("/attdday_dept_groupbyShift")
	@GetMapping
	@ResponseBody
	public Object attdday_dept_groupbyShift(@RequestParam("deptName")String deptName,@RequestParam("date")String date)
	{
		if(deptName.isEmpty())
		{
			return "Enter the DeptName";
		}
		else if(date.isEmpty())
		{
			return "Enter the Date";
		}
		else
		{
		return attddao.attdday_dept_groupbyShift(deptName, date);
		}
	}
	
	@RequestMapping("/AttendanceChoiceReport")
	@GetMapping
	@ResponseBody
	public Object attdday_dept_groupby(@RequestParam("date")Date date,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.presentReport1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}

}
