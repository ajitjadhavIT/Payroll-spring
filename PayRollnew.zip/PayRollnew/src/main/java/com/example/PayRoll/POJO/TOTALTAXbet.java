package com.example.PayRoll.POJO;

public class TOTALTAXbet {
	
	
	int noofemp;
	float Totalpf;
	float Totalpt;
	float totalother;
	float fnltotal;
	
	public int getNoofemp() {
		return noofemp;
	}
	public void setNoofemp(int noofemp) {
		this.noofemp = noofemp;
	}
	public float getTotalpf() {
		return Totalpf;
	}
	public void setTotalpf(float totalpf) {
		Totalpf = totalpf;
	}
	public float getTotalpt() {
		return Totalpt;
	}
	public void setTotalpt(float totalpt) {
		Totalpt = totalpt;
	}
	public float getTotalother() {
		return totalother;
	}
	public void setTotalother(float totalother) {
		this.totalother = totalother;
	}
	public float getFnltotal() {
		return fnltotal;
	}
	public void setFnltotal(float fnltotal) {
		this.fnltotal = fnltotal;
	}
	
	

}
