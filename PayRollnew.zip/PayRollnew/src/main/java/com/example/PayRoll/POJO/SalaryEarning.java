package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salaryearning")
public class SalaryEarning {
@Id
int	idSalaryEarning;
int idSalary;
String earningType;
float earningAmount;
public int getIdSalaryEarning() {
	return idSalaryEarning;
}
public void setIdSalaryEarning(int idSalaryEarning) {
	this.idSalaryEarning = idSalaryEarning;
}
public int getIdSalary() {
	return idSalary;
}
public void setIdSalary(int idSalary) {
	this.idSalary = idSalary;
}
public String getEarningType() {
	return earningType;
}
public void setEarningType(String earningType) {
	this.earningType = earningType;
}
public float getEarningAmount() {
	return earningAmount;
}
public void setEarningAmount(float earningAmount) {
	this.earningAmount = earningAmount;
}
@Override
public String toString() {
	return "SalaryEarning [idSalaryEarning=" + idSalaryEarning + ", idSalary=" + idSalary + ", earningType="
			+ earningType + ", earningAmount=" + earningAmount + "]";
}

	
}
