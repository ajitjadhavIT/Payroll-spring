package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.BonusSetting;
import com.example.PayRoll.POJO.DeductionSetting;
import com.example.PayRoll.POJO.DeductionType;
import com.example.PayRoll.POJO.Deductions;
@Component
@Controller
public class DeductionSettingDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	DeductionTypeDAO dtdao;
	@Autowired
	DeductionsDAO ddao;
	
	
	public DeductionSetting save(int iddeduc,int con,float mincon,float maxcon,String dedtype,String ded,float amount) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();	
		int idded=(int) ddao.get(ded);
		Criteria cr=session.createCriteria(DeductionType.class);
		cr.add(Restrictions.eq("type", dedtype));
		Projection pr=Projections.property("idDeductionType");
		cr.setProjection(pr);
		int iddedtype=(int) cr.uniqueResult();
		DeductionSetting ds=new DeductionSetting();
		ds.setIddeductionsetting(iddeduc);
		ds.setAmount(amount);
		ds.setCondition1(con);
		ds.setIdDeductions(idded);
		ds.setIdDeductionType(iddedtype);
		ds.setMinimum_condition(mincon);
		ds.setMaximum_condition(maxcon);
	
	    session.saveOrUpdate(ds);
	    t.commit();
	session.close();
	return ds;
	}

	public List get(String con)
	{
		Session session = (Session) hipernateConfg.getSession();
		
		
		Criteria cr=session.createCriteria(Deductions.class);
		cr.add(Restrictions.eq("name", con));
		Projection pr=Projections.property("idDeductions");
		cr.setProjection(pr);
		int idded=(int) cr.uniqueResult();
		Criteria cr1=session.createCriteria(DeductionSetting.class);
		cr1.add(Restrictions.eq("idDeductions", idded));
		return cr1.list();
	}
	
	public List getall()
	{
		Session session = (Session) hipernateConfg.getSession();
		Criteria cr1=session.createCriteria(DeductionSetting.class);
	
		return cr1.list();
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		DeductionSetting d = (DeductionSetting ) session.createCriteria(DeductionSetting.class)
                 .add(Restrictions.eq("iddeductionsetting", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
}
	
