package com.example.PayRoll.Manager;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.EmpleaveDAO;
import com.example.PayRoll.POJO.Empleave;
@Component
@Controller
public class EmpleaveManager 
{	@Autowired
	EmpleaveDAO empldao;;

	public Empleave save(String empcode,Date date,String leavename,String shift) 
	{
		return empldao.save(empcode,date,leavename,shift);
	}
	public Object get(String empcode) 
	{
		return empldao.get(empcode);
	}
	public Object getall() 
	{
		return empldao.getall();
	}
}
