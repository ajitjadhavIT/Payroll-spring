package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.ProfessionalTaxDAO;
import com.example.PayRoll.POJO.ProfessionalTax;
@Controller
@Component
public class ProfessionalTaxManager {
	@Autowired
	ProfessionalTaxDAO ptDAO;

	public String save(ProfessionalTax pt) {
		
		return ptDAO.save(pt);
	}

	public Object get(String id) {
		// TODO Auto-generated method stub
		return ptDAO.get(id);
	}

}
