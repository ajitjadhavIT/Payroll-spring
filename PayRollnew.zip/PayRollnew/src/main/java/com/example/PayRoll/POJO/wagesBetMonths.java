package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;

public class wagesBetMonths {

	List present=new ArrayList();
	List leave=new ArrayList();
	List total=new ArrayList();
	public List getPresent() {
		return present;
	}
	public void setPresent(List present) {
		this.present = present;
	}
	public List getLeave() {
		return leave;
	}
	public void setLeave(List leave) {
		this.leave = leave;
	}
	public List getTotal() {
		return total;
	}
	public void setTotal(List total) {
		this.total = total;
	}
	
}
