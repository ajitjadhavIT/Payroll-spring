package com.example.PayRoll.DAO;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Attd_leave_ReportbyDate;
import com.example.PayRoll.POJO.Attd_leave_reportbetweenDates;
import com.example.PayRoll.POJO.Attd_leave_reportbyMonth;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Empleave;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.ShiftAllownce;
import com.example.PayRoll.POJO.Shift_Reportbetweendates;
import com.example.PayRoll.POJO.Shift_report;
@Component
public class Report1 

{
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	ShiftDAO shiftdao;
	@Autowired
	WorkhoursDAO1 workhrdao;
	@Autowired
	Shift_Reportbetweendates sft;
	@Autowired
	Shift_report sftre;
	@Autowired
	Attd_leave_reportbyMonth aatm;
	@Autowired
	WagesDayFilterDAO WDFilterdao;
	@Autowired
	Attd_leave_ReportbyDate ar;
	@Autowired
	EmpleaveDAO EmpDAO;
	@Autowired
	Attd_leave_reportbetweenDates attd;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	EmpleaveDAO EmpleaveDAO ;
	
	public List presentReport1(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	 {
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Integer> Common_list=new ArrayList<Integer>();
		List present_report=new ArrayList();
		List<Integer> Shift_report=new ArrayList<Integer>();
		int idemp=0;
		//Group, Department,Category,Designation,Shift,Employee Code,Date
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		Date date1=format.parse(format.format(date));
		
		Common_list=WDFilterdao.commonEmployees(Designation, Department, Catagory, Employee_Code);
		
				
      if(!Shift.isEmpty())
      {
   	   Shift e1=new Shift();
  		  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
  		   int idshift=e1.getIdShift();
  		   System.err.println("Common_list"+Common_list);
  		   Criteria shiftcr=session.createCriteria(Attendance.class);
  		   shiftcr.add(Restrictions.eq("idShift", idshift));
  		   shiftcr.add(Restrictions.eq("date", date));
  		   Projection pr2=Projections.property("idEmployees");
  		   ProjectionList pl=Projections.projectionList();
  		   pl.add(pr2);
  		   shiftcr.setProjection(pl);
  		   Shift_report=shiftcr.list();
  		   Common_list.retainAll(Shift_report);
  		   		
      }
      System.err.println("Shift_report"+Shift_report);
     
     
      System.err.println("date"+date1);
    System.err.println("Common_list"+Common_list);
		Query r=session.createQuery("select empt.name as Emptype,dept.name as department,cat.name as Catagory,empwork.hours as Hours,"
				+ "desg.name as Designation ,emp.employeeCode as EmployeeCode ,sft.name as Shift,whr.inTime "
				+ "as Intime,whr.outTime as Outtime,TIMEDIFF(outtime,intime)as timdef, CONCAT(emp.emp_First_Name, ' ',emp.emp_Middle_Name,' '"
				+ ",emp.emp_Last_Name) AS EmployeeName from EmpWorkDetails as empwork,Department dept, Shift sft,Workhours whr, Emptype "
				+ "as empt , Employees AS emp, Catagory AS cat , Designation as desg where emp.idEmployees in "
				+ ":Common_list  and empt.idEmpType = (select idEmpType from Employees where idEmployees = "
				+ "emp.idEmployees) and desg.idDesignation = (select idDesignation from EmpWorkDetails where"
				+ " idEmployees = emp.idEmployees) and cat.idCatagory = (select idCatagory from Designation "
				+ "where idDesignation = desg.idDesignation) and dept.idDepartment = (select idDepartment from "
				+ "Catagory  where idCatagory = cat.idCatagory) and sft.idShift=(select distinct idShift from "
				+ "Attendance where Date = :date and idEmployees = emp.idEmployees) and whr.idWorkHours=(select "
				+ "idWorkHours from Workhours where idAttendance = (select idAttendance from Attendance where date = :date and idEmployees = emp.idEmployees)) "
				+ " and empwork.idEmpWorkDetails = (select idEmpWorkDetails from EmpWorkDetails where idEmployees=emp.idEmployees)");
		r.setParameter("Common_list", Common_list);
		r.setParameter("date", date1);
		present_report=r.list();
		System.err.println("present_report"+present_report);
		System.err.println("present_report"+present_report);
		return present_report;
     
	 }
	public Attd_leave_ReportbyDate attd_leave_totalReport(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Object[]> leave1=new ArrayList<Object[]>();
		List<Object[]> present1=new ArrayList<Object[]>();
		List Total1=new ArrayList();
		
		leave1=this.leaveReport1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
		System.err.println("leave"+leave1);
		ar.setLeave(leave1);
		
		present1=this.presentReport1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
		System.err.println("present"+present1);
		ar.setPresent(present1);
		
		
		
		System.err.println("present1"+present1);
		int idEmployees =0;
		int empcount=present1.size();
		System.err.println("empcount"+empcount);
		
		
		float TotalWorkingHR=0.0f;
		float totalDayConverted=0.0f;
		int totalispaid=0;
		 long Nonpaidleaves=0;
		 long paidLeaves=0;
		 float TotalHours=0.0f;
		 float workefficiency=0.0f;
		 
		for(int i=0;i<present1.size();i++)
		{
			System.err.println("Hours"+present1.get(i)[3]);
			float Hours=(float) present1.get(i)[3];
			
			float WorkHR=(float) workhrdao.PresentDaybyHRbyDate(String.valueOf(present1.get(i)[5]), date);
			System.err.println("WorkHR"+WorkHR);
			
			TotalWorkingHR=TotalWorkingHR+WorkHR;
			float DayConverted=(WorkHR/Hours);
			totalDayConverted=totalDayConverted+DayConverted;
			TotalHours= TotalHours + Hours;
			workefficiency=(TotalWorkingHR/TotalHours)*100;
			 
		}
			Query n=session.createQuery("select count(idEmployee_leave) from Empleave where idLeave in (select idLeave from TblLeave where isPaid='1' )and date = :date");
	        n.setParameter("date", date);
	        paidLeaves=(long) n.uniqueResult();
	        
	        Query p=session.createQuery("select count(idEmployee_leave) from Empleave where idLeave in (select idLeave from TblLeave where isPaid='0' )and date = :date");
	      	p.setParameter("date", date);
	      	Nonpaidleaves=(long) p.uniqueResult();
	       
        Criteria leave=session.createCriteria(Empleave.class);
        Projection pr=Projections.rowCount();
        leave.setProjection(pr);
        long leave_count=(long) leave.uniqueResult();
		
		System.err.println("empcount"+empcount);
		Total1.add(empcount);
		System.err.println("TotalWorkingHR"+TotalWorkingHR);
		Total1.add(TotalWorkingHR);
		System.err.println("totalDayConverted"+totalDayConverted);
		Total1.add(totalDayConverted);
		System.err.println("Nonpaidleaves"+Nonpaidleaves);
		Total1.add(Nonpaidleaves);
		System.err.println("paidLeaves"+paidLeaves);
		Total1.add(paidLeaves);
		System.err.println("leave_count"+leave_count);
		Total1.add(leave_count);
		Total1.add(workefficiency);
		ar.setTotal(Total1);
        return ar;
	}
	public List presentReportbetweenDates(Date Startdate,Date lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	{
		List employees=new ArrayList();
		List final1=new ArrayList();
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Integer> Common_list=new ArrayList<Integer>();
		System.err.println("strt "+Startdate+"last "+lastDate);
		List Total=new ArrayList();
		List<Integer> Shift_report=new ArrayList<Integer>();
		int idemp=0;
		//Group, Department,Category,Designation,Shift,Employee Code,Date
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy/MM/dd");
		Calendar calendar = Calendar.getInstance();
		System.err.println("Startdate : "+Startdate);
		Date Fd=format1.parse(format1.format(Startdate));
		calendar.setTime(Startdate);
		System.err.println("Designation"+Designation + "Department"+Department +"Catagory"+Catagory );
		Common_list=WDFilterdao.commonDesignation(Designation, Department, Catagory,empcode );
		System.err.println("Common_list"+Common_list);
		//Date date1=format.parse(format.format(date));
		
		while(!calendar.getTime().after(lastDate))
		{
			
			Date date=calendar.getTime();
			
			System.err.println("date in loop"+date);
			int year = calendar.get(Calendar.YEAR);
			int month = calendar.get(Calendar.MONTH);
			int idshift=0;
			
			String base="select atd.idAttendance, atd.idShift, atd.idEmployees from Attendance as atd  where idDesignation = :idDesignation and date =:date  ";
			  if(!Shift.isEmpty())
			  {
				  
				  String byShift = " and idShift = :idshift ";
				  
				  base = base.concat(byShift);
				   		Shift e1=new Shift();
					  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("Name", Shift )).uniqueResult();
					idshift=e1.getIdShift();
					   System.err.println("idshift"+idshift);
					   System.err.println("Common_list"+Common_list);
					   Criteria shift=session.createCriteria(Attendance.class);
					   
					   shift.add(Restrictions.eq("idShift", idshift));
					   shift.add(Restrictions.eq("date", date));
					   Projection pr=Projections.property("idDesignation");
					   shift.setProjection(pr);
					   Shift_report=shift.list();
					   System.err.println("Shift_report"+Shift_report+"date"+date);
					   Common_list.retainAll(Shift_report);
					   		
			  }
			 
			  System.err.println("common list after shift"+Common_list);
			  
			  for(int i=0;i<Common_list.size();i++)
			  {
				  Map present_report=new HashMap();  
			  int idDesignation=Common_list.get(i);
			  float totalworkinghours=0.0f;
			  float daysConverted=0.0f;
			  float workefficiency=0.0f;
			  float TotalHours=0.0f;
			  	System.err.println("idDesignation"+idDesignation);
			  	
				Query r=session.createQuery(base);
				r.setParameter("idDesignation", idDesignation);
				r.setParameter("date", date);
				if(!Shift.isEmpty())
				{
					r.setParameter("idshift", idshift);
				}
				List<Object[]> attd=r.list();
				int j=0;
				System.err.println("No.of records "+attd.size());
				String ShiftName="", deptName = "",Desname ="",CategoryName="";
				Time timediff=null;
				
				while(j<attd.size())
				{
				int idShift=(int) attd.get(j)[1];
				int idAttendance=(int) attd.get(j)[0];
				System.err.println("idAttendance for"+j);
				int idEmployees=(int)attd.get(j)[2];
				
				if(!employees.contains(idEmployees))
				{
					employees.add(idEmployees);
				}
				Criteria z=session.createCriteria(Employees.class);
				z.add(Restrictions.eq("idEmployees", idEmployees));
				Projection pr=Projections.property("employeeCode");
				z.setProjection(pr);
				String Employeecode=(String) z.uniqueResult();
				
				float WorkHR=(float) workhrdao.PresentDaybyHRbyDate(Employeecode, date);
				totalworkinghours=	totalworkinghours + WorkHR;
								
				workefficiency=(totalworkinghours/TotalHours)*100;
				
				Criteria s=session.createCriteria(EmpWorkDetails.class);
				s.add(Restrictions.eq("idEmployees", idEmployees));
				Projection pr1=Projections.property("idShift");
				s.setProjection(pr1);
				Integer hours=(Integer) s.uniqueResult();
				TotalHours =TotalHours + hours;
				workefficiency=(totalworkinghours/TotalHours)*100;
				daysConverted += WorkHR/hours;
				
				 Criteria q=session.createCriteria(Shift.class);
				 q.add(Restrictions.eq("idShift", idShift));
				 Projection pr2=Projections.property("name");
				 q.setProjection(pr2);
				 ShiftName=(String) q.uniqueResult();
				
							
				Query a=session.createQuery("select timediff(outTime,inTime) from Workhours where idAttendance = :idAttendance");
				a.setParameter("idAttendance", idAttendance);
				 timediff=(Time) a.uniqueResult();
				 System.err.println("timediff"+timediff);
				 
				 	
					j++;
				}
				if(!attd.isEmpty())
				{
					Query w=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
					w.setParameter("idDesignation", idDesignation);
					List <Object[]> dept=w.list();
					 deptName=(String) dept.get(0)[2];
					 System.err.println("deptName"+deptName);
					 Desname=(String)dept.get(0)[0];
					 System.err.println("Desname"+Desname);
					 
					 Query c=session.createQuery("select name from Catagory where idCatagory in (select idCatagory from Designation where idDesignation =:idDesignation ) ");
					 c.setParameter("idDesignation", idDesignation);
					 CategoryName=(String) c.uniqueResult();
					
					present_report.put("ShiftName", ShiftName);
					present_report.put("timediff", timediff);
					present_report.put("deptName", deptName);
					
					present_report.put("Desname", Desname);
					present_report.put("CategoryName", CategoryName);
					present_report.put("noofrecords", attd.size());
					present_report.put("totalworkinghours", totalworkinghours);
					present_report.put("daysConverted", daysConverted);
					present_report.put("workefficiency", workefficiency);
					present_report.put("date", date);
					
					Total.add(present_report);
				
				}
		}
			 
			  calendar.add(Calendar.DATE, 1);
		System.err.println("present_report"+Total);
		
	 
	 }
		final1.add(Total);
		final1.add(employees);
		session.close();
		return final1;
	}



	public List presentReportbetweenMonth(String Startdate,String lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
	{
		
		GregorianCalendar gcal = new GregorianCalendar();
		List employees=new ArrayList();
		List final1=new ArrayList();
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Integer> Common_list=new ArrayList<Integer>();
		System.err.println("shift"+Shift);
		List Total=new ArrayList();
		List<Integer> Shift_report=new ArrayList<Integer>();
		int idemp=0;
		//Group, Department,Category,Designation,Shift,Employee Code,Date

		String strdate[]=Startdate.split("/");
		int month1=Integer.valueOf(strdate[0]);
	
		int year1=Integer.valueOf(strdate[1]);
		int day=1;
		System.err.println("lastdate"+lastDate);
		
		String ltDate[]=lastDate.split("/");
		int month2=Integer.valueOf(ltDate[0]);
	
		int year2=Integer.valueOf(ltDate[1]);
		int day1=31;
		 gcal.set(year2, month2, day1);
		Date end=gcal.getTime();
		 gcal.set(year1, month1, day);
		System.err.println("Designation"+Designation + "Department"+Department +"Catagory"+Catagory );
		Common_list=WDFilterdao.commonDesignation(Designation, Department,Catagory,empcode);
		System.err.println("Common_list"+Common_list);
		//Date date1=format.parse(format.format(date));
		
		System.err.println("******************start "+gcal.getTime() +"end date "+end);
		while(!gcal.getTime().after(end))
		{
				 Date d = gcal.getTime();
			     System.out.println(d);
			     gcal.add(Calendar.MONTH, 1);
			     
			     Date firstdate=gcal.getTime();
			     gcal.add(Calendar.MONTH, 1);  
			     gcal.set(Calendar.DAY_OF_MONTH, 1);  
			     gcal.add(Calendar.DATE, -1); 
			     Date lstDate=gcal.getTime();
			
			System.err.println("date in loop"+d);
		
			int idshift=0;
			
			String base="select atd.idAttendance, atd.idShift, atd.idEmployees from Attendance as atd  where idDesignation = :idDesignation and Date =:date  ";
			  if(!Shift.isEmpty())
			  {
				  
				  String byShift = " and idShift = :idshift";
				  
				  base = base.concat(byShift);
				   		Shift e1=new Shift();
					  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
					idshift=e1.getIdShift();
					   System.err.println("idshift"+idshift);
					   System.err.println("Common_list"+Common_list);
					   Criteria shift=session.createCriteria(Attendance.class);
					   shift.add(Restrictions.eq("idShift", idshift));
					   shift.add(Restrictions.eq("date", d));
					   Projection pr=Projections.property("idDesignation");
					   shift.setProjection(pr);
					   Shift_report=shift.list();
					   System.err.println("Shift_report"+Shift_report+"date"+d);
					   Common_list.retainAll(Shift_report);
					   		
			  }
			 
			  System.err.println("common list after shift"+Common_list);
			  
			  for(int i=0;i<Common_list.size();i++)
			  {
				 Map present_report=new HashMap();  
			  int idDesignation=Common_list.get(i);
			  float totalworkinghours=0.0f;
			  float daysConverted=0.0f;
			  float workefficiency=0.0f;
			  float TotalHours=0.0f;
			  	System.err.println("idDesignation"+idDesignation);
			  	
				Query r=session.createQuery(base);
				r.setParameter("idDesignation", idDesignation);
				r.setParameter("date", d);
				if(!Shift.isEmpty())
				{
					r.setParameter("idshift", idshift);
				}
				List<Object[]> attd=r.list();
				int j=0;
				System.err.println("No.of records "+attd.size());
				String ShiftName="", deptName = "",Desname ="", CategoryName="";
				Time timediff=null;
				
				while(j<attd.size())
				{
				int idShift=(int) attd.get(j)[1];
				int idAttendance=(int) attd.get(j)[0];
				System.err.println("idAttendance for"+j);
				int idEmployees=(int)attd.get(j)[2];
				
				if(!employees.contains(idEmployees))
				{
					employees.add(idEmployees);
				}
				Criteria z=session.createCriteria(Employees.class);
				z.add(Restrictions.eq("idEmployees", idEmployees));
				Projection pr=Projections.property("employeeCode");
				z.setProjection(pr);
				String Employeecode=(String) z.uniqueResult();
				System.err.println("Employeecode"+Employeecode);
				float WorkHR=(float) workhrdao.PresentDaybyHRbyDate(Employeecode, d);
				totalworkinghours=	totalworkinghours + WorkHR;
								
				workefficiency=(totalworkinghours/TotalHours)*100;
				
				Criteria s=session.createCriteria(EmpWorkDetails.class);
				s.add(Restrictions.eq("idEmployees", idEmployees));
				Projection pr1=Projections.property("hours");
				s.setProjection(pr1);
				float hours=(float) s.uniqueResult();
				TotalHours =TotalHours + hours;
				System.err.println("hours"+hours);
				workefficiency=(totalworkinghours/TotalHours)*100;
				daysConverted += WorkHR/hours;
				
				 Criteria q=session.createCriteria(Shift.class);
				 q.add(Restrictions.eq("idShift", idShift));
				 Projection pr2=Projections.property("name");
				 q.setProjection(pr2);
				 ShiftName=(String) q.uniqueResult();
				
							
				Query a=session.createQuery("select timediff(outTime,inTime) from Workhours where idAttendance = :idAttendance");
				a.setParameter("idAttendance", idAttendance);
				 timediff=(Time) a.uniqueResult();
				 System.err.println("timediff"+timediff);
				 
				 	
					j++;
				}
				if(!attd.isEmpty())
				{
				Query w=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
				w.setParameter("idDesignation", idDesignation);
				List <Object[]> dept=w.list();
				 deptName=(String) dept.get(0)[2];
				 System.err.println("deptName"+deptName);
				 Desname=(String)dept.get(0)[0];
				 System.err.println("Desname"+Desname);
				 
				 Query c=session.createQuery("select name from Catagory where idCatagory in (select idCatagory from Designation where idDesignation =:idDesignation ) ");
				 c.setParameter("idDesignation", idDesignation);
				 CategoryName=(String) c.uniqueResult();
				
				present_report.put("ShiftName",ShiftName);
				present_report.put("timediff",timediff);
				present_report.put("deptName",deptName);
				present_report.put("Desname",Desname);
				present_report.put("CategoryName",CategoryName);
				present_report.put("count",attd.size());
				present_report.put("totalworkinghours",totalworkinghours);
				present_report.put("daysConverted",daysConverted);
				present_report.put("workefficiency",workefficiency);
				present_report.put("date",d);
				Total.add(present_report);
				
				}
		}
			 
			  gcal.add(Calendar.MONTH, 1);
		System.err.println("present_report"+Total);
		
	 
	 }
		session.close();
		final1.add(Total);
		final1.add(employees);
		return final1;
	}
	public List attdReport_GroupbyGender(int Month,int year)
	{
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List finallist=new ArrayList();
		List dept_total=new ArrayList();
		List wwandstaff=new ArrayList();
		long count=0;
		List<Object[]> dept=new ArrayList<Object[]>();
		Query iddept=session.createQuery("SELECT distinct idDepartment,name FROM Department where name!='Stafff' and name!= 'Watch and ward'");
		dept=iddept.list();
		List<String> gender=new ArrayList<String>();
		Query gender1=session.createQuery("select distinct gender from Employees");
		gender=gender1.list();
		ArrayList<HashMap<String, Object>> count_by_gender=new ArrayList<HashMap<String,Object>>();
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH-1, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1); 
	   	calendar.add(Calendar.DATE, -1);
		
		
		int lastdate=calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

	    
	    	   
		for(Object[] rs:dept)
		{  
			Map ms=new HashMap();
			int Male_Count=0;
			int female_count=0;
			int final_total=0;
			calendar.set(year, Month-1, 1);
			int dept1=(int) rs[0];
			Query name=session.createQuery("select name from Department where idDepartment = :dept1");
			name.setParameter("dept1", dept1);
			String departmentname=(String) name.uniqueResult();
			
			
			for (int i = 0; i < lastdate; i++)
		    {   		float total=0;
		    			Map m=new HashMap();
				        Date date=calendar.getTime();
		        for(int j=0;j<gender.size();j++)
			{
				String gendername=(String) gender.get(j);
				Query count_groupby_gender=session.createQuery("select count(*) from"
						+ " Attendance where idDesignation in "
						+ "(select idDesignation from Designation where idDepartment = :dept1 ) and "
						+ "idEmployees in (select idEmployees from Employees where gender =:gendername) and date =:date ");  
				count_groupby_gender.setParameter("dept1", dept1);
				count_groupby_gender.setParameter("gendername", gendername);
				count_groupby_gender.setParameter("date", date);
				count=(long) count_groupby_gender.uniqueResult();

				  total += count;
				  
				
				if(gendername.equals("male"))
				{
					Male_Count += count;
				}
				else if(gendername.equals("female"))
				{
					female_count += count;
				}
				m.put(gendername, count);
				m.put("Total", total);
				m.put("department name", departmentname);
				m.put("Date", date);
				
				
			}
		       // System.err.println("***"+m);
		        final_total += total;
		        ms.put("Male_Count", Male_Count);
				ms.put("female_count", female_count);
				ms.put("departmentname", departmentname); 
				ms.put("final_total", final_total); 
				
				calendar.add(Calendar.DAY_OF_MONTH, 1);
				count_by_gender.add((HashMap<String, Object>) m);
				//System.err.println("***********"+count_by_gender);
				
		   }
			dept_total.add(ms);
			
			//System.err.println("departmentname"+departmentname);
			float malecount=0.0f;
			malecount += Male_Count;
			System.err.println("totalmale count"+malecount+"departmentname"+departmentname);
			float femalecount=0.0f;
			femalecount += female_count;
			System.err.println("totalfemale count"+femalecount+"departmentname"+departmentname);
		
	    }
		
		
		//total number of employees for date
		List<Map<String,Object>> date_total=new ArrayList<Map<String,Object>>();
		
		calendar.set(year, Month-1, 1);
		for (int i = 0; i < lastdate; i++)
		{
			Map row=new HashMap();
			float total=0.0f;
			Map p=new HashMap();
			float Date_count=0.0f;
			Date date=calendar.getTime();
			//System.err.println("date in total count"+date);
			Query Staff=session.createQuery("select count(*) from Attendance where idDesignation in (select idDesignation from Designation where idDepartment in(select idDepartment from Department where name = 'Stafff'))and date =:date");
			Staff.setParameter("date", date);
			long counts=(long) Staff.uniqueResult();
	        Query ww=session.createQuery("select count(*) from Attendance where idDesignation in (select idDesignation from Designation where idDepartment in(select idDepartment from Department where name = 'Watch and ward'))and date =:date"); 
	        ww.setParameter("date", date);
	        long countw=(long) ww.uniqueResult(); 
	        total=counts+countw;
	        row.put("wwCount", countw);
	        row.put("staffcount", counts);
	        row.put("total", total);
	        row.put("date", date);
	        wwandstaff.add(row);
			
			for(Map x:count_by_gender)
			{
				float count1=(float) x.get("Total");
				Date date1=(Date) x.get("Date");
				
				if(date.equals(date1) && count1 > 0)
				{
					/*System.err.println("date1 in total count"+date1);
					System.err.println("date in total count"+date);
					System.err.println("dept"+x.get("department name"));
					System.err.println(" count"+x.get("Total"));
					*/
					Date_count += count1;
					//System.err.println(" Date_count"+Date_count);
					
				}
				
				
			}
			
		
		p.put("date", date);
		p.put("Date_count", Date_count);
	    float grand_total=	Date_count+total;
		date_total.add(p);
		
		Map v=new HashMap();
		v.put("date", date);
		v.put("grand_total", grand_total);
		//finallist.addAll(date_total);
		//finallist.addAll(wwandstaff);
		finallist.add(v);
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		}
		return date_total;
	}
		public List attdReport_GroupbyGender1(String date ) throws ParseException
		{
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			List finallist=new ArrayList();
			
			String date1[]=date.split("-");
			int year=Integer.valueOf(date1[0]);
		
			int Month=Integer.valueOf(date1[1]);
		
			
			List<Object[]> dept=new ArrayList<Object[]>();
			String arr[] = {"26","RINGFRAME"};
			Query iddept=session.createQuery("SELECT distinct idDepartment,name FROM Department ");
			dept=iddept.list();
			//dept.add(arr);
			List<String> gender=new ArrayList<String>();
			Query gender1=session.createQuery("select distinct gender from Employees");
			gender=gender1.list();
			
			Calendar calendar = Calendar.getInstance();
			calendar.add(Calendar.MONTH-1, 1);  
		    calendar.set(Calendar.DAY_OF_MONTH, 1); 
		   	calendar.add(Calendar.DATE, -1);
		   	
			
		   	
			int lastday=calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
			calendar.set(year, Month-1, lastday);
			Date ld=calendar.getTime();
		
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
			calendar.set(year, Month-1, 1);
		   	Date fd=calendar.getTime();
		
			while(fd.before(ld))
		    {   		
			    Map datea=new HashMap();
				int total_workers_day = 0;
		    	int total_male_day = 0;
		    	int total_female_day = 0;
						System.err.println("****************************fd in loop"+fd);
						SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
						fd = df.parse(df.format(fd));
						List day=new ArrayList();
						
				       for(Object[] rs:dept)
				    	{  
				    	   	int dept1= (int) rs[0];
				    		
				    	   
				    		float total=0;
				    		String departmentname="";
				    		departmentname=(String) rs[1];
				    	
				    		Map department=new HashMap();
				    		int Male_Count=0;
				    		int female_count=0;
				    		
				    		List idEmployees=new ArrayList();
				    		Query l=session.createQuery("SELECT idEmployees FROM EmpWorkDetails where idDesignation in(select idDesignation from Designation where idDepartment =:dept1)");
				    		l.setParameter("dept1", dept1);
				    		idEmployees=l.list();
				    		Query emplist=session.createQuery("select idEmployees from Employees where idEmpType in(select idEmpType from Emptype where name !='Staff'and name !='Trainee')");
				    		List employeeList=new ArrayList();
				    		employeeList=emplist.list();
				    		idEmployees.retainAll(employeeList);
				    		if(!idEmployees.isEmpty())
				    		{
				    		 for(int j=0;j<gender.size();j++)
				    			{
				    			 	long count=0;
				    				String gendername=(String) gender.get(j);
				    				Query bygen = session.createQuery("select idEmployees from Employees where gender =:gendername");
				    				bygen.setParameter("gendername", gendername);
				    				
				    				idEmployees.retainAll(bygen.list());
				    				
				    				if(!idEmployees.isEmpty()) 
				    				{			    					
				    					
						    			Query count_groupby_gender=session.createQuery("select count(idEmployees) from "
					    						+ " Attendance where idEmployees in :employeeList and date = :fd ");
					    				count_groupby_gender.setParameter("fd",fd);
					    				count_groupby_gender.setParameter("employeeList", idEmployees);
					    				count=(long) count_groupby_gender.uniqueResult();
				    				}
				    				  total += count;
				    				  
				    				if(gendername.equals("male"))
				    				{
				    					Male_Count += count;
				    				}
				    				else if(gendername.equals("female"))
				    				{
				    					female_count += count;
				    				}
				    				
				    				if(!departmentname.equals("Watch and ward"))
						    		 {
						    			total_workers_day +=count;
						    		 total_female_day += female_count;
						    		 total_male_day += Male_Count;
						    		 }
				    			}
				    		}
				    		Map a=new HashMap<>();
				    		
				    		 department.put("Male_Count", Male_Count);
				    		 department.put("female_count", female_count);
				    	
				    		 department.put("total", total); 
				    		 department.put("date", fd);
				    		 a.put("Dept",departmentname);
					    		a.put("data", department);
				 			 day.add(a);
				    	}
				       
				       Query qempliststaff=session.createQuery("select idEmployees from Employees where idEmpType in(select idEmpType from Emptype where Name ='Staff')");
				       List empliststaff=new ArrayList();
				       empliststaff=qempliststaff.list();
				      
				       float total=0.0f;
				       float Male_Count=0.0f;
				       float female_count=0.0f;
				       Map Staff=new HashMap();
				       for(int j=0;j<gender.size();j++)
				       {
		    				String gendername=(String) gender.get(j);
		    				
		    				Query p = session.createQuery("select count(idEmployees) from Attendance "
		    						+ "where Date = :fd and idEmployees in :empliststaff1 "
		    						+ "and idEmployees in (select idEmployees "
		    						+ "from Employees where gender =:gendername)");
		    				p.setParameter("empliststaff1", empliststaff);
		    				p.setParameter("fd",fd);
		    				p.setParameter("gendername", gendername);
		    				
		    				long countstaff=(long) p.uniqueResult();
		    				
		    				
		    				total += countstaff;
			    			if(gendername.equals("male"))
			    			{
			    				Male_Count += countstaff;
			    			}
			    			else if(gendername.equals("female"))
			    			{
			    				female_count += countstaff;
			    			}	
			    		}
			    		
				      Map b=new HashMap<>();
				      Staff.put("total", total);
				      Staff.put("Male_Count", Male_Count);
				      Staff.put("female_count", female_count);
				  
				      Staff.put("date", fd);
				      b.put("Dept","staff");
				      b.put("data", Staff);
				   day.add(b);
				   
				   Query emplisttrainee=session.createQuery("select idEmployees from Employees where idEmpType in (select idEmpType from Emptype where name ='Trainee')");
			       List emplisttrainee1=new ArrayList();
			       emplisttrainee1=emplisttrainee.list();
			       
			       float total1=0.0f;
			       float Male_Count1=0.0f;
			       float female_count1=0.0f;
		
			       Map trainee=new HashMap();
			       for(int j=0;j<gender.size();j++)
			       {
	    				String gendername=(String) gender.get(j);
	    				long counttrainee=0;
	    				try {
	    				Query p1=session.createQuery("select count(idEmployees) from Attendance where date = : fd and idEmployees in : emplisttrainee1 and idEmployees in (select idEmployees from Employees where gender = : gendername)");
	    				p1.setParameter("emplisttrainee1", emplisttrainee1);
	    				p1.setParameter("fd", fd);
	    				p1.setParameter("gendername", gendername);
	    				 counttrainee=(long) p1.uniqueResult();
	    				}
	    				catch (Exception e) {
						
						}
	    				total1 += counttrainee; 
		    				if(gendername.equals("male"))
		    				{
		    					Male_Count1 += counttrainee;
		    				}
		    				else if(gendername.equals("female"))
		    				{
		    					female_count1 += counttrainee;
		    				}
		    		}
			       		Map c=new HashMap<>();
					    trainee.put("total", total1);
					    trainee.put("Male_Count", Male_Count1);
					    trainee.put("female_count", female_count1);
					    trainee.put("departmentname","Trainee");
					    trainee.put("date", fd);
					    c.put("Dept","Trainee" );
					    c.put("data", trainee);
					    day.add(c);
					 
					 
				       	finallist.add(day);
				        
				        calendar.add(Calendar.DAY_OF_MONTH, 1);  
				        fd=calendar.getTime();
				        
		    }
			return finallist ;
		}
		public List leaveReport1(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
		 {
			 Session session = (Session) hipernateConfg.getSession();  
				Transaction t = session.beginTransaction();
				
				
				List<Integer> Common_list=new ArrayList<Integer>();
				List<Object[]> leave_report=new ArrayList<Object[]>();
				List<Integer> Shift_report=new ArrayList<Integer>();
				int idemp=0;
				//Group, Department,Category,Designation,Shift,Employee Code,Date
				SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
				Date date1=format.parse(format.format(date));
				System.err.println("empcode"+Employee_Code);
				Common_list=WDFilterdao.commonEmployees(Designation, Department, Catagory, Employee_Code);
				System.err.println("Common_list"+Common_list);
		    if(!Shift.isEmpty())
		    {
		 	   Shift e1=new Shift();
				  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
				   int idshift=e1.getIdShift();
				   System.err.println("Common_list"+Common_list);
				   Query shift=session.createQuery("select idEmployees from Empleave where idShift =:idshift and Date=:date");
				   shift.setParameter("idshift", idshift);
				   shift.setParameter("date", date1);
				   Shift_report=shift.list();
				   Common_list.retainAll(Shift_report);
				   		
		    }
		    System.err.println("Shift_report"+Shift_report);
		   
		   
		    System.err.println("date"+date1);
		    System.err.println("Common_list"+Common_list);
				Query r=session.createQuery("select empt.name as Emptype,dept.name as department,cat.name as"
						+ " Catagory,desg.name as Designation ,emp.employeeCode as EmployeeCode ,sft.name as"
						+ " Shift,lve.name as LeaveType,CONCAT(emp.emp_First_Name,' ',emp.emp_Middle_Name,' ',"
						+ "emp.emp_Last_Name) AS EmployeeName from Department as dept,Shift as sft,TblLeave as lve,"
						+ "Emptype as empt , Employees AS emp, Catagory AS cat , Designation as desg where emp.idEmployees in :Common_list "
						+ "and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees) "
						+ "and desg.idDesignation = (select idDesignation from Emp"
						+ "WorkDetails where idEmployees = emp.idEmployees) "
						+ " and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation) "
						+ " and dept.idDepartment = (select idDepartment from Catagory  where idCatagory = cat.idCatagory) "
						+ "and sft.idShift=(select distinct idShift from Empleave where Date = :date and idEmployees = emp.idEmployees) "
						+ " and lve.idLeave=(select idLeave from Empleave  where Date = :date and idEmployees = emp.idEmployees)");
				r.setParameter("Common_list", Common_list);
				System.err.println("Common_list"+Common_list);
				r.setParameter("date", date1);
				leave_report=r.list();
			
				System.err.println("leave_report"+leave_report);
				return leave_report;
		   
		 }
		public List leaveReportbetweenDates(Date Startdate,Date lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
		 {
		 	
		 	Session session = (Session) hipernateConfg.getSession();  
		 	Transaction t = session.beginTransaction();
		 	List<Integer> Common_list=new ArrayList<Integer>();
		 	
		 	List Total=new ArrayList();

		 	List<Integer> Shift_report=new ArrayList<Integer>();
		 	int idemp=0;
		 	//Group, Department,Category,Designation,Shift,Employee Code,Date
		 	SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		 	Calendar calendar = Calendar.getInstance();
		 	
		 	Date Fd=format.parse(format.format(Startdate));
		 	calendar.setTime(Startdate);
		 	System.err.println("Designation"+Designation + "Department"+Department +"Catagory"+Catagory );
		 	
		 	Common_list=WDFilterdao.commonDesignation(Designation, Department, Catagory,empcode);
		 	
		 	System.err.println("Common_list"+Common_list);
		 	//Date date1=format.parse(format.format(date));
		 	
		 	
		 	while(!calendar.getTime().after(lastDate))
		 	{
		 		
		 		Date date=calendar.getTime();
		 		
		 		System.err.println("date in loop"+date);
		 		
		 		int idshift=0;
		 		
		 		String base="select idLeave, idShift from Empleave as leave  where date =:date";
		 		  if(!Shift.isEmpty())
		 		  {
		 			  
		 			  String byShift = " and idShift = :idshift ";
		 			  
		 			  base = base.concat(byShift);
		 			   		Shift e1=new Shift();
		 				  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
		 				  	idshift=e1.getIdShift();
		 				   System.err.println("idshift"+idshift);
		 				   System.err.println("Common_list"+Common_list);
		 				   Query shift=session.createQuery("select idDesignation from Employee_leave where idShift =:idshift and Date=:date");
		 				   shift.setParameter("idshift", idshift);
		 				   shift.setParameter("date", date);
		 				   Shift_report=shift.list();
		 				   System.err.println("Shift_report"+Shift_report+"date"+date);
		 				   Common_list.retainAll(Shift_report);
		 				   		
		 		  }
		 		 
		 		  System.err.println("common list after shift"+Common_list);
		 		  
		 		  for(int i=0;i<Common_list.size();i++)
		 		  {
		 			  
		 			List Leave_report=new ArrayList();
		 			  float Paidleaves=0.0f;
		 			 float NonPaidleaves=0.0f;
		 			 float leave_count =0.0f;
		 			  int idDesignation=Common_list.get(i);
		 			  float totalworkinghours=0.0f;
		 		  	System.err.println("idDesignation"+idDesignation);
		 		  	
		 			Query r=session.createQuery(base);
		 		
		 			r.setParameter("date", date);
		 			if(!Shift.isEmpty())
		 			{
		 				r.setParameter("idshift", idshift);
		 			}
		 			List<Object[]> leave=r.list();
		 			int j=0;
		 			System.err.println("No.of records "+leave.size());
		 			String ShiftName="", deptName = "",Desname ="", CategoryName="";
		 			
		 			
		 			while(j<leave.size())
		 			{
		 			int idShift=(int) leave.get(j)[1];
		 			int idLeave=(int) leave.get(j)[0];
		 			
		 			
		 			 Query q=session.createQuery("select name from Shift where idShift =:idShift");
		 			 q.setParameter("idShift", idShift);
		 			 ShiftName=(String) q.uniqueResult();
		 			
		 			 
			 			
					 Query a=session.createQuery("SELECT isPaid FROM TblLeave where idLeave = :idLeave");
					 a.setParameter("idLeave", idLeave);
					 int ispaid=(int) a.uniqueResult();
					 
					 if(ispaid>0)
					 {
						 Paidleaves++;
					 }
					 else 
					 {
						 NonPaidleaves++;
					 }
		 			
		 				j++;
		 			}
		 			if(!leave.isEmpty())
		 			{
		 			Query w=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
		 			w.setParameter("idDesignation", idDesignation);
		 			List <Object[]> dept=w.list();
		 			 deptName=(String) dept.get(0)[2];
		 			 System.err.println("deptName"+deptName);
		 			 Desname=(String)dept.get(0)[0];
		 			 System.err.println("Desname"+Desname);
		 			 
		 			 Query c=session.createQuery("select name from Catagory where idCatagory in (select idCatagory from Designation where idDesignation =:idDesignation ) ");
		 			 c.setParameter("idDesignation", idDesignation);
		 			 CategoryName=(String) c.uniqueResult();
		 			
		 			
			       
			        
					Leave_report.add(ShiftName);
					Leave_report.add(deptName);
					Leave_report.add(Desname);
					Leave_report.add(CategoryName);
					Leave_report.add(Paidleaves);
					Leave_report.add(NonPaidleaves);
					Leave_report.add(leave.size());
					Leave_report.add(date);
					Total.add(Leave_report);
		 			}
		 	}
		 		 
		 		  calendar.add(Calendar.DATE, 1);
		 	System.err.println("Total"+Total);
		 	  
		  }
		 	return Total;
		 }
		public Attd_leave_reportbetweenDates totalReportbetweenDates(Date Startdate,Date lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
		 {
			 	Session session = (Session) hipernateConfg.getSession();  
			
				List<List> presentreportBetdates=new ArrayList<List>();
				List<List> leavereportbetdates=new ArrayList<List>();
				List Totalbetdates=new ArrayList();
				List total =new ArrayList();
				List employees=new ArrayList();
				
				total=this.presentReportbetweenDates(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,Employee_Code);
				System.err.println("presentreportBetdates"+presentreportBetdates); 
				
				
				presentreportBetdates= (List<List>) total.get(0);
				attd.setPresentreportBetdates(presentreportBetdates);
				employees= (List) total.get(1);
				
				leavereportbetdates=this.leaveReportbetweenDates(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,Employee_Code);
				System.err.println("leavereportbetdates"+leavereportbetdates);
				attd.setLeavereportbetdates(leavereportbetdates);
				
							
			 	float Workhours=0.0f;
			 	float DaysConverted=0.0f;
			 	float Workefficiency=0.0f;
			 	float Paidleaves=0.0f;
			 	float NonPaidleaves=0.0f;
			 	int Totalleaves=0;
			 	float TotalEfficiency=0.0f;
			 	
				for(int i=0;i<presentreportBetdates.size();i++)
				{
					 System.err.println("i"+i);
					 
					 Workhours +=(float) presentreportBetdates.get(i).get(6);
					 System.err.println("Workhours"+Workhours);
					 DaysConverted +=(float) presentreportBetdates.get(i).get(7);
					 System.err.println("DaysConverted"+DaysConverted);
					 Workefficiency +=(float) presentreportBetdates.get(i).get(8);
					 
								
				}
				
				for(int j=0;j<leavereportbetdates.size();j++)
				{
					System.err.println("j"+j);
				    Paidleaves +=(float) leavereportbetdates.get(j).get(4);
				     NonPaidleaves +=(float) leavereportbetdates.get(j).get(5);
					Totalleaves += (int) leavereportbetdates.get(j).get(6);
				}
				
				TotalEfficiency=Workefficiency/presentreportBetdates.size();
				Totalbetdates.add(employees.size());
				Totalbetdates.add(Workhours);
				Totalbetdates.add(DaysConverted);
				Totalbetdates.add(TotalEfficiency);
				Totalbetdates.add(Paidleaves);
				Totalbetdates.add(NonPaidleaves);
				Totalbetdates.add(Totalleaves);
				attd.setTotalbetdates(Totalbetdates);
				session.close();
				 return attd;
		 }
		public List leaveReportbetweenMonth(String Startdate,String lastDate,String Group,String Department,String Catagory,String Designation,String Shift,String empcode) throws ParseException
		 {
		 	
			 GregorianCalendar gcal = new GregorianCalendar();
			 Session session = (Session) hipernateConfg.getSession();  
		 	 Transaction t = session.beginTransaction();
		 	List<Integer> Common_list=new ArrayList<Integer>();
		 	
		 	List Total=new ArrayList();

		 	List<Integer> Shift_report=new ArrayList<Integer>();
		 	int idemp=0;
		 	//Group, Department,Category,Designation,Shift,Employee Code,Date
		 		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		 		Calendar calendar = Calendar.getInstance();
		 	 Date start = format.parse(Startdate);
		 	 System.err.println("start"+start);
		 	System.err.println("lastDate"+lastDate);
			 Date end = format.parse(lastDate);
			 System.err.println("end"+end);
			 gcal.setTime(start);
			 
		 	System.err.println("Designation"+Designation + "Department"+Department +"Catagory"+Catagory );
		 	
		 	Common_list=WDFilterdao.commonDesignation(Designation, Department, Catagory,empcode);
		 	
		 	System.err.println("Common_list"+Common_list);
		 	//Date date1=format.parse(format.format(date));
		 	
		 	
		 	while(!gcal.getTime().after(end))
		 	{
		 		
		 		Date date = gcal.getTime();
				 System.out.println(date);
				 gcal.add(Calendar.MONTH, 1);
						     
				 Date firstdate=gcal.getTime();
				 gcal.add(Calendar.MONTH, 1);  
				 gcal.set(Calendar.DAY_OF_MONTH, 1);  
				 gcal.add(Calendar.DATE, -1); 
				 Date lstDate=gcal.getTime();
		 		
		 		System.err.println("date in loop"+date);
		 		
		 		int idshift=0;
		 		
		 		String base="select idLeave, idShift from Empleave as leave where idDesignation =:idDesignation and Date =:date ";
		 		  if(!Shift.isEmpty())
		 		  {
		 			  
		 			  String byShift = " and idShift = :idshift ";
		 			  
		 			  base = base.concat(byShift);
		 			   		Shift e1=new Shift();
		 				  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
		 				  	idshift=e1.getIdShift();
		 				    System.err.println("idshift"+idshift);
		 				    System.err.println("Common_list"+Common_list);
		 				    Query shift=session.createQuery("select idDesignation from Empleave where idShift =:idshift and Date=:date");
		 				   shift.setParameter("idshift", idshift);
		 				   shift.setParameter("date", date);
		 				   Shift_report=shift.list();
		 				   System.err.println("Shift_report"+Shift_report+"date"+date);
		 				   Common_list.retainAll(Shift_report);
		 				   		
		 		  }
		 		 
		 		  System.err.println("common list after shift"+Common_list);
		 		  
		 		  for(int i=0;i<Common_list.size();i++)
		 		  {
		 			  
		 			 Map Leave_report=new HashMap();
		 			 float Paidleaves=0.0f;
		 			 float NonPaidleaves=0.0f;
		 			 float leave_count =0.0f;
		 			 int idDesignation=Common_list.get(i);
		 			 float totalworkinghours=0.0f;
		 		  	 System.err.println("idDesignation"+idDesignation);
		 		  	
		 			Query r=session.createQuery(base);
		 			r.setParameter("idDesignation", idDesignation);
		 			r.setParameter("date", date);
		 			if(!Shift.isEmpty())
		 			{
		 				r.setParameter("idshift", idshift);
		 			}
		 			List<Object[]> leave=r.list();
		 			int j=0;
		 			System.err.println("No.of records "+leave.size());
		 			String ShiftName="", deptName = "",Desname ="", CategoryName="";
		 			
		 			
		 			while(j<leave.size())
		 			{
		 			int idShift=(int) leave.get(j)[1];
		 			int idLeave=(int) leave.get(j)[0];
		 			
		 			
		 			 Query q=session.createQuery("select name from Shift where idShift =:idShift");
		 			 q.setParameter("idShift", idShift);
		 			 ShiftName=(String) q.uniqueResult();
		 			
		 			 
			 			
					 Query a=session.createQuery("SELECT isPaid FROM TblLeave where idLeave = :idLeave");
					 a.setParameter("idLeave", idLeave);
					 int ispaid=(int) a.uniqueResult();
					 
					 if(ispaid==1)
					 {
						 Paidleaves++;
					 }
					 else 
					 {
						 NonPaidleaves++;
					 }
		 			
		 				j++;
		 			}
		 			if(!leave.isEmpty())
		 			{
		 			Query w=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
		 			w.setParameter("idDesignation", idDesignation);
		 			List <Object[]> dept=w.list();
		 			 deptName=(String) dept.get(0)[2];
		 			 System.err.println("deptName"+deptName);
		 			 Desname=(String)dept.get(0)[0];
		 			 System.err.println("Desname"+Desname);
		 			 
		 			 Query c=session.createQuery("select name from Catagory where idCatagory in (select idCatagory from Designation where idDesignation =:idDesignation ) ");
		 			 c.setParameter("idDesignation", idDesignation);
		 			 CategoryName=(String) c.uniqueResult();
		 			
		 			
			       
			        
					Leave_report.put("ShiftName",ShiftName);
					Leave_report.put("deptName",deptName);
					Leave_report.put("Desname",Desname);
					Leave_report.put("CategoryName",CategoryName);
					Leave_report.put("Paidleaves",Paidleaves);
					Leave_report.put("NonPaidleaves",NonPaidleaves);
					Leave_report.put("count",leave.size());
					Leave_report.put("date",date);
					Total.add(Leave_report);
		 			}
		 		
		 	}
		 		 
		 		 gcal.add(Calendar.MONTH, 1);
		 		 Date d=calendar.getTime();
		 	System.err.println("Total"+Total);
		 	  
		  }
		 	return Total;
		 }
		 
		 public Attd_leave_reportbyMonth totalReportbetweenMonth(String empcode,String Startdate,String lastDate,String Group,String Department,String Catagory,String Designation,String Shift) throws ParseException
		 {
			 Session session = (Session) hipernateConfg.getSession();  
		 	 Transaction t = session.beginTransaction();
			
		 	 	List<List> presentreportBetMonth=new ArrayList<List>();
				List<List> leavereportbetMonth=new ArrayList<List>();
				List TotalbetMonth=new ArrayList();
				List employees=new ArrayList();
				List total =new ArrayList();
				
				total=this.presentReportbetweenMonth(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
				System.err.println("presentreportBetMonth"+total);
				
				presentreportBetMonth=  (List<List>) total.get(0);
				aatm.setPresentreportBetMonth(presentreportBetMonth);
				System.err.println("*********prevsentreportBetMonth"+presentreportBetMonth);
				employees=(List) total.get(1);
				
				leavereportbetMonth=this.leaveReportbetweenMonth(Startdate, lastDate, Group, Department, Catagory, Designation, Shift,empcode);
				System.err.println("leavereportbetMonth"+leavereportbetMonth);
				aatm.setLeavereportbetMonth(leavereportbetMonth);
				
				float Workhours=0.0f;
			 	float DaysConverted=0.0f;
			 	float Workefficiency=0.0f;
			 	float Paidleaves=0.0f;
			 	float NonPaidleaves=0.0f;
			 	int Totalleaves=0;
			 	float TotalEfficiency=0.0f;
			 	for(int i=0;i<presentreportBetMonth.size();i++)
				{
					 System.err.println("i"+i);
					 
					 Workhours +=(float) presentreportBetMonth.get(i).get(6);
					 System.err.println("Workhours"+Workhours);
					 DaysConverted +=(float) presentreportBetMonth.get(i).get(7);
					 System.err.println("DaysConverted"+DaysConverted);
					 Workefficiency +=(float) presentreportBetMonth.get(i).get(8);
					 						
				}
						for(int j=0;j<leavereportbetMonth.size();j++)
				{
					System.err.println("j"+j);
				    Paidleaves +=(float) leavereportbetMonth.get(j).get(4);
				    NonPaidleaves +=(float) leavereportbetMonth.get(j).get(5);
					Totalleaves += (int) leavereportbetMonth.get(j).get(6);
				}
						
				TotalEfficiency=Workefficiency/presentreportBetMonth.size();
				TotalbetMonth.add(employees.size());
				TotalbetMonth.add(Workhours);
				TotalbetMonth.add(DaysConverted);
				TotalbetMonth.add(TotalEfficiency);
				TotalbetMonth.add(Paidleaves);
				TotalbetMonth.add(NonPaidleaves);
				TotalbetMonth.add(Totalleaves);
				aatm.setTotalbetMonth(TotalbetMonth);
				
			 return aatm;
		 } 
		 public List ShiftReportbyday(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
		 {
			
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			List<Integer> Common_list=new ArrayList<Integer>();
			List ShiftReport=new ArrayList();
			List<Integer> Shift_report=new ArrayList<Integer>();
			int idemp=0;
			//Group, Department,Category,Designation,Shift,Employee Code,Date
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Date date1=format.parse(format.format(date));
		System.err.println("date(************** " +date1);
			Common_list=WDFilterdao.commonEmployees(Designation, Department, Catagory, Employee_Code);
		
			int idshift=0;
					
	      if(!Shift.isEmpty())
	      {
	   	   		Shift e1=new Shift();
	  		  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
	  		  	idshift=e1.getIdShift();
	  		
	  		   Query shift=session.createQuery("select idEmployees from Attendance where idShift =:idshift and date=:date");
	  		   shift.setParameter("idshift", idshift);
	  		
	  		   shift.setParameter("date", date1);
	  		   Shift_report=shift.list();
	  		  
	  		   Common_list.retainAll(Shift_report);
	  		   		
	      }
	   
	     
	     

	      System.err.println("Common_list"+Common_list);
	      try {
	      Query r=session.createQuery("select empt.name as Emptype,dept.name as department,"
	      		+ "cat.name as Catagory,desg.name as Designation,emp.employeeCode as EmployeeCode,"
	      		+ "sft.name as Shift,CONCAT(emp.emp_First_Name, ' ',emp.emp_Middle_Name,' ',"
	      		+ "emp.emp_Last_Name) AS EmployeeName from Department as dept, Shift as sft,"
	      		+ "Emptype as empt ,Employees AS emp, Catagory AS cat ,Designation as desg, "
	      		+ "EmpWorkDetails as empwork  where emp.idEmployees in : Common_list and "
	      		+ "empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees) "
	      		+ "and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees) "
	      		+ "and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation) "
	      		+ "and dept.idDepartment = (select idDepartment from Catagory  where idCatagory = cat.idCatagory) "
	      		+ "and sft.idShift=(select distinct idShift from Attendance where date = :date and idEmployees = emp.idEmployees) "
	      		+ "and empwork.idEmpWorkDetails = (select idEmpWorkDetails from EmpWorkDetails where idEmployees=emp.idEmployees)");
			r.setParameter("Common_list", Common_list);
			r.setParameter("date", date1);
			ShiftReport=r.list();
	      }
	      catch (Exception e) {
			// TODO: handle exception
		}
			System.err.println("ShiftReport"+ShiftReport);
			float allowance=0.0f;
			try {
			Query shift=session.createQuery("select allownce from ShiftAllownce where idShift =:idshift ");
			shift.setParameter("idshift", idshift);
			 allowance=(float) shift.uniqueResult();
			}
			catch (Exception e) {
				// TODO: handle exception
			}
			ShiftReport.add(allowance);
			
			
			return ShiftReport;
	     
		 }
		public List ShiftwiseReportbyday(Date date,String Shift) throws ParseException
		{

			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			Map ShiftReport=new HashMap();
			List shiftReport=new ArrayList();
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
			Date date1=format.parse(format.format(date));
			Shift e1=new Shift();
			
			
			e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name", Shift )).uniqueResult();
			int idshift=e1.getIdShift();
			
			Query q=session.createQuery("select count(idEmployees) from Attendance where Date = :date and idShift =:idshift");
			q.setParameter("date", date);
			q.setParameter("idshift", idshift);
			long empcount=(long) q.uniqueResult();
			
			Query a=session.createQuery("select allownce from ShiftAllownce where idShift = :idshift");
			a.setParameter("idshift", idshift);
			float allowance=(float) a.uniqueResult();
			
			float Allowance_per_shift=empcount*allowance;
			
			
			
			ShiftReport.put("Shift",Shift);
			ShiftReport.put("empcount",empcount);
			ShiftReport.put("allowance",allowance);
			ShiftReport.put("Allowance_per_shift",Allowance_per_shift);
			shiftReport.add(ShiftReport);
			return shiftReport;
		}
		
		public List ShiftReport(Date date) throws ParseException
		{
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			List shift=new ArrayList();
			List shiftreport=new ArrayList();
			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
			Date date1=format.parse(format.format(date));
			Query s=session.createQuery("select name from Shift ");
			shift=s.list();
			float Allowance_per_shift =0.0f;
			long count=0; 
			float Totalemp=0.0f;
			float totalallowance=0.0f;
			
			for(int i=0;i<shift.size();i++)
			{

				Map Shift_Report =new HashMap();
			String ShiftName=(String) shift.get(i);
			
			Shift e1=new Shift();
			e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("name",ShiftName)).uniqueResult();
			int idshift=e1.getIdShift();
			
			
				Query q=session.createQuery("select count(idEmployees) from Attendance where date = :date and idShift =:idshift");
				q.setParameter("date", date);
				q.setParameter("idshift", idshift);
				
				count=(long) q.uniqueResult();
				Totalemp += count;
				System.err.println("idShift"+idshift);
				Query a=session.createQuery("select allownce from ShiftAllownce where idShift = :idshift");
				a.setParameter("idshift", idshift);
				float allowance=(float) a.uniqueResult();
				Allowance_per_shift=count*allowance;
				totalallowance += Allowance_per_shift;
				
				Shift_Report.put("Totalemp",Totalemp);
				Shift_Report.put("totalallowance",totalallowance);
				shiftreport.add(Shift_Report);
			}
			
			
			return shiftreport;
		}
		
		public List ShiftReportbetweenDates(Date Startdate,Date Enddate,String shift) throws ParseException
		{
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			Calendar calendar = Calendar.getInstance();
			
			Date Fd=format.parse(format.format(Startdate));
			calendar.setTime(Startdate);
			List Shifts=new ArrayList();
			List Total=new ArrayList();		
			while(!calendar.getTime().after(Enddate))
			{
				
				Date date=calendar.getTime();
			
				System.err.println("Date "+date);
				Criteria cr=session.createCriteria(Shift.class);
				Projection pr=Projections.property("idShift");
				ProjectionList pl=Projections.projectionList();
				pl.add(pr);
				cr.setProjection(pl);
				Shifts=cr.list();
				
				if(!shift.isEmpty())
				{
					cr.add(Restrictions.eq("name", shift));
					cr.setProjection(pl);
					int idShift=(int) cr.uniqueResult();
					Shifts.clear();
					Shifts.add(idShift);
				}
				System.err.println("Shift count"+Shifts.size());
				for(int i=0;i<Shifts.size();i++)
				{	
					
					
					List hm1=new ArrayList();
					int idShift=(int) Shifts.get(i);
					
					Criteria designations=session.createCriteria(Attendance.class);
					designations.add(Restrictions.eq("date", date));
					designations.add(Restrictions.eq("idShift", idShift)); 
					designations.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
					Projection prc=Projections.distinct(Projections.property("idDesignation"));
					designations.setProjection(prc);
					hm1=designations.list();
					System.err.println("Designation size "+hm1.size());
					for(int j=0;j<hm1.size();j++)
					{
						System.err.println("designation at "+j+" = "+hm1.get(j));
					}
					for(int j=0;j<hm1.size();j++)
					{
						Map record=new HashMap();
						int	idDesignation=(int) hm1.get(j);
						System.err.println("Date loop"+date);
						System.err.println("Shift loop"+idShift);
						System.err.println(" Designations= "+idDesignation);
						Query query3=session.createQuery("SELECT  t1.name as desg, "
								+ "t2.name as dept, "
								+ "t3.name as cat "
								+ "FROM Designation t1,Department t2 ,Catagory t3 "
								+ "where t1.idDesignation= :idDesignation and t2.idDepartment = (select idDepartment from Designation where idDesignation = t1.idDesignation) and  t3.idCatagory = (Select idCatagory from Designation where idDesignation = t1.idDesignation)");
						query3.setParameter("idDesignation", idDesignation);
						List<Object[]> des=query3.list();
						Query q=session.createQuery("select count(idEmployees) from Attendance where date = :date and idDesignation=:idDesignation and idShift =:idshift");
						q.setParameter("date", date);
						q.setParameter("idDesignation", idDesignation);
						q.setParameter("idshift", idShift);
						long empcount=(long) q.uniqueResult();
						System.err.println(" empcount = "+empcount);
						Query a=session.createQuery("select allownce from ShiftAllownce where idShift = :idshift");
						a.setParameter("idshift", idShift);
						float allowance=(float) a.uniqueResult();
						
						float Allowance_per_shift=empcount*allowance;
						Criteria crshift = session.createCriteria(Shift.class);
						crshift.add(Restrictions.eq("idShift", idShift));
						Projection prs=Projections.property("name");
						crshift.setProjection(prs);
						String sftname = (String) crshift.uniqueResult();
						record.put("Designation",des.get(0)[0]);
						record.put("Department",des.get(0)[1]);
						record.put("Catagory",des.get(0)[2]);
						record.put("Date",date);
						record.put("Shift",sftname);
						record.put("No_of_Employees",empcount);
						record.put("Allownce",Allowance_per_shift);
						Total.add(record);
					}
				}
				
				calendar.add(Calendar.DATE, 1);
			}
			
			return Total;
		}
		
		public Object ShiftReportbetweendates1(String StartDate1,String Enddate1,String shift) throws ParseException
		{
			List Present =new ArrayList();
			
			
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			List Shifts=new ArrayList();
			List Total=new ArrayList();
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		
			 Date StartDate = format.parse(StartDate1);
			 Date Enddate = format.parse(Enddate1);
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(StartDate);
			Date fd=calendar.getTime();
			calendar.setTime(Enddate);
			Date ld=calendar.getTime();
			
			long No_of_Employees=0;
			float TotalAllowance=0.0f;
			
			Criteria cr=session.createCriteria(Shift.class);
			Projection pr=Projections.property("idShift");
			ProjectionList pl=Projections.projectionList();
			pl.add(pr);
			cr.setProjection(pl);
			Shifts=cr.list();
			if(!shift.isEmpty())
			{
				cr.add(Restrictions.eq("name", shift));
				cr.setProjection(pl);
				int idShift=(int) cr.uniqueResult();
				Shifts.clear();
				Shifts.add(idShift);
			}
			for(int i=0;i<Shifts.size();i++)
			{
				
				
				
				float Shiftallownce=0.0f;
				Map record=new HashMap();
				int idShift=(int) Shifts.get(i);
				Criteria cr1=session.createCriteria(Attendance.class);
				cr1.add(Restrictions.eq("idShift", idShift));
				cr1.add(Restrictions.between("date", fd, ld));
				
				Projection pr1=Projections.rowCount();
				cr1.setProjection(pr1);
				long count=(long) cr1.uniqueResult();
				
				No_of_Employees += count;
				
				Criteria ShiftAllcr=session.createCriteria(ShiftAllownce.class);
				ShiftAllcr.add(Restrictions.eq("idShift", idShift));
				Projection pr2=Projections.property("allownce");
				ShiftAllcr.setProjection(pr2);
				float all=(float) ShiftAllcr.uniqueResult();
				
				Criteria Shiftnamecr=session.createCriteria(Shift.class);
				Shiftnamecr.add(Restrictions.eq("idShift", idShift));
				Projection pr3=Projections.property("name");
				Shiftnamecr.setProjection(pr3);
				String ShiftName= (String) Shiftnamecr.uniqueResult();
				
				Shiftallownce = count*all;
				TotalAllowance += Shiftallownce;
				
				record.put("ShiftName",ShiftName);
				record.put("count",count);
				record.put("all",all);
				record.put("Shiftallownce",Shiftallownce);
				Total.add(record);
				
			}
			List Total1=new ArrayList();
			Total1.add(No_of_Employees);
			Total1.add(TotalAllowance);
			
			
			Present=this.ShiftReportbetweenDates(StartDate, Enddate, shift);
			sft.setPresent(Present);
			
			sft.setSummary(Total);
			sft.setTotal(Total1);
			return sft;
			
		}
		
		public Object ShiftReport1(String date1,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
		{
			List Present =new ArrayList();
			List Summary =new ArrayList();
			List total =new ArrayList();
			
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			Date date=format.parse(date1);
		
			Present=this.ShiftReportbyday(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
			sftre.setPresent(Present);
			
			Summary=this.ShiftwiseReportbyday(date, Shift);
			sftre.setSummary(Summary);
			
			total=this.ShiftReport(date);
			sftre.setTotal(total);
			
			return sftre;
		}
		
		public Object ShiftReportbetweenMonth(String StartDate,String Enddate,String shift) throws ParseException
		{
			List Present =new ArrayList();
			GregorianCalendar gcal = new GregorianCalendar();
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			List Shifts=new ArrayList();
			List Total=new ArrayList();
			long No_of_Employees=0;
			float TotalAllowance=0.0f;
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
			Calendar calendar = Calendar.getInstance();
			
			 Date start = format.parse(StartDate);
			 Date end = format.parse(Enddate);

			 gcal.setTime(start);
			
			Criteria cr=session.createCriteria(Shift.class);
			Projection pr=Projections.property("idShift");
			ProjectionList pl=Projections.projectionList();
			pl.add(pr);
			cr.setProjection(pl);
			Shifts=cr.list();
			if(!shift.isEmpty())
			{
				cr.add(Restrictions.eq("name", shift));
				cr.setProjection(pl);
				int idShift=(int) cr.uniqueResult();
				Shifts.clear();
				Shifts.add(idShift);
			}
			
			 while(!gcal.getTime().after(end))
			 {
					
					
					Date date = gcal.getTime();
					 System.out.println(date);
					 gcal.add(Calendar.MONTH, 1);
							     
					 Date firstdate=gcal.getTime();
					 gcal.add(Calendar.MONTH, 1);  
					gcal.set(Calendar.DAY_OF_MONTH, 1);  
					gcal.add(Calendar.DATE, -1); 
					 Date lstDate=gcal.getTime();
			for(int i=0;i<Shifts.size();i++)
			{
				float Shiftallownce=0.0f;
				long count=0;
				Map record=new HashMap();
				int idShift=(int) Shifts.get(i);
				Criteria cr1=session.createCriteria(Attendance.class);
				cr1.add(Restrictions.eq("idShift", idShift));
				cr1.add(Restrictions.eq("date", date));
				Projection pr1=Projections.rowCount();
				
				cr1.setProjection(pr1);
				count=(long) cr1.uniqueResult();
				System.err.println("count"+count);
				No_of_Employees += count;
				
				
				Criteria ShiftAllcr=session.createCriteria(ShiftAllownce.class);
				ShiftAllcr.add(Restrictions.eq("idShift", idShift));
				Projection pr2=Projections.property("allownce");
				ShiftAllcr.setProjection(pr2);
				float all=(float) ShiftAllcr.uniqueResult();
				
				Criteria Shiftnamecr=session.createCriteria(Shift.class);
				Shiftnamecr.add(Restrictions.eq("idShift", idShift));
				Projection pr3=Projections.property("name");
				Shiftnamecr.setProjection(pr3);
				String ShiftName= (String) Shiftnamecr.uniqueResult();
				
				Shiftallownce = count*all;
				TotalAllowance += Shiftallownce;
				
				record.put("ShiftName",ShiftName);
				record.put("count",count);
				record.put("all",all);
				record.put("Shiftallownce",Shiftallownce);
				Total.add(record);
				}
				gcal.add(Calendar.MONTH, 1);
			 }
			 
		

			List Total1=new ArrayList();
			Total1.add(No_of_Employees);
			Total1.add(TotalAllowance);
			
			
			Present=this.ShiftpReportbetweenMonth1(StartDate, Enddate, shift);
			sft.setPresent(Present);
			
			sft.setSummary(Total);
			sft.setTotal(Total1);
			return sft;
			
		}
		
		public List ShiftpReportbetweenMonth1(String Startdate,String Enddate,String shift) throws ParseException
		{
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
			GregorianCalendar gcal = new GregorianCalendar();
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");
			Calendar calendar = Calendar.getInstance();
			
			 Date start = format.parse(Startdate);
			 Date end = format.parse(Enddate);

			 gcal.setTime(start);
			List Shifts=new ArrayList();
			List Total=new ArrayList();		
			
			while(!gcal.getTime().after(end))
			 {
				
					Date date = gcal.getTime();
					System.out.println(date);
					gcal.add(Calendar.MONTH, 1);
							     
					 Date firstdate=gcal.getTime();
					 gcal.add(Calendar.MONTH, 1);  
					 gcal.set(Calendar.DAY_OF_MONTH, 1);  
					 gcal.add(Calendar.DATE, -1); 
					 int month=gcal.get(gcal.MONTH);
					 Date lstDate=gcal.getTime();
			
				System.err.println("Date "+firstdate+"lastdate"+lstDate);
				Criteria cr=session.createCriteria(Shift.class);
				Projection pr=Projections.property("idShift");
				ProjectionList pl=Projections.projectionList();
				pl.add(pr);
				cr.setProjection(pl);
				Shifts=cr.list();
				
				if(!shift.isEmpty())
				{
					cr.add(Restrictions.eq("name", shift));
					cr.setProjection(pl);
					int idShift=(int) cr.uniqueResult();
					Shifts.clear();
					Shifts.add(idShift);
				}
				System.err.println("Shift count"+Shifts.size());
				for(int i=0;i<Shifts.size();i++)
				{	
					
					
					List hm1=new ArrayList();
					int idShift=(int) Shifts.get(i);
					
					Criteria designations=session.createCriteria(Attendance.class);
					designations.add(Restrictions.eq("date",date));
					designations.add(Restrictions.eq("idShift", idShift)); 
					designations.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
					Projection prc=Projections.distinct(Projections.property("idDesignation"));
					designations.setProjection(prc);
					hm1=designations.list();
					System.err.println("Designation size "+hm1.size());
					for(int j=0;j<hm1.size();j++)
					{
						System.err.println("designation at "+j+" = "+hm1.get(j));
					}
					for(int j=0;j<hm1.size();j++)
					{
						Map record=new HashMap();
						int	idDesignation=(int) hm1.get(j);
						System.err.println("Date loop"+date);
						System.err.println("Shift loop"+idShift);
						System.err.println(" Designations= "+idDesignation);
						Query query3=session.createQuery("SELECT  t1.name as desg, "
								+ "t2.name as dept, "
								+ "t3.name as cat "
								+ "FROM Designation t1,Department t2 ,Catagory t3 "
								+ "where t1.idDesignation= :idDesignation and t2.idDepartment = (select idDepartment from Designation where idDesignation = t1.idDesignation) and  t3.idCatagory = (Select idCatagory from Designation where idDesignation = t1.idDesignation)");
						query3.setParameter("idDesignation", idDesignation);
						List<Object[]> des=query3.list();
						Query q=session.createQuery("select count(idEmployees) from Attendance where Date =:date and idDesignation=:idDesignation and idShift =:idshift");
						q.setParameter("date", date);
						q.setParameter("idDesignation", idDesignation);
						q.setParameter("idshift", idShift);
						long empcount=(long) q.uniqueResult();
						System.err.println(" empcount = "+empcount);
						Query a=session.createQuery("select allownce from ShiftAllownce where idShift = :idshift");
						a.setParameter("idshift", idShift);
						float allowance=(float) a.uniqueResult();
						
						float Allowance_per_shift=empcount*allowance;
						Criteria crshift = session.createCriteria(Shift.class);
						crshift.add(Restrictions.eq("idShift", idShift));
						Projection prs=Projections.property("name");
						crshift.setProjection(prs);
						String sftname = (String) crshift.uniqueResult();
						record.put("Designation",des.get(0)[0]);
						record.put("Department",des.get(0)[1]);
						record.put("Catagory",des.get(0)[2]);
						record.put("month",month);
						record.put("Shift",sftname);
						record.put("NoOfEmployees",empcount);
						record.put("Allownce",Allowance_per_shift);
						Total.add(record);
					}
				}
				
				gcal.add(Calendar.MONTH, 1);
			}
			
			return Total;
		}
	
}
