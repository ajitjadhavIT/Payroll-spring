package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pt")
public class ProfessionalTax {
//idPT, idEmpType, fromAmount, toAmount, taxPercent
	@Id
	int idPT;
	int idEmpType;
	float fromAmount;
	float toAmount;
	float taxPercent;
	public int getIdPT() {
		return idPT;
	}
	public void setIdPT(int idPT) {
		this.idPT = idPT;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public float getfromAmount() {
		return fromAmount;
	}
	public void setfromAmount(float fromAmount) {
		fromAmount = fromAmount;
	}
	public float gettoAmount() {
		return toAmount;
	}
	public void settoAmount(float toAmount) {
		toAmount = toAmount;
	}
	public float gettaxPercent() {
		return taxPercent;
	}
	public void settaxPercent(float taxPercent) {
		taxPercent = taxPercent;
	}
	@Override
	public String toString() {
		return "ProfessionalTax [idPT=" + idPT + ", idEmpType=" + idEmpType + ", fromAmount=" + fromAmount
				+ ", toAmount=" + toAmount + ", taxPercent=" + taxPercent + "]";
	}
	
	
}
