package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bonussetting")
public class BonusSetting
{
	@Id
	int idBonusSetting;
	float condition1;
	float percent;
	int startmonth;
	int endmonth;
	public int getIdBonusSetting() {
		return idBonusSetting;
	}
	public void setIdBonusSetting(int idBonusSetting) {
		this.idBonusSetting = idBonusSetting;
	}
	public float getCondition1() {
		return condition1;
	}
	public void setCondition1(float condition1) {
		this.condition1 = condition1;
	}
	public float getPercent() {
		return percent;
	}
	public void setPercent(float percent) {
		this.percent = percent;
	}
	public int getStartmonth() {
		return startmonth;
	}
	public void setStartmonth(int startmonth) {
		this.startmonth = startmonth;
	}
	public int getEndmonth() {
		return endmonth;
	}
	public void setEndmonth(int endmonth) {
		this.endmonth = endmonth;
	}
	
}
