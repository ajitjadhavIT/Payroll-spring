package com.example.PayRoll.Manager;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import com.example.PayRoll.DAO.leaveApplicationDAO;
import com.example.PayRoll.POJO.leaveApplication;

@Component
@Controller
public class leaveApplicationManager
{
@Autowired
leaveApplicationDAO leadao;
	public leaveApplication get(String empcode) 
	{
		return leadao.get(empcode);
	}
	public List getall() 
	{
		return leadao.getall();
	}

	public leaveApplication save(int id,String empcode,String DateFrom, String DateTo,String Reason,String leave,String Description,String Application_Date,int Status) throws ParseException
	{

		return leadao.save(id,empcode, DateFrom, DateTo, Reason, leave, Description, Application_Date,Status);
	}	

}
