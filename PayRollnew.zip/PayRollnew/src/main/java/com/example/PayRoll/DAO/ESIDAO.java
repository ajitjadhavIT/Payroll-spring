package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.ESI;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Employees;
@Controller
@Component

public class ESIDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	
	
	public String save(ESI esi) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		//idESI, idEmpType, FromAmount, ToAmount, Percent

		session.saveOrUpdate(esi);
		t.commit();  
		
		session.close();
		
		return "saved Successfully";
		
		
	}

	public Object get()
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		
		
		//@SuppressWarnings("deprecation")
			//Criteria cr = session.createCriteria(Employees.class);
				//cr.add(Restrictions.eq("id", id));
				//return cr.list();
		
		
		/*return session.createCriteria(Employees.class)
			    .createCriteria("idEmpType", "EmpType")
		        .add( Restrictions.eq("Name", "Staff") )
		    .setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
		    .list();
		*/
		DetachedCriteria avgWeightForSex = DetachedCriteria.forClass(EmpWorkDetails.class, "EmpWorkDe")
			    .setProjection( Property.forName("idEmployees") )
			    .add( Property.forName("EmpWorkDe.idDesignation").eqProperty("Desig.idDesignation") );
			session.createCriteria(Designation.class, "Desig")
			    .add( Property.forName("Name").eq("MIXING ATTENDENT") )
			    .list();
		
		return avgWeightForSex;
		
	}

}
