package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="absent")
public class Absent
{
	@Id
	int idabsent;
	Date date;
	int idShift;
    int idDesignation;
   int idEmployees;
   String reason;
public int getIdabsent() {
	return idabsent;
}
public void setIdabsent(int idabsent) {
	this.idabsent = idabsent;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public int getIdShift() {
	return idShift;
}
public void setIdShift(int idShift) {
	this.idShift = idShift;
}
public int getIdDesignation() {
	return idDesignation;
}
public void setIdDesignation(int idDesignation) {
	this.idDesignation = idDesignation;
}
public int getIdEmployees() {
	return idEmployees;
}
public void setIdEmployees(int idEmployees) {
	this.idEmployees = idEmployees;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
@Override
public String toString() {
	return "Absent [idabsent=" + idabsent + ", date=" + date + ", idShift=" + idShift + ", idDesignation="
			+ idDesignation + ", idEmployees=" + idEmployees + ", reason=" + reason + "]";
}

}
