package com.example.PayRoll.DAO;


import java.util.ArrayList;
import java.util.Date;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.Manager.BasicSalaryManager;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Hoursleave;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.Salary;
import com.example.PayRoll.POJO.SalaryDeduction;
import com.example.PayRoll.POJO.SalaryDetails;
import com.example.PayRoll.POJO.SalaryEarning;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.POJO.ShiftAllownce;
import com.example.PayRoll.POJO.Welfare;

@Controller
@Component


public class EmployeeSalaryDAO{
	@Autowired
	HipernateConfg hipernateConfg;

	@Autowired
	BasicSalaryDAO bsDAO;
	@Autowired
	BasicSalaryManager BSmanager;
	@Autowired
	OtherDeductionDAO ODdao;
    @Autowired
    AllDeductionDAO ADdao;
	public List EmpSal(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Object[]> hm = new ArrayList<Object[]>();
		
		Criteria c=session.createCriteria(Employees.class);
		c.add(Restrictions.eq("employeeCode", empcode));
		Projection p1=Projections.property("idEmployees");
			
		c.setProjection(p1);
		int idEmp=(int) c.uniqueResult();
		
		Criteria cr=session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", idEmp));
		Projection pr=Projections.property("date");
		Projection pr1=Projections.property("idShift");
		Projection pr2=Projections.property("idDesignation");
		ProjectionList pl=Projections.projectionList();
		pl.add(pr);
		pl.add(pr1);
		pl.add(pr2);
		cr.setProjection(pl);
		hm=cr.list();
		List<Map<String, Object>> TableValues = new ArrayList<Map<String, Object>>();
	
	//HashMap<String,String> ShiftName = new HashMap<String,String>();
		int idDesignation=0;
		int idShift=0;
		Date date;
		float leavehours=0.0f;
		float Allownce=0.0f;
		float basicSalary=0.0f;
		Float Overtime=0.0f;
		
		int x=0;
		for(Object[] row : hm)
		{
			Map<String,Object> values= new HashMap<String,Object>();
			date = (Date) row[0];
			idDesignation = (int) row[2];
			idShift= (int) row[1];
			Criteria cp=session.createCriteria(Designation.class);
			cp.add(Restrictions.eq("idDesignation", idDesignation));
			Projection a=Projections.property("short_Form");
			Projection a1=Projections.property("salary");
			ProjectionList ps=Projections.projectionList();
			ps.add(a);
			ps.add(a1);
			cp.setProjection(ps);
			List<Object[]> desShortformSal=cp.list();
			
			String Shortform=(String) desShortformSal.get(0)[0];
			basicSalary=(float) desShortformSal.get(0)[1];
			Criteria cd=session.createCriteria(Shift.class);
			cd.add(Restrictions.eq("idShift", idShift));
			Projection ap=Projections.property("name");
			cd.setProjection(ap);
			String ShiftName=(String)cd.uniqueResult();
			try {
				Criteria ds=session.createCriteria(Hoursleave.class);
				ds.add(Restrictions.eq("idEmployees", idEmp));
				ds.add(Restrictions.eq("idShift", idShift));
				ds.add(Restrictions.eq("date", date));
				Projection s=Projections.property("hours");
				ds.setProjection(s);
				leavehours=(float) ds.uniqueResult();
		
				Criteria z=session.createCriteria(ShiftAllownce.class);
				z.add(Restrictions.eq("idShift", idShift));
				Projection pa=Projections.property("allownce");
				z.setProjection(pa);
				Allownce=(float) z.uniqueResult();
				
				Criteria cd1=session.createCriteria(Overtime.class);
				cd1.add(Restrictions.eq("idEmployees", idEmp));

				cd1.add(Restrictions.eq("date", date));
				Projection d=Projections.property("hours");
				cd.setProjection(d);
				Overtime=(Float) cd.uniqueResult();
			}
			catch(Exception ex)
			{
				leavehours=0;
				Allownce=0;
			}
			values.put("Date", date);
			values.put("Shortform", Shortform);
			values.put("ShiftName", ShiftName);
			values.put("leavehours", leavehours);
			values.put("basicSalary", basicSalary);
			values.put("Allownce", Allownce);
			values.put("Overtime", Overtime);
			float leavsal=(basicSalary/8)*leavehours;
			float OvertimeSal=(basicSalary/8)*Overtime;
			values.put("leavSal", leavsal);
			float salary=basicSalary+OvertimeSal+Allownce-(leavsal);
			values.put("Salary", salary);
			x++;
			TableValues.add(values);
		
		}
		session.close();
	return TableValues;
	}
	
	
	public double EmployeeSalary(String empcode, int month, int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Map<String,Float> TotalDeductions=new HashMap();
		Map<String,Float> TotalEarning=new HashMap();
		
		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
		 
		
		Map Designation_Days=new HashMap();
		
		Designation_Days=bsDAO.DesigID_PresntDay(empcode, month, year);
	
		Criteria c=session.createCriteria(Employees.class);
		c.add(Restrictions.eq("employeeCode", empcode));
		Projection p=Projections.property("idEmployees");
			
		c.setProjection(p);
		int empid=(int) c.uniqueResult();
	
		Map Info=new HashMap();
		Info=bsDAO.info(empcode);//Emp_id& Emp_Name
		String EmpName=(String) Info.get("EmployeeName");
	
		
		
		float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
	
		float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
	
		float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
		float mOvertime=bsDAO.Overtime(empcode, month, year);
	
		float totalEarn=BasicSalary+incentive+ThirdShift+mOvertime;

		TotalEarning.put("Incentive",incentive );
		TotalEarning.put("Third Shift Allownce", ThirdShift);
		TotalEarning.put("Overtime", mOvertime);
		TotalEarning.put("Basic ", BasicSalary);
		
		float pf=0.0f;
	
		float pt=0.0f;
	
		float esi=0.0f;
	
		float tds=0.0f;
	
		float society=0.0f;
		float welfare=Welfare(empcode, month);

		float AllTaxDeductions=pf+pt+esi+tds+society;
	
		TaxDeduction=ADdao.CalDeductions((int) empid, BasicSalary);//TaxDeductions
	
	
	
	if(TaxDeduction.containsKey("PF"))
	{
		
	pf=(float) TaxDeduction.get("PF");

	}
	if(TaxDeduction.containsKey("PT"))
	{
		
	 pt=(float) TaxDeduction.get("PT");
	
	}
	if(TaxDeduction.containsKey("ESI"))
	{
	 esi=(float) TaxDeduction.get("ESI");
	
	}
	if(TaxDeduction.containsKey("TDS"))
	{
	 tds=(float) TaxDeduction.get("TDS");

	}
	if(TaxDeduction.containsKey("Society"))
	{
	society=(float) TaxDeduction.get("Society");
	
	}
	
	
	
	OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
	
	TotalDeductions.putAll(OtherDeductions);
	TotalDeductions.putAll(TaxDeduction);
	TotalDeductions.put("Welfare", welfare);
	Map<String,Float> TotalDeductionsall=new HashMap(); 
	TotalDeductionsall.putAll(TotalDeductions);

	
	
	float bus =(float) OtherDeductions.get("Bus Charge");
	
	
	float phone =(float) OtherDeductions.get("Phone Bills");
	
	
	float House =(float) OtherDeductions.get("House Rent");
	
	
	float Loan =(float) OtherDeductions.get("Loan");
	
	
	float Canteen =(float) OtherDeductions.get("canteen Deduction");
	
	
	float Advance =(float) OtherDeductions.get("Advance");
	
	
	float Other =(float) OtherDeductions.get("Other");
	
	float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
	
	double Alldeduction=ODdao.AllDeduction(empcode, month, year);
	
	double TotalDeduction=Alldeduction+AllTaxDeductions;
	
	double NetPay=totalEarn+LeavHRsal-TotalDeduction;
	
	int idSal=0;
	
	Criteria cr=session.createCriteria(Salary.class);
	cr.add(Restrictions.eq("idEmployees", empid));
	cr.add(Restrictions.eq("month", month));
	cr.add(Restrictions.eq("year", year));
	Projection pr=Projections.rowCount();
	cr.setProjection(pr);
	long count=(long) cr.uniqueResult();
	System.err.println("count "+count);
	if(count==0)
	{
		
		Salary s=new Salary();

		s.setIdEmployees(empid);
		s.setMonth(month);
		s.setYear(year);
		s.setNetSalary(NetPay);
		s.setTotalEarning(totalEarn);
		s.setTotalDeduction(TotalDeduction);
		session.save(s);
		 idSal=s.getIdSalary();
		t.commit();
		
	
		
	}
	else if(count>0)
	{
		//idsalary, idEmployees, Month, Year, TotalEarning, TotalDeduction, NetSalary
		Criteria cra=session.createCriteria(Salary.class);
		cra.add(Restrictions.eq("idEmployees", empid));
		cra.add(Restrictions.eq("month", month));
		cra.add(Restrictions.eq("year", year));
		
	
		Salary s= (Salary) cra.uniqueResult();
		
		s.setTotalEarning(totalEarn);
		s.setTotalDeduction(TotalDeduction);
		s.setNetSalary(NetPay);

		session.update(s);
		t.commit();
		
		 idSal=s.getIdSalary();
		 session.close();
		
	}
	Session session1 = (Session) hipernateConfg.getSession();
	
	if(idSal==0)
	{
	Criteria cra=session1.createCriteria(Salary.class);
	cra.add(Restrictions.eq("idEmployees", empid));
	cra.add(Restrictions.eq("month", month));
	cra.add(Restrictions.eq("year", year));
	Projection r2=Projections.property("idSalary");
	cra.setProjection(r2);
	idSal=(int) cra.uniqueResult();
	}
	
	 SalaryEarning se=new SalaryEarning();

		for (Map.Entry<String, Float> entry : TotalEarning.entrySet()) 
		{
			 String Key = entry.getKey(); 
			 float Value = entry.getValue();
			 Session session2 = (Session) hipernateConfg.getSession();
			 Transaction t2 = session2.beginTransaction();
			 System.err.println("idSalary in erning loop "+idSal+"\nkey"+Key+"\n value"+Value);
			Criteria r=session2.createCriteria(SalaryEarning.class);
				r.add(Restrictions.eq("earningType", Key));
				r.add(Restrictions.eq("idSalary", idSal));
				Projection ps=Projections.rowCount();
				r.setProjection(ps);
				long rowcount=(long) r.uniqueResult();
			
			if(rowcount==0)
			{
				
			 se.setIdSalary(idSal);
			  se.setEarningType(Key);
			  se.setEarningAmount(Value);
	
			  session2.save(se);

			  t2.commit();
			  session2.clear();
			}
			else if(rowcount>0)
			{
				 se.setIdSalary(idSal);
				  se.setEarningType(Key);
				  se.setEarningAmount(Value);
					
				  session2.update(se);
				  session2.clear();
			}
				
			session2.close();
			
		}	
		
		SalaryDeduction se1=new SalaryDeduction();
 
		
		for (Map.Entry<String, Float> entry1 : TotalDeductionsall.entrySet()) 
		{
			  String Key1 = entry1.getKey(); 
			  float Value1 = entry1.getValue();
				
			 Session session3 = (Session) hipernateConfg.getSession();
			  Transaction z1 = session3.beginTransaction();
			System.err.println("idSalary in erning loop "+idSal+"\nkey"+Key1+"\n value"+Value1);
			Criteria r=session3.createCriteria(SalaryDeduction.class);
			r.add(Restrictions.eq("deductionType", Key1));
			r.add(Restrictions.eq("idSalary", idSal));
			Projection ps=Projections.rowCount();
			r.setProjection(ps);
			long rowcount=(long) r.uniqueResult();

			if(rowcount==0)
			{
			 se1.setIdSalary(idSal);
			 se1.setDeductionType(Key1);
			 se1.setDeductionAmount(Value1);
		
			 session3.save(se1);
			z1.commit();
			session3.clear();
			}
			else if(rowcount>0)
			{
	
			 se1.setIdSalary(idSal);
			 se1.setDeductionType(Key1);
			 se1.setDeductionAmount(Value1);
			 
			 session3.update(se1);
		
			 session3.clear();
			}
		}

	return NetPay;
		
	}
	
	public float Welfare(String empcode,int month)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		float welfare=0.0f;
		
		Criteria cr=session.createCriteria(Employees.class);
		cr.add(Restrictions.eq("employeeCode", empcode));
		Projection p=Projections.property("idEmpType");
		cr.setProjection(p);
		int idEmptype=(int) cr.uniqueResult();
		
		List<Float> Amount=new ArrayList<Float>();
		
		Criteria c=session.createCriteria(Welfare.class);
		c.add(Restrictions.eq("idEmpType", idEmptype));
		c.add(Restrictions.eq("month", month));
		Projection pr=Projections.property("amount");
		c.setProjection(pr);
		Amount=c.list();
		if(Amount.size()>0)
		{
			welfare=Amount.get(0);
		}
		session.clear();
		return welfare;
		
	}
	
}
