package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="userroles")
public class UserRoles {
	@Id
	int idUserroles;
	String employeeCode;
	int idRoles;
	public int getIdUserroles() {
		return idUserroles;
	}
	public void setIdUserroles(int idUserroles) {
		this.idUserroles = idUserroles;
	}
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public int getIdRoles() {
		return idRoles;
	}
	public void setIdRoles(int idRoles) {
		this.idRoles = idRoles;
	}
	
	

}
