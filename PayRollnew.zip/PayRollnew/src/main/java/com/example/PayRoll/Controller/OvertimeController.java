package com.example.PayRoll.Controller;


import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.OvertimeDAO;
import com.example.PayRoll.Manager.OvertimeManager;
import com.example.PayRoll.POJO.Overtime;

@Component
@Controller
@RequestMapping("/Overtime")
public class OvertimeController 
{
	@Autowired
	OvertimeManager overman;
	@Autowired
	OvertimeDAO overdao;

	@GetMapping
	@ResponseBody
	@RequestMapping("/get")
	public Object get(@RequestParam("empcode")String empcode,@RequestParam("date")Date dt)
	{
		return overman.get(empcode,dt);
	}
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	@RequestMapping("/getall")
	public Object getall()
	{
		return overdao.getall();
	}
	@PostMapping("/Overtime_Report")
	@ResponseBody
	public List Overtime_Report(@RequestParam("Date")Date date)
	{
		return overdao.Overtime_Report(date);
	}
	@RequestMapping("/Monthly_Overtime_report")
	@GetMapping
	@ResponseBody
	public Object Monthly_Overtime_report(@RequestParam("Month")String Month,@RequestParam("year")String year)
	{
		
			return overdao.Monthly_Overtime_report(Month, year);
		
	}
	@RequestMapping("/yearly_Overtime_report")
	@GetMapping
	@ResponseBody
	public Object yearly_Overtime_report(@RequestParam("year")String year)
	{
		
		return overdao.yearly_Overtime_report(year);
		
	}
	@RequestMapping("/delete")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id")int id)
	{
		return overdao.delete(id); 
	}
	
}
