package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.ESIManager;
import com.example.PayRoll.POJO.ESI;



	@Controller
	@RequestMapping("ESI")
	
	public class ESIController
	{
		
		@Autowired
		ESIManager eSIManager;
		
		@RequestMapping("/save")
		@PostMapping
		@ResponseBody
		public String save(ESI esi)
		{
			
			return eSIManager.save(esi); 
		
		}
	
		@RequestMapping("/get")
		@PostMapping
		@ResponseBody
		public Object get()
		{
			
			return eSIManager.get();
			
		}
		

}
