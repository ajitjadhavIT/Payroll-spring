package com.example.PayRoll.DAO;
	import java.util.ArrayList;
	import java.util.HashMap;
	import java.util.List;
	import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
	import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.DeductionSetting;
import com.example.PayRoll.POJO.DeductionType;
import com.example.PayRoll.POJO.Deductions;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.GroupDeductions;

	@Component
	@Controller
	public class AllDeductionDAO {
		
		@Autowired
		HipernateConfg hipernateConfg;
		
		@Autowired
		BasicSalaryDAO bsDAO;
	
		public Map CalDeductions(int empid,float basic)
		{
			Session session = (Session) hipernateConfg.getSession();  
			Transaction t = session.beginTransaction();
		
			 float totaldeduction=0.0f;
			 		 
		 Map m= new HashMap();
			 
			List iddeductions= new ArrayList();
	
			
			Criteria cr = session.createCriteria(Employees.class);
			
			cr.add(Restrictions.eq("idEmployees", empid));
			
			  Projection projection1 = Projections.property("idEmpType"); 
		     ProjectionList pList = Projections.projectionList();
		     pList.add(projection1);
		
		     cr.setProjection(pList);
		     int emptype=(int) cr.uniqueResult();
			
			
			
			
			Query query1=session.createQuery("select distinct(idDeductions) from GroupDeductions where idEmpType = :emptype");
			query1.setParameter("emptype", emptype);
			iddeductions=query1.list();
			
			
			float basicsal=basic;
	System.err.println("basic"+basicsal);
			for(int i=0;i<iddeductions.size();i++)
			{
				 int idDeductions=(int)iddeductions.get(i);
				 float deduction=0.0f;
				
				 System.err.println("idded  "+idDeductions);
				 Query query2=session.createQuery("select a.name, b.condition1,  b.minimum_condition, b.maximum_condition, b.idDeductionType, b.amount from Deductions a, DeductionSetting b where a.idDeductions = :idDeductions and a.idDeductions = b.idDeductions ");
				 query2.setParameter("idDeductions", idDeductions);
					List<Object[]> dedset=query2.list();
			
			
				//String sql2="select Condition1, Minimum_Condition, Maximum_Condition, idDeductionType, Amount from deductionsetting where idDeductions = ?";
				//dedset = jdbcTemplate.queryForMap(sql2,re.get(iddeductions));
				int iddedtype=0;
				
					   
						float min=(float) dedset.get(0)[2];
						float max=(float) dedset.get(0)[3];
					    int Con =(int) dedset.get(0)[1];
					    float amount=(float) dedset.get(0)[5];
						if(Con==0)
						{	
					
							iddedtype= (int) dedset.get(0)[4];
							
							
							Criteria cr1 = session.createCriteria(DeductionType.class);
							
							cr1.add(Restrictions.eq("idDeductionType", iddedtype));
							
							 
							  Projection projection2 = Projections.property("type"); 
						     ProjectionList List = Projections.projectionList();
					
						     List.add(projection2);
						   
						     cr1.setProjection(List);
						     String type=(String)cr1.uniqueResult();
							
							
						if(dedset.get(0)[0].equals("PF")&& basicsal>=max )
						{
							basicsal=max;
						}
							 if(type.equals("Percent"))
							{
								 
								 deduction= (basicsal/100)*amount;
								 
							}
							 if(type.equals("Amount"))
							{
								deduction=(float) dedset.get(0)[5];
								 
							}
		
						}
						
						else if(Con==1)
						{
							if(dedset.get(0)[0].equals("PF") && basicsal>=max )
							{
								basicsal=max;
							}
							iddedtype= (int) dedset.get(0)[4];
							
						
							Criteria cr1 = session.createCriteria(DeductionSetting.class);
							
							cr1.add(Restrictions.eq("idDeductions", idDeductions));
							
							 
							  Projection projection2 = Projections.property("minimum_condition"); 
							  Projection projection3 = Projections.property("maximum_condition");
							  Projection projection4 = Projections.property("idDeductionType");
							  Projection projection5 = Projections.property("amount");
						     ProjectionList List = Projections.projectionList();
					
						     List.add(projection2);
						     List.add(projection3);
						     List.add(projection4);
						     List.add(projection5);
						   
						     cr1.setProjection(List);
						     List<Object[]> conditions=cr1.list();
							
							Criteria cr2=session.createCriteria(DeductionType.class);
						cr2.add(Restrictions.eq("idDeductionType", iddedtype));
							Projection p=Projections.property("type");
							 ProjectionList List1 = Projections.projectionList();
								
						     List1.add(p);
							cr2.setProjection(List1);
							String type	=(String) cr2.uniqueResult();		
							
							
								float min1=(float) conditions.get(0)[0];
								float max1=(float) conditions.get(0)[1];
								float amount1=(float) conditions.get(0)[3];
								
								
								System.err.println("min"+min1);
								System.err.println("max1"+max1);
								System.err.println("amount1"+amount1);
							 if(basicsal >=min1 && basicsal<= max1)
							{
								
								 
								if(type.equals("Percent"))
								{     
									deduction= (basicsal/100)*amount1;
									System.err.println("pdeduction"+deduction);
								}
								
								else if(type.equals("Amount"))
									
								{
									  deduction=amount1;
										System.err.println("adeduction"+deduction);
								}
							}
						}
						totaldeduction += deduction;	
				
						m.put(dedset.get(0)[0], deduction);	
						}
				
				session.close();
					return m;
				}	
			
		
									
	
		
			
	
		public Map deductionAmount(String empcode,int Month,int year,String name)
		{
			Session session = (Session) hipernateConfg.getSession();  
		
			Criteria cr2=session.createCriteria(Employees.class);
			cr2.add(Restrictions.eq("employeeCode", empcode));
				Projection p=Projections.property("idSalarytype");
				 ProjectionList List1 = Projections.projectionList();
					
			     List1.add(p);
				cr2.setProjection(List1);
				int idSalaryType	=(int) cr2.uniqueResult();		
			
			float BasicSal=0.0f;
			if(idSalaryType==1)
			{
				BasicSal= bsDAO.DesignationSal(empcode,Month,year);
			}
			else if(idSalaryType==2)
			{
				BasicSal= bsDAO.PerDaySal(empcode,Month,year);
			}
			else if(idSalaryType==3)
			{
				BasicSal= bsDAO.MonthlySal(empcode,Month,year);
			}
			
			Map hm=new HashMap();
			 float basicsal=BasicSal;
			 float deduction=0.0f;
			 
			 System.err.println("basicsal="+basicsal);
			
			List<Object[]> m=new ArrayList<Object[]>();
		
			Criteria c=session.createCriteria(Employees.class);
			c.add(Restrictions.eq("employeeCode", empcode));
				Projection pr=Projections.property("idEmployees");
				Projection pr1=Projections.property("idEmpType");
	
				Projection pr3=Projections.property("emp_First_Name");
				Projection pr4=Projections.property("emp_Middle_Name");
				Projection pr5=Projections.property("emp_Last_Name");
				 ProjectionList Lis = Projections.projectionList();
					
				 Lis.add(pr);
				 Lis.add(pr1);
			
				 Lis.add(pr3);
				 Lis.add(pr4);
				 Lis.add(pr5);
				c.setProjection(Lis);
				m=c.list();
			
			 for(Object[] x:m)
			 {
				 int emptype=  (int) x[1];
			 List<Object[]> dedset = new ArrayList<Object[]>();
		
			Criteria cr=session.createCriteria(Deductions.class);
			cr.add(Restrictions.eq("name", name));
			Projection pt=Projections.property("idDeductions");
			cr.setProjection(pt);
			int idded=(int) cr.uniqueResult();
			
			Criteria cs=session.createCriteria(GroupDeductions.class);
			cs.add(Restrictions.eq("idEmpType", emptype));
			cs.add(Restrictions.eq("idDeductions", idded));
			Projection p1=Projections.rowCount();
			cs.setProjection(p1);
			 long count=(long) cs.uniqueResult();
		
			 if(count==1)
			 {
				Query query4 =session.createQuery("select a.name, b.condition,  b.minimum_condition, b.maximum_condition, b.idDeductionType, b.amount from Deductions a, DeductionSetting b where a.idDeductions = :idded and a.idDeductions = b.idDeductions ");
				query4.setParameter("idded", idded);
				dedset=query4.list();
			
				 
			for(Object[] row:dedset)
			{
		
			int iddedtype=0;
			
					float min=(float) row[2];
					float max=(float) row[3];
				    int Con =(int) row[1];
				    float amount=(float) row[5];
					if(Con==0)
					{	

						iddedtype=(int) row[4];
						Criteria cr0=session.createCriteria(DeductionType.class);
						cr0.add(Restrictions.eq("idDeductionType", iddedtype));
							Projection p0=Projections.property("type");
							 ProjectionList List10 = Projections.projectionList();
								
						     List10.add(p0);
							cr0.setProjection(List10);
							String type	=(String) cr0.uniqueResult();
					if(row[0].equals("PF")&& basicsal>=max )
					{
						basicsal=max;
					}
						 if(type.equals("Percent"))
						{
							 
							 deduction= (basicsal/100)*amount;
							 
						}
						 if(type.equals("Amount"))
						{
							deduction=(float) row[5];
							 
						}
					
					}
					
					else if(Con==1)
					{
						if(row[0].equals("PF") && basicsal>=max )
						{
							basicsal=max;
						}
						iddedtype= (int) row[4];
					
						Criteria cr1 = session.createCriteria(DeductionSetting.class);
						
						cr1.add(Restrictions.eq("idDeductions", idded));
						
						 
						  Projection projection2 = Projections.property("minimum_condition"); 
						  Projection projection3 = Projections.property("maximum_condition");
						  Projection projection4 = Projections.property("idDeductionType");
						  Projection projection5 = Projections.property("amount");
					     ProjectionList pList = Projections.projectionList();
				
					     pList.add(projection2);
					     pList.add(projection3);
					     pList.add(projection4);
					     pList.add(projection5);
					   
					     cr1.setProjection(pList);
					     List<Object[]> conditions=cr1.list();
					
						Criteria cr4=session.createCriteria(DeductionType.class);
						cr4.add(Restrictions.eq("idDeductionType", iddedtype));
							Projection p4=Projections.property("type");
							 ProjectionList List4 = Projections.projectionList();
								
						     List4.add(p4);
							cr4.setProjection(List4);
							String type	=(String) cr4.uniqueResult();		
						for(Object[] rs:conditions)
						{
							float min1=(float) rs[0];
							float max1=(float) rs[1];
							float amount1=(float) rs[3];
						 if(basicsal >=min1 && basicsal<= max1)
						{
						
							if(type.equals("Percent"))
							{     deduction= (basicsal/100)*amount1;}
							else if(type.equals("Amount"))
							{
								  deduction=amount1;
							}
						}
						}
					}
			
					
				String name1=String.valueOf(x[2])+" "+String.valueOf(x[3])+" "+String.valueOf(x[4]);
			
				hm.put("EmpCode",empcode);
				hm.put("Deduction Amount",deduction);
				hm.put("Employee name", name1);
				hm.put("Basic Salary", basicsal);
				
				
			}	
			
				
		}
			
	 }
			return hm;
			 
	}
		
		
		
	}

	
	


