package com.example.PayRoll.Controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


import com.example.PayRoll.DAO.WagesDayFilterDAO;
import com.example.PayRoll.POJO.Overtimebetdates;
import com.example.PayRoll.POJO.TaxDedReportFilter;
import com.example.PayRoll.POJO.WagesDayFilter;
import com.example.PayRoll.POJO.overtimebetmonth;
import com.example.PayRoll.POJO.overtimedayreport;

@Component
@Controller
@RequestMapping("/WagesDayfilter")
public class WageDayfilterController {

	@Autowired
	WagesDayFilterDAO attddao;

	@CrossOrigin()
	@RequestMapping("/wagesDay")
	@GetMapping
	@ResponseBody
	public WagesDayFilter grouA(@RequestParam("date")String date,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		
		System.err.println("empcode "+Employee_Code+"\ndate from ui = "+date);
		System.err.println("Date provided are = "+date+" group "+Group+" dept "+Department+" Catagory "+Catagory
				+" Designation "+Designation+" Shift "+Shift+" Employee_Code "+Employee_Code);
		WagesDayFilter wf=attddao.Wagesdayreport(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
		System.err.println("Leave data "+wf.getLeaveDay());
		System.err.println("empcode "+Employee_Code+"\ndate from ui = "+date);
		System.err.println("Date provided are = "+date+" group "+Group+" dept "+Department+" Catagory "+Catagory
				+" Designation "+Designation+" Shift "+Shift+" Employee_Code "+Employee_Code);
		return wf;//attddao.Wagesdayreport(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//wages present between dates
	@RequestMapping("/wagesbetDates")
	@GetMapping
	@ResponseBody
	public Object WagesPresentbetDate(@RequestParam("strtdate")Date fdate,@RequestParam("endtdate")Date ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.WagesPresentbetDate(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/wages")
	@GetMapping
	@ResponseBody
	//String design,String dept,String catagory,String empcode
	public Object wagesbetD(@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.commonDesignation(Designation, Department, Catagory, Employee_Code);
	}
	//TotalSalarybetDays
	@RequestMapping("/wagesbetD")
	@GetMapping
	@ResponseBody
	public Object wagesb(@RequestParam("strtdate")Date fdate,@RequestParam("endtdate")Date ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.TotalSalarybetDays(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//WagesleavebetDate
	@RequestMapping("/wagesleavesbetDates")
	@GetMapping
	@ResponseBody
	public Object WagesleavebetDate(@RequestParam("strtdate")Date fdate,@RequestParam("endtdate")Date ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.WagesleavebetDate(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//WagesTotalSalaryReportbetDates
	
	@RequestMapping("/WagesTotalSalaryReportbetDates")
	@GetMapping
	@ResponseBody
	public Object WagesTotalSalaryReportbetDates(@RequestParam("strtdate")Date fdate,@RequestParam("endtdate")Date ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.WagesTotalSalaryReportbetDates(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//Wagesdatebetweenreport**********first report finl1
	@RequestMapping("/WagesSalaryReportbetDates")//(******************************************
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public Object WagesSalaryReportbetDates(@RequestParam("strtdate")String fdate,@RequestParam("endtdate")String ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.Wagesdatebetweenreport(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//WagesTotalSalaryReportbetmonths
	
	@RequestMapping("/Wagesbetmonth")//(******************************************
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Object Totalsalfilterreport(@RequestParam("strtdate")String fdate,@RequestParam("endtdate")String ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.Totalsalfilterreport(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	
	//SalaryReports
	
	@RequestMapping("/SalaryReportfilter")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Object SalaryReport(@RequestParam("date")String date,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.SalaryReportfilter1(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//presentbonusfilter
	@RequestMapping("/bonusfilter")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Object presentbonusfilter(@RequestParam("date")String date,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.bonusfilter(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	
	//TaxBetmonthsReportfilter
	
	
	@RequestMapping("/TaxDedReportFilter1")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public TaxDedReportFilter TaxDedReportFilter1
	(@RequestParam("strtdate")String fdate,@RequestParam("endtdate")String ldate,
			@RequestParam("group")String Group,@RequestParam("Department")String Department,
			@RequestParam("Catagory")String Catagory,@RequestParam("Designation")String Designation,
			@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) 
					throws ParseException
	{
		TaxDedReportFilter tdrf = attddao.TaxDedReportFilter1(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
		System.err.println("data  fetched = "+tdrf);
		System.err.println("Date provided are = "+fdate+" ldate "+ldate+" group "+Group+" dept "+Department+" Catagory "+Catagory
				+" Designation "+Designation+" Shift "+Shift+" Employee_Code "+Employee_Code);
		return tdrf;
		
	}
	//TaxDedReportFilter1
	
	//otherDedBetMonthFilter1
	@RequestMapping("/otherDedBetMonthFilter1")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Object otherDedBetMonthFilter1(@RequestParam("strtdate")String fdate,@RequestParam("endtdate")String ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.otherDedBetMonthFilter1(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/incentiveFilter1")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Object incentiveFilter1(@RequestParam("strtdate")String fdate,@RequestParam("endtdate")String ldate,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.incentiveFilter1(fdate,ldate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	
	//incentiveFilter1
	

	//overtimeSalaryReport
	@RequestMapping("/overtimedayReport")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Object overtimedayReport(@RequestParam("date")String date,@RequestParam("group")String Group,@RequestParam("Department")String Department,@RequestParam("Catagory")String Catagory
			,@RequestParam("Designation")String Designation,@RequestParam("Shift")String Shift,@RequestParam("Employee_Code")String Employee_Code) throws ParseException
	{
		return attddao.overtimedayReport(date, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	@RequestMapping("/overtimebetdatesReport")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public Overtimebetdates overtimebetdatesReport(String Strtdate,String enddate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attddao.overtimebetdatesReport(Strtdate, enddate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	//totalovertimebetmonthReport
	
	@RequestMapping("/totalovertimebetmonthReport")
	@GetMapping 
	@CrossOrigin()
	@ResponseBody
	public overtimebetmonth totalovertimebetmonthReport(String Strtdate,String enddate,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	{
		return attddao.totalovertimebetmonthReport(Strtdate, enddate, Group, Department, Catagory, Designation, Shift, Employee_Code);
	}
	
}
