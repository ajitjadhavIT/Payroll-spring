package com.example.PayRoll.DAO;

import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Shift;

@Component
@Controller
public class ShiftDAO 
{	
	@Autowired
	HipernateConfg hipernateConfg;
	
	public Shift save(int id,String name,String start,String end,float allownce) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
	
		Shift s=new Shift();
		s.setIdShift(id);
		s.setName(name);
		s.setStartTime(Time.valueOf(start));
		s.setEndTime(Time.valueOf(end));
		s.setAllownce(allownce);
		session.saveOrUpdate(s);
		t.commit();  
		session.close();
		
		return s;
	}

	public Object get(String name)
	{
		System.err.println(name);
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		TblLeave e1=new TblLeave();
		e1 = (TblLeave)session.createCriteria(TblLeave.class,name);
		t.commit();
		session.close(); 
		
		return e1;
	}


	public Shift getname(String name)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Shift e1=new Shift();
		
		Criteria cr=session.createCriteria(Shift.class);
		cr.add(Restrictions.eq("name", name));
		
	
		return (Shift) cr.uniqueResult();
		
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession(); 
		Criteria cr=session.createCriteria(Shift.class);
		
		return cr.list();
	}

	public Object delete(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Shift d = (Shift ) session.createCriteria(Shift.class)
                 .add(Restrictions.eq("name", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
	
}
