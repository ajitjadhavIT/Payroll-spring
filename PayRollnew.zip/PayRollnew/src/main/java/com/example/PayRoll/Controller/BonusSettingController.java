package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.BonusSettingManager;
import com.example.PayRoll.POJO.BonusSetting;

@Controller
@RequestMapping("/BonusSetting")
public class BonusSettingController {

	@Autowired
	BonusSettingManager bsManager;
	
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public BonusSetting save(@RequestBody BonusSetting bs)
	{
		return bsManager.save(bs);
	}
	
	@RequestMapping("/get")
	@PostMapping
	@ResponseBody
	public Object get(@RequestParam("condition") float con)
	{
		return bsManager.get(con);
	}
	
	@RequestMapping("/delete")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object delete(@RequestParam("id") int id)
	{
		return bsManager.delete(id);
	}
	
	@RequestMapping("/getall")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public List getall()
	{
		return bsManager.getall();
	}
	
}
