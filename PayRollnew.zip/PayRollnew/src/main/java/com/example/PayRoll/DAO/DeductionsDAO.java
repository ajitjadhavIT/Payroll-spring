package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import org.hibernate.query.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Deductions;
import com.example.PayRoll.POJO.LateDeduction;


@Controller
@Component
public class DeductionsDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	
	public Deductions save(int id, String name)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Deductions d=new Deductions();
		d.setIdDeductions(id);
		d.setName(name);
		session.saveOrUpdate(d);
		t.commit();  
		session.close();
		return d;
		
				
	}
	
			public List getAll() 
		{
				Session session = (Session) hipernateConfg.getSession();  
				Transaction t = session.beginTransaction();
				//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(Deductions.class);
				return  cr.list();
		}
	
	public Object get(String name)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		Criteria cr=session.createCriteria(Deductions.class);
		cr.add(Restrictions.eq("name", name));
		Projection pr=Projections.property("idDeductions");
		cr.setProjection(pr);
		return cr.uniqueResult();
	}

	public Object delete(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Deductions d = (Deductions ) session.createCriteria(Deductions.class)
                 .add(Restrictions.eq("name", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
