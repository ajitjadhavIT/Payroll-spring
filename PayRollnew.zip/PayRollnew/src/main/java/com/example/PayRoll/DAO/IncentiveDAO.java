package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Incentive;

@Component
@Controller
public class IncentiveDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	public Incentive save(Incentive inc) 
	{	
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		session.saveOrUpdate(inc);
		t.commit();  
		session.close();
		
		return inc;
		
	}

	public Incentive get(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Incentive.class);
		cr.add(Restrictions.eq("incentive_type", name));//idIncentive, incentive_Type, idEmpType
		return (Incentive) cr.uniqueResult();


	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Incentive.class);
		return  cr.list();

	}

}
