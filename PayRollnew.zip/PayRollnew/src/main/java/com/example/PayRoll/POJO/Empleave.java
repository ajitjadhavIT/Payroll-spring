package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employee_leave")
public class Empleave 
{//idEmployee_leave, idEmployees, Date, idLeave
	@Id
	int idEmployee_leave;
	int idEmployees;
	Date date;
	int idLeave;
	int idShift;
	
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public int getidEmployee_leave() {
		return idEmployee_leave;
	}
	public void setidEmployee_leave(int idEmployee_leave) {
		this.idEmployee_leave = idEmployee_leave;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getIdleave() {
		return idLeave;
	}
	public void setIdleave(int idleave) {
		this.idLeave = idleave;
	}
	@Override
	public String toString() {
		return "Empleave [idEmployee_leave=" + idEmployee_leave + ", idEmployees=" + idEmployees + ", date=" + date
				+ ", idleave=" + idLeave + ", idShift=" + idShift + "]";
	}
	
}
