package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="salarytype")
public class Salarytype 
{
	@Id
	int idSalarytype;
	String name;
	public int getIdSalarytype() {
		return idSalarytype;
	}
	public void setIdSalarytype(int idSalarytype) {
		this.idSalarytype = idSalarytype;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
