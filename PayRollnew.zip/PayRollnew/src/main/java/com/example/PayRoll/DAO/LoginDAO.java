package com.example.PayRoll.DAO;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.Controller.OtpController;
import com.example.PayRoll.POJO.Login;
import com.example.PayRoll.POJO.Roles;
import com.example.PayRoll.POJO.UserRoles;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;
@SuppressWarnings("restriction")
@Component
@Controller
public class LoginDAO {
	 private static final String ALGORITHM = "AES";
	    private static final String KEY = "1Hbfh667adfDEJ78";
	    
	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired
	OtpController otpcontroller;
	public Object login(String username, String usrpassword) throws Exception 
	{
		Session session = (Session) hipernateConfg.getSession();  
		List<Object[]> usrnamepass=new ArrayList<Object[]>();
		Criteria cr=session.createCriteria(Login.class);
		Projection pr=Projections.property("username");
		Projection pr1=Projections.property("password");
		
		ProjectionList pl=Projections.projectionList();
		pl.add(pr);
		pl.add(pr1);
		
		cr.setProjection(pl);
		usrnamepass=cr.list();
		
		List<String> allusr=new ArrayList<String>();
	
	   
	    String usr = "";
		String password ="";
	
	
		HashMap<String,String> pass = new HashMap<String,String>();
		
		for(Object[] row: usrnamepass)
		{
			String usrname = (String) row[0];
			
			allusr.add((String) usrname);			
			pass.put(String.valueOf(usrname), String.valueOf(row[1]));
			
		
		}
	
		for(int i = 0;i < allusr.size();i++ ) 
		{
			if(username.equals(allusr.get(i)))
			{
				List roles=new ArrayList();
				usr = allusr.get(i);
				System.err.println("username = "+usr);
				password = pass.get(String.valueOf(usr));
				
				 String decryptedPassword = LoginDAO.decrypt(password); 
				System.err.println("decryptedPassword = "+decryptedPassword);
				System.err.println("password = "+password);
				if(usrpassword.equals(decryptedPassword) )
				{
					
					Criteria dc=session.createCriteria(Login.class);
					dc.add(Restrictions.eq("username", username));
					Projection ps=Projections.property("employeeCode");
					dc.setProjection(ps);
					String empcode=(String) dc.uniqueResult();
					
					
					Criteria czr=session.createCriteria(UserRoles.class);
					czr.add(Restrictions.eq("employeeCode", empcode));
					Projection pzr=Projections.property("idRoles");
					czr.setProjection(pzr);
					roles=czr.list();
					Map abc=new HashMap();
					int otp=0;
					List rolesname=new ArrayList();
					otp=otpcontroller.generateOtp();
//					for(int j=0;j<roles.size();j++)
//					{
//						System.err.println("role = "+roles.get(j));
//						Criteria dx=session.createCriteria(Roles.class);
//						dx.add(Restrictions.eq("idRoles", roles.get(j)));
//						Projection pt=Projections.property("role");
//						dx.setProjection(pt);
//						
//						String name=(String) dx.uniqueResult();
//						rolesname.add(name);
//		
//					}
					//abc.put("otp", otp);
					
					return otp;
					
				}

				
			}
			
			
		}
		
		return null;
	}
	public Object createlogin(int id,String username, String password,String empcode) throws Exception {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		 String encryptedPassword = LoginDAO.encrypt(password);
		 System.err.println(" encryptedPassword  "+encryptedPassword);
		Login s=new Login();
		s.setIdLogin(id);
		s.setPassword(encryptedPassword);
		s.setUsername(username);
		s.setEmployeeCode(empcode);
		session.saveOrUpdate(s);
		t.commit();
		session.close();
		
		return s;
	}
	
	 public static String encrypt(String value) throws Exception
	    {
	        Key key = generateKey();
	        Cipher cipher = Cipher.getInstance(LoginDAO.ALGORITHM);
	        cipher.init(Cipher.ENCRYPT_MODE, key);
	        byte [] encryptedByteValue = cipher.doFinal(value.getBytes("utf-8"));
	        String encryptedValue64 = new BASE64Encoder().encode(encryptedByteValue);
	        return encryptedValue64;
	               
	    }
	    
	    public static String decrypt(String value) throws Exception
	    {
	        Key key = generateKey();
	        Cipher cipher = Cipher.getInstance(LoginDAO.ALGORITHM);
	        cipher.init(Cipher.DECRYPT_MODE, key);
	        byte [] decryptedValue64 = new BASE64Decoder().decodeBuffer(value);
	        byte [] decryptedByteValue = cipher.doFinal(decryptedValue64);
	        String decryptedValue = new String(decryptedByteValue,"utf-8");
	        return decryptedValue;
	                
	    }
	    private static Key generateKey() throws Exception 
	    {
	        Key key = new SecretKeySpec(LoginDAO.KEY.getBytes(),LoginDAO.ALGORITHM);
	        return key;
	    }

}
