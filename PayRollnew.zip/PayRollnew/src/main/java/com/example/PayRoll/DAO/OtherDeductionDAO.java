package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.OtherDeduction;
import com.example.PayRoll.POJO.OtherDeductiontype;
@Controller
@Component
public class OtherDeductionDAO {
	
	@Autowired
	HipernateConfg hipernateConfg;
	
	public double AllDeduction(String empcode, int month, int year) {
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month-1;
		int enterdYear=year;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd1 = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

		int year1 = calendar.get(Calendar.YEAR);
		int month1 = calendar.get(Calendar.MONTH);
		
		System.err.println(fd1+"\n"+ld1);
		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		System.err.println(daysInMonth);
		
		
		Query a =session.createQuery("SELECT idEmployees FROM Employees where EmployeeCode = :empcode");
		a.setParameter("empcode", empcode);
		int eid=(int) a.uniqueResult();
		double TotalDeductionAmount=0.0d;
		try {
		
		Query v = session.createQuery("SELECT sum(Amount) FROM OtherDeduction where idEmployees = :eid and Month = :month and Year = :year");
		v.setParameter("eid", eid);
		v.setParameter("month", month);
		v.setParameter("year", year);
		TotalDeductionAmount=  (double) v.uniqueResult();
		
		}
		catch(NullPointerException ex)
		{
			TotalDeductionAmount=0.0f;
		}
	
		session.close();
		return TotalDeductionAmount;
	}
	

	public Map OtherDeductions(String empcode,int month,int year) {
		//abcd
		Session session = (Session) hipernateConfg.getSession();  
		
		int enterdmonth =month-1;
		int enterdYear=year;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,enterdmonth,day);  
       
        Date fd1 = calendar.getTime();
        calendar.add(Calendar.MONTH, 1);  
        calendar.set(Calendar.DAY_OF_MONTH, 1);  
        calendar.add(Calendar.DATE, -1);
        Date ld1 = calendar.getTime();

		int year1 = calendar.get(Calendar.YEAR);
		int month1 = calendar.get(Calendar.MONTH);
		
		System.err.println(fd1+"\n"+ld1);
		int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

		
		List ids=new ArrayList();
		
		
		 Criteria ct=session.createCriteria(Employees.class);
		 ct.add(Restrictions.eq("employeeCode", empcode));
		 Projection p=Projections.property("idEmployees");
		 ct.setProjection(p);
		 
		 int eid=(int) ct.uniqueResult();
		
		 Criteria c=session.createCriteria(OtherDeductiontype.class);
		 Projection pr=Projections.property("idOtherDeductionType");
		 c.setProjection(pr);
		 
		ids=c.list();
		
		Map<String,Object> values= new HashMap<String,Object>();
		for (int i=0;i<ids.size();i++)
		{
			float Amount=0.0f;
		try 
		{
		int idded=(int) ids.get(i);	
		Criteria cd=session.createCriteria(OtherDeduction.class);
		cd.add(Restrictions.eq("idOtherDeductionType", idded));
		cd.add(Restrictions.eq("idEmployees", eid));
		cd.add(Restrictions.eq("month", month));
		cd.add(Restrictions.eq("year", year));
		Projection pn=Projections.property("amount");
		cd.setProjection(pn);
		Amount =(float) cd.uniqueResult();
		
		}
		catch(Exception ex)
		{
			Amount=0.0f;
		}
		int idded=(int) ids.get(i);
		
		
		 Criteria ca=session.createCriteria(OtherDeductiontype.class);
		 ca.add(Restrictions.eq("idOtherDeductionType", idded));
		 Projection pra=Projections.property("name");
		 ca.setProjection(pra);
		 
			String DeductionName=(String) ca.uniqueResult();
		
		values.put(DeductionName, Amount);
		
		}
		
		session.close();
		
		return values;
	}
	
	
	
}
