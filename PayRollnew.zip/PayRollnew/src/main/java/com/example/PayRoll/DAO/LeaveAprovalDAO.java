package com.example.PayRoll.DAO;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.LeaveAproval;
@Component
public class LeaveAprovalDAO {
	@Autowired
	HipernateConfg hipernateConfg;
	

	public LeaveAproval save(LeaveAproval la) {
	
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		session.saveOrUpdate(la);
		t.commit();  
		session.close();
		
		return la;
		
	}

	public List getall()
	{
		Session session = (Session) hipernateConfg.getSession();  

		Criteria cr=session.createCriteria(LeaveAproval.class);
		return cr.list();
	}
	
}
