package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import org.hibernate.query.Query;

import java.util.List;
import java.util.Map;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import com.example.PayRoll.POJO.WageSheet;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.Bankdetails;
import com.example.PayRoll.POJO.Bonus;
import com.example.PayRoll.POJO.BonusSetting;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Emptype;
import com.example.PayRoll.POJO.EnglishNumberToWords;
import com.example.PayRoll.POJO.Salary;
import com.example.PayRoll.POJO.SalaryDeduction;
import com.example.PayRoll.POJO.SalaryDetails;
import com.example.PayRoll.POJO.SalaryEarning;
import com.example.PayRoll.POJO.SalarySlip;
import com.example.PayRoll.POJO.Salaryreport;
import com.example.PayRoll.POJO.Shift;
import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.Manager.BasicSalaryManager;
@Controller
@Component
public class ReportDAO {
	
	
	
	@Autowired
	OtherDeductionDAO ODdao;
	@Autowired
	AllDeductionDAO ADdao;
	@Autowired
	BasicSalaryDAO bsDAO;
	@Autowired
	HipernateConfg hipernateConfg;
	
	
	@Autowired
	BasicSalaryManager BSmanager;
	
	
	@Autowired
	EnglishNumberToWords ENT;
	@Autowired
	EmployeeSalaryDAO ESdao;
	
	
	
	

	
	public List SalarySlip(String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		List<SalarySlip> SS=new ArrayList();
		List Empid=new ArrayList();
		
		
	Map TaxDeduction=new HashMap();
	Map OtherDeductions=new HashMap();

	Empid= bsDAO.Empid();

	List<Map<String,Object>> FinalTaxDeduction=new ArrayList<Map<String,Object>>();
	List<Map<String,Object>> FinalOtherDeduction=new ArrayList<Map<String,Object>>();
	for(int i=0;i<Empid.size();i++)
	{
		SalarySlip sal=new SalarySlip();
	
		Map Designation_Days=new HashMap();	
		
		int idemp= Integer.parseInt(String.valueOf(Empid.get(i)));
		
		Query z= session.createQuery("SELECT a.employeeCode,b.pF_NO FROM Employees a join Bankdetails b on a.idEmployees=b.idEmployees where a.idEmployees = :idemp");
		z.setParameter("idemp", idemp);
		List<Object[]> map1=z.list();
		
		if(!map1.isEmpty())
		{		
		String empcode=(String) map1.get(0)[0];
		String PF_No=(String) map1.get(0)[1];
		
		Designation_Days=bsDAO.DesigID_PresntDay(empcode, month, year);

		Criteria cr=session.createCriteria(EmpWorkDetails.class);
		cr.add(Restrictions.eq("idEmployees", idemp));
		Projection a=Projections.property("idDesignation");
		
	
		cr.setProjection(a);
		int idDesignation=(int) cr.uniqueResult();

		
		Map Info=new HashMap();
		Info=bsDAO.info(empcode);//Emp_id& Emp_Name
		int idEmployee=(int) Info.get("idEmployee");
		String EmpName=(String) Info.get("EmployeeName");
		
		
		float PaidSalLeavs=bsDAO.paidLeaveSal(empcode, month, year);
		float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
		
		float PageTotalBasicSal =+ BasicSalary;
		
		float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
		float PageTotalIncentive=+incentive;
		
		float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
		float PagetotalThirdShift=+ThirdShift;
	
		
		float totalEarn=BasicSalary+incentive+ThirdShift;
		float PagePagetotalEarn=+totalEarn;

		float pf=0.0f;
		float PagetotalPF=0.0f;
		float pt=0.0f;
		float Pagetotalpt=0.0f;
		float esi=0.0f;
		float Pagetotalesi=0.0f;
		float tds=0.0f;
		float Pagetotaltds=0.0f;
		float society=0.0f;
		float Pagetotalsociety=0.0f;
		float pageTotalNetPay=0.0f;
		
		TaxDeduction=ADdao.CalDeductions(idemp, BasicSalary);//TaxDeductions
		FinalTaxDeduction.add(TaxDeduction);

		if(TaxDeduction.containsKey("PF"))
		{
		pf=(float) TaxDeduction.get("PF");
		PagetotalPF=+pf;
		}
		if(TaxDeduction.containsKey("PT"))
		{
			
		 pt=(float) TaxDeduction.get("PT");
		Pagetotalpt=+pt;
		}
		if(TaxDeduction.containsKey("ESI"))
		{
		 esi=(float) TaxDeduction.get("ESI");
		Pagetotalesi=+esi;
		}
		if(TaxDeduction.containsKey("TDS"))
		{
		 tds=(float) TaxDeduction.get("TDS");
		Pagetotaltds=+tds;
		}
		if(TaxDeduction.containsKey("Society"))
		{
		society=(float) TaxDeduction.get("Society");
		Pagetotalsociety=+society;
		}
		float AllTaxDeductions=pf+pt+esi+tds+society;
		OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
		FinalOtherDeduction.add(OtherDeductions);
		float bus =(float) OtherDeductions.get("Bus Charge");
		float Pagetotalbus=+bus;
		
		float phone =(float) OtherDeductions.get("Phone Bills");
		float Pagetotalphone=+phone;
		
		float House =(float) OtherDeductions.get("House Rent");
		float PagetotalHouse=+House;
		
		float Loan =(float) OtherDeductions.get("Loan");
		float PagetotalLoan=+Loan;
		
		float Canteen =(float) OtherDeductions.get("canteen Deduction");
		float PagetotalCanteen=+Canteen;
		
		float Advance =(float) OtherDeductions.get("Advance");
		float PagetotalAdvance=+Advance;
		
		float Other =(float) OtherDeductions.get("Other");
		float PagetotalOther=+Other;
		float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
		
		double Alldeduction=ODdao.AllDeduction(empcode, month, year);
		
		double TotalDeduction=Alldeduction+AllTaxDeductions;
		double PageTotalDeduction=+TotalDeduction;
		
		int NetPay=(int) (totalEarn+LeavHRsal-TotalDeduction);
	
		
		String NetPayInWord=ENT.convert(Math.abs(NetPay));
		
		float PresentDays=bsDAO.PresentDays(empcode, month, year);//Present Days
		pageTotalNetPay=+NetPay;
		sal.setMonth(month);
		sal.setYear(year);
		sal.setEmpName(EmpName);
		sal.setEmpCode(empcode);
		sal.setBasic(BasicSalary);
		sal.setIncidence(ThirdShift);
		sal.setOther(Other);
		sal.setpF(pf);
		sal.setpT(pt);
		sal.seteSI(esi);
		sal.setAdvance(Advance);
		sal.setSociety(society);
		sal.setLoan(Loan);
		sal.setCanteen(Canteen);
		sal.setBusCharge(bus);
		sal.setHouseRent(House);
		sal.setPhoneBill(phone);
		sal.setlWS(LeavHRsal);
		sal.settDS(tds);
		sal.setTotalEarn(totalEarn);
		sal.setTotaldeduction(TotalDeduction);
		sal.setPayDays(PresentDays);
		sal.setDesigDays(Designation_Days);
		sal.setTotalpayable(NetPay);
		sal.setiNWordNetpay(NetPayInWord);
	
		SS.add(sal);
	 }
	}
	session.close();
		return SS;
	
	}
	public List WageSheet(String month1,String year1) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		List<WageSheet> WS=new ArrayList();
		List Empid=new ArrayList();
		
		

		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
	
		
		 
	Empid= bsDAO.Empid();
	

	List<Map<String,Object>> TotalDesignation_Days=new ArrayList<Map<String,Object>>();
	List<Map<String,Object>> FinalInfo=new ArrayList<Map<String,Object>>();
	List<Map<String,Object>> FinalTaxDeduction=new ArrayList<Map<String,Object>>();
	List<Map<String,Object>> FinalOtherDeduction=new ArrayList<Map<String,Object>>();
	
	 for (int i=0; i<Empid.size() ;i++) 
	 {
		 	WageSheet Wage=new WageSheet();
			Map Designation_Days=new HashMap();	
			
			int idemp=(int) Empid.get(i);
			
	
			Criteria cr1=session.createCriteria(Employees.class);
			cr1.add(Restrictions.eq("idEmployees", idemp));
			Projection p=Projections.property("employeeCode");
			cr1.setProjection(p);
			String empcode=(String) cr1.uniqueResult();
			
			
			Criteria cr=session.createCriteria(Bankdetails.class);
			cr.add(Restrictions.eq("idEmployees", idemp));
			Projection pf1=Projections.property("pF_NO");
			cr.setProjection(pf1);
			String PF_No=(String) cr.uniqueResult();
		
			Designation_Days=bsDAO.DesigID_PresntDay(empcode, month, year);
			
			
			Criteria cr11=session.createCriteria(EmpWorkDetails.class);
			cr11.add(Restrictions.eq("idEmployees", idemp));
			Projection a=Projections.property("idDesignation");
			
		
			cr11.setProjection(a);
			int idDesignation=(int) cr11.uniqueResult();
			//t1.Name,t1.idDepartment, t2.Name from Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
			
			Query x= session.createQuery("SELECT t1.name from Designation t1 join Department t2 on t1.idDepartment=t2.idDepartment where t1.idDesignation = :idDesignation");
			x.setParameter("idDesignation", idDesignation);
			String DeptName=(String) x.uniqueResult();
		
			Map Info=new HashMap();
			Info=bsDAO.info(empcode);//Emp_id& Emp_Name
			int idEmployee=(int) Info.get("idEmployee");
			String EmpName=(String) Info.get("EmployeeName");

			float PresentDays=bsDAO.PresentDays(empcode, month, year);//Present Days
			float PaidSalLeavs=bsDAO.paidLeaveSal(empcode, month, year);
			float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
			float PageTotalBasicSal =+ BasicSalary;
			
			float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
			float PageTotalIncentive=+incentive;
			
			float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
			float PagetotalThirdShift=+ThirdShift;
		
			
			float totalEarn=BasicSalary+incentive+ThirdShift;
			float PagePagetotalEarn=+totalEarn;
			
			
			float pf=0.0f;
			float PagetotalPF=0.0f;
			float pt=0.0f;
			float Pagetotalpt=0.0f;
			float esi=0.0f;
			float Pagetotalesi=0.0f;
			float tds=0.0f;
			float Pagetotaltds=0.0f;
			float society=0.0f;
			float Pagetotalsociety=0.0f;
			double pageTotalNetPay=0.0f;
			
			TaxDeduction=ADdao.CalDeductions((int)Empid.get(i), BasicSalary);//TaxDeductions
			FinalTaxDeduction.add(TaxDeduction);
			
			
			if(TaxDeduction.containsKey("PF"))
			{
			pf=(float) TaxDeduction.get("PF");
			PagetotalPF=+pf;
			}
			if(TaxDeduction.containsKey("PT"))
			{
				
			 pt=(float) TaxDeduction.get("PT");
			Pagetotalpt=+pt;
			}
			if(TaxDeduction.containsKey("ESI"))
			{
			 esi=(float) TaxDeduction.get("ESI");
			Pagetotalesi=+esi;
			}
			if(TaxDeduction.containsKey("TDS"))
			{
			 tds=(float) TaxDeduction.get("TDS");
			Pagetotaltds=+tds;
			}
			if(TaxDeduction.containsKey("Society"))
			{
			society=(float) TaxDeduction.get("Society");
			Pagetotalsociety=+society;
			}
			float AllTaxDeductions=pf+pt+esi+tds+society;
			OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
			FinalOtherDeduction.add(OtherDeductions);
			float bus =(float) OtherDeductions.get("Bus Charge");
			float Pagetotalbus=+bus;
			
			float phone =(float) OtherDeductions.get("Phone Bills");
			float Pagetotalphone=+phone;
			
			float House =(float) OtherDeductions.get("House Rent");
			float PagetotalHouse=+House;
			
			float Loan =(float) OtherDeductions.get("Loan");
			float PagetotalLoan=+Loan;
			
			float Canteen =(float) OtherDeductions.get("canteen Deduction");
			float PagetotalCanteen=+Canteen;
			
			float Advance =(float) OtherDeductions.get("Advance");
			float PagetotalAdvance=+Advance;
			
			float Other =(float) OtherDeductions.get("Other");
			float PagetotalOther=+Other;
			float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
			
			double Alldeduction=ODdao.AllDeduction(empcode, month, year);
			
			double TotalDeduction=Alldeduction+AllTaxDeductions;
			double PageTotalDeduction=+TotalDeduction;
			
			double NetPay=totalEarn+LeavHRsal-TotalDeduction;
			pageTotalNetPay=+NetPay;
		
			Wage.setEmpcode(empcode);
			Wage.setName(EmpName);
			Wage.setPresentdays(PresentDays);
			Wage.setBasic(BasicSalary);
			Wage.setIncentive(incentive);
			Wage.setShiftAllownce(ThirdShift);
			Wage.setTotalEarn(totalEarn);
			Wage.setpF(pf);
			Wage.setpT(pt);
			Wage.seteSI(esi);
			Wage.setAdvance(Advance);
			Wage.setSociety(society);
			Wage.setLoan(Loan);
			Wage.setPhonebill(phone);
			Wage.setCanteen(Canteen);
			Wage.setHouseRent(House);
			Wage.setBusCharge(bus);
			Wage.setlWP(PaidSalLeavs);
			Wage.settDS(tds);
			Wage.setOther(Other);
			Wage.setTotalDeduction(TotalDeduction);
			Wage.setNetPay(NetPay);
			Wage.setpF_no(PF_No);
			Wage.setDept(DeptName);
			Wage.setDes_PresDays(Designation_Days);
			WS.add(Wage);
			
			}
session.close();
			return WS;
			
	}
	
	public List WageSheet_Grp(String date,String grp)
	{
		Session session = (Session) hipernateConfg.getSession();  

		String start[]=date.split("-");
		int year=Integer.valueOf(start[0]);
		int month=Integer.valueOf(start[1]);

		List<WageSheet> WS=new ArrayList();
		//List<Map<String, Object>> AllMap = new ArrayList<Map<String, Object>>();
		List Empid=new ArrayList();
		System.err.println(month+"    "+year);
		//TreeMap<Integer, String> Empid = new TreeMap<Integer, String>();

		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
	
		List<Map<String,Object>> TotalDesignation_Days=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalInfo=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalTaxDeduction=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalOtherDeduction=new ArrayList<Map<String,Object>>();
		 List<Map<String,Object>> idEmp=new ArrayList<Map<String,Object>>();
		 Map FinlList=new HashMap();
		
		
		 Criteria s=session.createCriteria(Emptype.class);
		 s.add(Restrictions.eq("name", grp));
		 Projection pr=Projections.property("idEmpType");
		 s.setProjection(pr);
		 int idEmptype=(int) s.uniqueResult();
		 
		 Criteria ps=session.createCriteria(Employees.class);
		 ps.add(Restrictions.eq("idEmpType", idEmptype));
		 Projection pa=Projections.property("idEmployees");
		 ps.setProjection(pa);
		 Empid=ps.list();
		
		float totalBonus=0.0f;
		
		for (int i=0; i<Empid.size() ;i++) 
		{
		 
		 	WageSheet Wage=new WageSheet();
			Map Designation_Days=new HashMap();	
			int id=(int) Empid.get(i);

			Criteria cr1=session.createCriteria(Employees.class);
			cr1.add(Restrictions.eq("idEmployees", id));
			Projection p=Projections.property("employeeCode");
			cr1.setProjection(p);
			String empcode=(String) cr1.uniqueResult();
			
			
			Criteria cr=session.createCriteria(Bankdetails.class);
			cr.add(Restrictions.eq("idEmployees", id));
			Projection pf1=Projections.property("pF_NO");
			cr.setProjection(pf1);
			String PF_No=(String) cr.uniqueResult();
			String DeptName="";
			int idDesignation=0;
		try {
			Designation_Days=bsDAO.DesigID_PresntDay(empcode, month, year);
			Criteria cr11=session.createCriteria(EmpWorkDetails.class);
			cr11.add(Restrictions.eq("idEmployees", id));
			Projection a=Projections.property("idDesignation");
			
		
			cr11.setProjection(a);
			 idDesignation=(int) cr11.uniqueResult();
		
			
			Query sz = session.createQuery("SELECT b.name from Designation a join Department b on a.idDepartment=b.idDepartment where idDesignation = :idDesignation");
			sz.setParameter("idDesignation", idDesignation);
			 DeptName=(String) sz.uniqueResult();
		}
		catch(Exception e)
		{
			
		}
			Map Info=new HashMap();
			Info=bsDAO.info(empcode);//Emp_id& Emp_Name
			int idEmployee=(int) Info.get("idEmployee");
			String EmpName=(String) Info.get("EmployeeName");
		
			float PresentDays=bsDAO.PresentDays(empcode, month, year);//Present Days
			float PaidSalLeavs=bsDAO.paidLeaveSal(empcode, month, year);
			float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
			float PageTotalBasicSal =+ BasicSalary;
			
			float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
			float PageTotalIncentive=+incentive;
			
			float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
			float PagetotalThirdShift=+ThirdShift;
		
			
			float totalEarn=BasicSalary+incentive+ThirdShift;
			float PagePagetotalEarn=+totalEarn;
			
			
			float pf=0.0f;
			float PagetotalPF=0.0f;
			float pt=0.0f;
			float Pagetotalpt=0.0f;
			float esi=0.0f;
			float Pagetotalesi=0.0f;
			float tds=0.0f;
			float Pagetotaltds=0.0f;
			float society=0.0f;
			float Pagetotalsociety=0.0f;
			double pageTotalNetPay=0.0f;
			
			TaxDeduction=ADdao.CalDeductions((int)Empid.get(i), BasicSalary);//TaxDeductions
			FinalTaxDeduction.add(TaxDeduction);
			
			
			if(TaxDeduction.containsKey("PF"))
			{
			pf=(float) TaxDeduction.get("PF");
			PagetotalPF=+pf;
			}
			if(TaxDeduction.containsKey("PT"))
			{
				
			 pt=(float) TaxDeduction.get("PT");
			Pagetotalpt=+pt;
			}
			if(TaxDeduction.containsKey("ESI"))
			{
			 esi=(float) TaxDeduction.get("ESI");
			Pagetotalesi=+esi;
			}
			if(TaxDeduction.containsKey("TDS"))
			{
			 tds=(float) TaxDeduction.get("TDS");
			Pagetotaltds=+tds;
			}
			if(TaxDeduction.containsKey("Society"))
			{
			society=(float) TaxDeduction.get("Society");
			Pagetotalsociety=+society;
			}
			float AllTaxDeductions=pf+pt+esi+tds+society;
			OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
			FinalOtherDeduction.add(OtherDeductions);
			float bus =(float) OtherDeductions.get("Bus Charge");
			float Pagetotalbus=+bus;
			
			float phone =(float) OtherDeductions.get("Phone Bills");
			float Pagetotalphone=+phone;
			
			float House =(float) OtherDeductions.get("House Rent");
			float PagetotalHouse=+House;
			
			float Loan =(float) OtherDeductions.get("Loan");
			float PagetotalLoan=+Loan;
			
			float Canteen =(float) OtherDeductions.get("canteen Deduction");
			float PagetotalCanteen=+Canteen;
			
			float Advance =(float) OtherDeductions.get("Advance");
			float PagetotalAdvance=+Advance;
			
			float Other =(float) OtherDeductions.get("Other");
			float PagetotalOther=+Other;
			float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
			
			double Alldeduction=ODdao.AllDeduction(empcode, month, year);
			
			double TotalDeduction=Alldeduction+AllTaxDeductions;
			double PageTotalDeduction=+TotalDeduction;
			
			double NetPay=totalEarn+LeavHRsal-TotalDeduction;
			pageTotalNetPay=+NetPay;
			System.err.println(idEmployee+"\npresent days"+PresentDays);
			Wage.setEmpcode(empcode);
			Wage.setName(EmpName);
			Wage.setPresentdays(PresentDays);
			Wage.setBasic(BasicSalary);
			Wage.setIncentive(incentive);
			Wage.setShiftAllownce(ThirdShift);
			Wage.setTotalEarn(totalEarn);
			Wage.setpF(pf);
			Wage.setpT(pt);
			Wage.seteSI(esi);
			Wage.setAdvance(Advance);
			Wage.setSociety(society);
			Wage.setLoan(Loan);
			Wage.setPhonebill(phone);
			Wage.setCanteen(Canteen);
			Wage.setHouseRent(House);
			Wage.setBusCharge(bus);
			Wage.setlWP(PaidSalLeavs);
			Wage.settDS(tds);
			Wage.setOther(Other);
			Wage.setTotalDeduction(TotalDeduction);
			Wage.setNetPay(NetPay);
			Wage.setpF_no(PF_No);
			Wage.setDept(DeptName);
			Wage.setDes_PresDays(Designation_Days);
			WS.add(Wage);
			
			}
		session.close();
			return WS;
		
		
	}
	
	
	
	public List WageSheet_Dept(String month1,String dept,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		List<WageSheet> WS=new ArrayList();
		//List<Map<String, Object>> AllMap = new ArrayList<Map<String, Object>>();
		List Empid=new ArrayList();
		
		//TreeMap<Integer, String> Empid = new TreeMap<Integer, String>();

		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
	
		List<Map<String,Object>> TotalDesignation_Days=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalInfo=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalTaxDeduction=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalOtherDeduction=new ArrayList<Map<String,Object>>();
		 List<Map<String,Object>> idEmp=new ArrayList<Map<String,Object>>();
		 Map FinlList=new HashMap();
		 List idDess=new ArrayList();
			Criteria as=session.createCriteria(Department.class);
			as.add(Restrictions.eq("name", dept));
			Projection fd=Projections.property("idDepartment");
			as.setProjection(fd);
			int idDept=(int) as.uniqueResult();
			
			Criteria as1=session.createCriteria(Designation.class);
			as1.add(Restrictions.eq("idDepartment", idDept));
			Projection fd1=Projections.property("idDesignation");
			as1.setProjection(fd1);
			idDess= as1.list();
		
			float totalBonus=0.0f;
			
			Map DeptBonus=new HashMap();
			
			for(int j=0;j<idDess.size();j++)
			{
				List<Map<String,Object>> idemp=new ArrayList<Map<String,Object>>();
				int iddesi=(int) idDess.get(j);
			
			Criteria a1=session.createCriteria(Attendance.class);
			a1.add(Restrictions.eq("idDesignation", iddesi));
			Projection f=Projections.property("idEmployees");
			Projection b=Projections.distinct(f);
			a1.setProjection(b);
			Empid=a1.list();
				
				
				for (int i=0; i<Empid.size() ;i++) 
				{
					
				
			 	WageSheet Wage=new WageSheet();
				Map Designation_Days=new HashMap();	
				int idemployee=(int) Empid.get(i);

			 	Criteria cr1=session.createCriteria(Employees.class);
				cr1.add(Restrictions.eq("idEmployees", idemployee));
				Projection p1=Projections.property("employeeCode");
				cr1.setProjection(p1);
				String empcode=(String) cr1.uniqueResult();
				
				
				Criteria cr=session.createCriteria(Bankdetails.class);
				cr.add(Restrictions.eq("idEmployees", idemployee));
				Projection pf1=Projections.property("pF_NO");
				cr.setProjection(pf1);
				String PF_No=(String) cr.uniqueResult();
			 	
			 	
		
				Designation_Days=bsDAO.DesigID_PresntDay(empcode, month, year);
				Criteria cr5=session.createCriteria(EmpWorkDetails.class);
				cr5.add(Restrictions.eq("idEmployees", idemployee));
				Projection a=Projections.property("idDesignation");
				
			
				cr5.setProjection(a);
				int idDesignation=(int) cr5.uniqueResult();
				Query deptName = session.createQuery("SELECT a.name from Designation a join Department b on a.idDepartment=b.idDepartment where idDesignation = :idDesignation");
				deptName.setParameter("idDesignation", idDesignation);
				String DeptName=(String) deptName.uniqueResult();
			
				Map Info=new HashMap();
				Info=bsDAO.info(empcode);//Emp_id& Emp_Name
				int idEmployee=(int) Info.get("idEmployee");
				String EmpName=(String) Info.get("EmployeeName");
			
				float PresentDays=bsDAO.PresentDays(empcode, month, year);//Present Days
				float PaidSalLeavs=bsDAO.paidLeaveSal(empcode, month, year);
				float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
				float PageTotalBasicSal =+ BasicSalary;
				
				float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
				float PageTotalIncentive=+incentive;
				
				float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
				float PagetotalThirdShift=+ThirdShift;
			
				
				float totalEarn=BasicSalary+incentive+ThirdShift;
				float PagePagetotalEarn=+totalEarn;
				
				
				float pf=0.0f;
				float PagetotalPF=0.0f;
				float pt=0.0f;
				float Pagetotalpt=0.0f;
				float esi=0.0f;
				float Pagetotalesi=0.0f;
				float tds=0.0f;
				float Pagetotaltds=0.0f;
				float society=0.0f;
				float Pagetotalsociety=0.0f;
				double pageTotalNetPay=0.0f;
				
				TaxDeduction=ADdao.CalDeductions((int)Empid.get(i), BasicSalary);//TaxDeductions
				FinalTaxDeduction.add(TaxDeduction);
				
				
				if(TaxDeduction.containsKey("PF"))
				{
				pf=(float) TaxDeduction.get("PF");
				PagetotalPF=+pf;
				}
				if(TaxDeduction.containsKey("PT"))
				{
					
				 pt=(float) TaxDeduction.get("PT");
				Pagetotalpt=+pt;
				}
				if(TaxDeduction.containsKey("ESI"))
				{
				 esi=(float) TaxDeduction.get("ESI");
				Pagetotalesi=+esi;
				}
				if(TaxDeduction.containsKey("TDS"))
				{
				 tds=(float) TaxDeduction.get("TDS");
				Pagetotaltds=+tds;
				}
				if(TaxDeduction.containsKey("Society"))
				{
				society=(float) TaxDeduction.get("Society");
				Pagetotalsociety=+society;
				}
				float AllTaxDeductions=pf+pt+esi+tds+society;
				OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
				FinalOtherDeduction.add(OtherDeductions);
				float bus =(float) OtherDeductions.get("Bus Charge");
				float Pagetotalbus=+bus;
				
				float phone =(float) OtherDeductions.get("Phone Bills");
				float Pagetotalphone=+phone;
				
				float House =(float) OtherDeductions.get("House Rent");
				float PagetotalHouse=+House;
				
				float Loan =(float) OtherDeductions.get("Loan");
				float PagetotalLoan=+Loan;
				
				float Canteen =(float) OtherDeductions.get("canteen Deduction");
				float PagetotalCanteen=+Canteen;
				
				float Advance =(float) OtherDeductions.get("Advance");
				float PagetotalAdvance=+Advance;
				
				float Other =(float) OtherDeductions.get("Other");
				float PagetotalOther=+Other;
				float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
				
				double Alldeduction=ODdao.AllDeduction(empcode, month, year);
				
				double TotalDeduction=Alldeduction+AllTaxDeductions;
				double PageTotalDeduction=+TotalDeduction;
				
				double NetPay=totalEarn+LeavHRsal-TotalDeduction;
				pageTotalNetPay=+NetPay;
				
				Wage.setEmpcode(empcode);
				Wage.setName(EmpName);
				Wage.setPresentdays(PresentDays);
				Wage.setBasic(BasicSalary);
				Wage.setIncentive(incentive);
				Wage.setShiftAllownce(ThirdShift);
				Wage.setTotalEarn(totalEarn);
				Wage.setpF(pf);
				Wage.setpT(pt);
				Wage.seteSI(esi);
				Wage.setAdvance(Advance);
				Wage.setSociety(society);
				Wage.setLoan(Loan);
				Wage.setPhonebill(phone);
				Wage.setCanteen(Canteen);
				Wage.setHouseRent(House);
				Wage.setBusCharge(bus);
				Wage.setlWP(PaidSalLeavs);
				Wage.settDS(tds);
				Wage.setOther(Other);
				Wage.setTotalDeduction(TotalDeduction);
				Wage.setNetPay(NetPay);
				Wage.setpF_no(PF_No);
				Wage.setDept(DeptName);
				Wage.setDes_PresDays(Designation_Days);
				WS.add(Wage);
				
				}
			}
				return WS;
		
		
	}
	
	
	
	
	
	public List SalaryReports(String empcode,String date)
	{
		Session session = (Session) hipernateConfg.getSession();  
		String start[]=date.split("-");
		int year=Integer.valueOf(start[0]);
		int month=Integer.valueOf(start[1]);

		List abc=new ArrayList();
		SalaryDetails SalaryDetail=new SalaryDetails();
		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
		 
		List MainTablePerDay=new ArrayList();
		Map Designation_Days=new HashMap();
		
		float totalpresentdays=bsDAO.PresentDays(empcode, month, year);
		
		MainTablePerDay= ESdao.EmpSal(empcode, month, year);
		int Fworkingdays=0;
		int Fdesignation=0;
		try {
	
		Designation_Days=bsDAO.DesigID_PresntDay(empcode, month, year);
		 Fworkingdays=(int) Designation_Days.get("Presentdays");
		 Fdesignation=(int) Designation_Days.get("Designation");
		}
		catch(Exception e) {
			
		}
	Criteria cr1=session.createCriteria(Employees.class);
	cr1.add(Restrictions.eq("employeeCode", empcode));
	Projection p1=Projections.property("idEmployees");
	cr1.setProjection(p1);
	int empid=(int) cr1.uniqueResult();
		
		Map Info=new HashMap();
		Info=bsDAO.info(empcode);//Emp_id& Emp_Name
		String EmpName=(String) Info.get("EmployeeName");
	
		
		float PaidSalLeavs=bsDAO.paidLeaveSal(empcode, month, year);
		float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
	
		float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
	
		float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
		float mOvertime=bsDAO.Overtime(empcode, month, year);
	
		float totalEarn=BasicSalary+incentive+ThirdShift+mOvertime;

		float pf=0.0f;
	
		float pt=0.0f;
	
		float esi=0.0f;
	
		float tds=0.0f;
	
		float society=0.0f;

		float AllTaxDeductions=pf+pt+esi+tds+society;
	
		TaxDeduction=ADdao.CalDeductions((int) empid, BasicSalary);//TaxDeductions

	if(TaxDeduction.containsKey("PF"))
	{
		
	pf=(float) TaxDeduction.get("PF");

	}
	if(TaxDeduction.containsKey("PT"))
	{
		
	 pt=(float) TaxDeduction.get("PT");
	
	}
	if(TaxDeduction.containsKey("ESI"))
	{
	 esi=(float) TaxDeduction.get("ESI");
	
	}
	if(TaxDeduction.containsKey("TDS"))
	{
	 tds=(float) TaxDeduction.get("TDS");

	}
	if(TaxDeduction.containsKey("Society"))
	{
	society=(float) TaxDeduction.get("Society");
	
	}
	
	OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
	
	float bus =(float) OtherDeductions.get("Bus Charge");
	
	
	float phone =(float) OtherDeductions.get("Phone Bills");
	
	
	float House =(float) OtherDeductions.get("House Rent");
	
	
	float Loan =(float) OtherDeductions.get("Loan");
	
	
	float Canteen =(float) OtherDeductions.get("canteen Deduction");
	
	
	float Advance =(float) OtherDeductions.get("Advance");
	
	
	float Other =(float) OtherDeductions.get("Other");
	
	float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
	
	double Alldeduction=ODdao.AllDeduction(empcode, month, year);

	float welfare=ESdao.Welfare(empcode, month);
	
	double TotalDeduction=Alldeduction+AllTaxDeductions+welfare;
	
	double NetPay=totalEarn+LeavHRsal-TotalDeduction;
	
	SalaryDetail.setPerDayInfo(MainTablePerDay);
	SalaryDetail.setFdesignation(Fdesignation);
	SalaryDetail.setFworkingdays(Fworkingdays);
	SalaryDetail.setFBasic(BasicSalary);
	SalaryDetail.setIncentive(incentive);
	SalaryDetail.setFAllownce(ThirdShift);
	SalaryDetail.setFOvertime(mOvertime);
	SalaryDetail.setPF(pf);
	SalaryDetail.setPT(pt);
	SalaryDetail.setESI(esi);
	SalaryDetail.setTDS(tds);
	SalaryDetail.setWelfare(welfare);
	SalaryDetail.setSociety(society);
	SalaryDetail.setBusCharge(bus);
	SalaryDetail.setHouseRent(House);
	SalaryDetail.setPhoneBill(phone);
	SalaryDetail.setCanteenDeduction(Canteen);
	SalaryDetail.setAdvance(Advance);
	SalaryDetail.setLoan(Loan);
	SalaryDetail.setLWP(PaidSalLeavs);
	SalaryDetail.setFinalSalary(NetPay);
	SalaryDetail.setPresentDays(totalpresentdays);
	
	abc.add(SalaryDetail);
		return abc;
		
	}
	
	public List Bonus(String year) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		List<Object[]> months1=new ArrayList<Object[]>();

		Criteria cr=session.createCriteria(BonusSetting.class);
		Projection p0=Projections.property("startmonth");
		Projection p1=Projections.property("endmonth");
		Projection pa=Projections.distinct(p0);
		
		ProjectionList ps=Projections.projectionList();
		ps.add(pa);
		ps.add(p1);
		cr.setProjection(ps);
		months1=cr.list();

		int Month1 =(int) months1.get(0)[0];
		int Month2=(int) months1.get(0)[1];
	
		int day=1;
		String years[]=year.split("-");
		int year1=Integer.valueOf(years[0]);
	
		int year2=Integer.valueOf(years[1]);
		
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year1-1,Month1,day);  
        Date fd1 = calendar.getTime();
        day=calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        calendar.set(year2-1,Month2,day);  
        Date ld1 = calendar.getTime();

        List Empid=new ArrayList();
        List<Map<String,Object>> months=new ArrayList<Map<String,Object>>();
        List<Map<String,Object>> AllBonus=new ArrayList<Map<String,Object>>();
    	Empid= bsDAO.Empid();
    	int loop=12;
    session.close();
    		calendar.set(year1,Month1,day); 
    		 
    		for(int p=0;p<=loop;p++)
    		{
    			Map MandY=new HashMap();
    			int m = calendar.get(Calendar.MONTH);
    			int y = calendar.get(Calendar.YEAR);
    			MandY.put("Month", m);
    			MandY.put("Year", y);
    			months.add(MandY);
    			calendar.add(Calendar.MONTH,1);
    		}
    	 for (int j=0; j<Empid.size() ;j++) 
    	 {
    		 
    		 Session session1 = (Session) hipernateConfg.getSession();  
    		Transaction t1 = session1.beginTransaction();
    		int idemp= (int) Empid.get(j);

			Criteria b=session1.createCriteria(Employees.class);
			b.add(Restrictions.eq("idEmployees", idemp));
			Projection ad=Projections.property("employeeCode");
			b.setProjection(ad);
			String empcode=(String) b.uniqueResult();
			
    		Map Info=new HashMap();
    		List<Object[]> BonusSetting=new ArrayList<Object[]>();
    		Info=bsDAO.info(empcode);//Emp_id& Emp_Name
    		String EmpName=(String) Info.get("EmployeeName");
    
    		 Criteria cx=session1.createCriteria(BonusSetting.class);
    		 Projection ads=Projections.property("condition1");
    		 Projection adsa=Projections.property("percent");
    		 ProjectionList pl=Projections.projectionList();
    		 pl.add(ads);
    		 pl.add(adsa);
    		 cx.setProjection(pl);
    		 BonusSetting=cx.list();
    		 
    		List<Float> prescons=new ArrayList<Float>();
    		
    		float PresentDays=0.0f;
    	    float BasicSal=0.0f;
    	    Float Con = 0.0f;
			float percent =0.0f;
    	        
    		Map Bonus1=new HashMap();
    		float Bonus=0.0f;
    		for(int i=0;i<=loop;i++)
    	     { 
    			int monthx=(int) months.get(i).get("Month");
    			int yearx=(int) months.get(i).get("Year");
    System.err.println("\n empcode"+empcode+"\n month"+monthx+"\n year"+yearx);
    			PresentDays+=bsDAO.PresentDays(empcode, monthx, yearx);
 System.err.println("presentdays ="+PresentDays);
    			BasicSal+=BSmanager.basicsal(empcode, monthx, yearx);
    	     }
    		HashMap<String,String> per = new HashMap<String,String>();
    		int x=0;
    		for(Object[] row: BonusSetting)
    		{
    			float condition = (float) row[0];
    			prescons.add((float) condition);			
    			per.put(String.valueOf(condition), String.valueOf(row[1]));
    			
    			x++;
    		}
    		Collections.sort(prescons);
    		for(int i = 0;i < prescons.size();i++ ) 
    		{
    			if(PresentDays >= prescons.get(i))
    			{
    				Con = prescons.get(i);
    				
    				percent = Float.valueOf(per.get(String.valueOf(Con)) );
    			}
    			
    		}
    		
    			Bonus=(float) ((BasicSal/100)*percent);
		    	Bonus1.put("Bonus", Bonus);
		    	Bonus1.put("EmpCode", empcode);
		        Bonus1.put("Working Days", PresentDays);
		    	Bonus1.put("Basic Salary", BasicSal);
		    	Bonus1.put("EmployeeName", EmpName);
		    	Bonus1.put("Percent", percent);
    		
    		
    			Criteria ct=session1.createCriteria(Bonus.class);
    			ct.add(Restrictions.eq("idEmployees", idemp));
    			ct.add(Restrictions.eq("year", year));
    			Projection pr=Projections.rowCount();
    			ct.setProjection(pr);
    			long count=(long)ct.uniqueResult();
    			
    		 if(count==0)
    		 {
    			 System.err.println(year);
    			 Bonus bonus=new Bonus();
    			 bonus.setIdEmployees(idemp);
    			 bonus.setPresentDays(PresentDays);
    			 bonus.setYear(year);
    			 bonus.setBasicSal(BasicSal);
    			 bonus.setBonus(Bonus);
    			 session1.save(bonus);
    			 t1.commit();
    		
    		 }
    		
    		  else if(count>0)
    		 {
    			 Bonus bonus=new Bonus();
    			 
    			 Criteria c=session1.createCriteria(Bonus.class);
    			 c.add(Restrictions.eq("idEmployees", idemp));
    			 c.add(Restrictions.eq("year", year));
    			 Projection pks=Projections.property("idBonus");
    			 c.setProjection(pks);
    			 int idbonus=(int) c.uniqueResult();
    			 System.err.println("idbonus "+idbonus);
    			 bonus.setIdBonus(idbonus);
     			 bonus.setIdEmployees(idemp);
     			 bonus.setPresentDays(PresentDays);
     			 bonus.setYear(year);
     			 bonus.setBasicSal(BasicSal);
     			 bonus.setBonus(Bonus);
     			 session1.update(bonus);
     			 t1.commit();

    		 }
    		 AllBonus.add(Bonus1);
        	 session1.close();

    		 	}
    		
    		 
		return AllBonus;
      }
	
	
	public Map Bonus_by_GRP(String year,String grp)
	{
		Session session = (Session) hipernateConfg.getSession();  
		  List idEmp=new ArrayList();
		 Map FinlList=new HashMap();
		 Criteria s=session.createCriteria(Emptype.class);
		 s.add(Restrictions.eq("name", grp));
		 Projection pr=Projections.property("idEmpType");
		 s.setProjection(pr);
		 int idEmptype=(int) s.uniqueResult();
		 

		 
		 Criteria ps=session.createCriteria(Employees.class);
		 ps.add(Restrictions.eq("idEmpType", idEmptype));
		 Projection pa=Projections.property("idEmployees");
		 ps.setProjection(pa);
			idEmp=ps.list();
		float totalBonus=0.0f;
		for(int i=0;i<idEmp.size();i++)
		{
			int idemp= (int) idEmp.get(i);
			float bonus=0.0f;
			try {
				
			Criteria ca=session.createCriteria(Bonus.class);
			ca.add(Restrictions.eq("idEmployees", idemp));
			Projection pn=Projections.property("bonus");
			ca.setProjection(pn);
			 bonus=(float) ca.uniqueResult();

			 
			}
			catch(Exception e)
			{
				bonus=0.0f;
			}
			totalBonus=+bonus;
			
		}
		
		FinlList.put("Group", grp);
		FinlList.put("year", year);
		FinlList.put("Bonus", totalBonus);
		
		
		return FinlList;
		
	}
	
	
	
	
	
	
	public Map EmployeeInfo(String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Map info=new HashMap();
		Map EmployeeEnfo=new HashMap();
		info=bsDAO.info(empcode);
		Criteria a1=session.createCriteria(Employees.class);
		a1.add(Restrictions.eq("employeeCode", empcode));
		Projection f=Projections.property("idEmployees");
		Projection f1=Projections.property("idEmpType");
		Projection f2=Projections.property("address");
		Projection f3=Projections.property("contact_No");
		ProjectionList pl=Projections.projectionList();
		pl.add(f);
		pl.add(f1);
		pl.add(f2);
		pl.add(f3);
		a1.setProjection(pl);
		List<Object[]>Basic=a1.list();
	
		int idEmpType=(int) Basic.get(0)[1];
		
		String Address= (String) Basic.get(0)[2];
		
		long Contact_No=(long) Basic.get(0)[3];
		
		int idEmployees=(int)Basic.get(0)[0];
		

		
		
		Query b= session.createQuery("SELECT a.idDesignation,b.name,b.idDepartment FROM EmpWorkDetails a join Designation b on b.idDesignation= a.idDesignation where idEmployees = :idEmployees");
		b.setParameter("idEmployees", idEmployees);
		List<Object[]>list=b.list();


		
		int idDesignation=(int) list.get(0)[0];
		String DesigName=(String) list.get(0)[1];
		int idDept= (int) list.get(0)[2];

		 Criteria s=session.createCriteria(Emptype.class);
		 s.add(Restrictions.eq("idEmpType", idEmpType));
		 Projection pr=Projections.property("name");
		 s.setProjection(pr);
		 String Group=(String) s.uniqueResult();
		 Criteria s4=session.createCriteria(Department.class);
		 s4.add(Restrictions.eq("idDepartment", idDept));
		 Projection pr4=Projections.property("name");
		 s4.setProjection(pr4);
		 String DeptName=(String) s4.uniqueResult();

		EmployeeEnfo.put("Address", Address);
		EmployeeEnfo.put("Contact", Contact_No);
		EmployeeEnfo.put("Group", Group);
		EmployeeEnfo.putAll(info);
		EmployeeEnfo.put("Designation", DesigName);
		EmployeeEnfo.put("Department", DeptName);
		return EmployeeEnfo;
	}
	
	public List SalaryReportMonth(String Group,String Month1,String year1) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		  int Month=Integer.parseInt(Month1);
		  int year=Integer.parseInt(year1);
	      List idEmployees=new ArrayList();

		 Criteria s=session.createCriteria(Emptype.class);
		 s.add(Restrictions.eq("name", Group));
		 Projection pr=Projections.property("idEmpType");
		 s.setProjection(pr);
		 int idEmpType = (int)s.uniqueResult();

		Criteria a1=session.createCriteria(Employees.class);
		a1.add(Restrictions.eq("idEmpType", idEmpType));
		Projection f=Projections.property("idEmployees");
		Projection b=Projections.distinct(f);

		a1.setProjection(b);
		idEmployees=a1.list();
	
	      List<Map<String,Object>> Allinfo=new ArrayList<Map<String,Object>>();
	      for (int j=0; j<idEmployees.size() ;j++) 
	    	 {
	    		
	    		 Map Salreport=new HashMap();
	    		 int idemp= (int) idEmployees.get(j);
	    	
	    		Query q= session.createQuery("SELECT a.employeeCode, a.emp_First_Name,a.emp_Middle_Name,a.emp_Last_Name,b.bank_Name,b.account_Number,b.iFSC_Code,b.branch FROM Employees a join Bankdetails b on a.idEmployees=b.idEmployees where a.idEmployees = :idemp");
	    	    q.setParameter("idemp", idemp);      
	    		List<Object[]> m=q.list();
	    				
	    		 
	    		 String Name=(String) m.get(0)[1]+" "+(String) m.get(0)[2]+" "+(String) m.get(0)[3];
	    		 String empcode=(String) m.get(0)[0];
	    		 String Bank_Name=(String) m.get(0)[4];
	    		 long Account_Number=(long) m.get(0)[5];
	    		 String IFSC_code=(String) m.get(0)[6];
	    		 String Branch=(String) m.get(0)[7];
	    		 
	    		 double NetPay=ESdao.EmployeeSalary(empcode, Month, year);	
	    		 Salreport.put("Empcode", empcode);
	    		 Salreport.put("Employee Name", Name);
	    		 Salreport.put("Amount", NetPay);
	    		 Salreport.put("Bank_Name", Bank_Name);
	    		 Salreport.put("Account_Number", Account_Number);
	    		 Salreport.put("IFSC_code", IFSC_code);
	    		 Salreport.put("Branch", Branch);
	    		 Allinfo.add(Salreport);
	    	 }
	      
	      
	      
		return Allinfo;
	}
	
	public List DeductionMonthly(String DeductionName,String Month1,String year1) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int Month=Integer.parseInt(Month1);
		int year=Integer.parseInt(year1);
		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();
	    List Empid=new ArrayList();
	    List<Map<String,Object>> allDeduct=new ArrayList<Map<String,Object>>();
	    Empid=bsDAO.Empid();
	    for (int j=0; j<Empid.size() ;j++) 
   	 {
	    	
	    	
	    	 Map Deductionmonth=new HashMap();
	    	 int idemp= (int) Empid.get(j);
	    	
    	

    		Criteria cr=session.createCriteria(Employees.class);
    		cr.add(Restrictions.eq("idEmployees", idemp));
    		Projection p=Projections.property("employeeCode");
    		Projection p1=Projections.property("emp_First_Name");
    		Projection p2=Projections.property("emp_Middle_Name");
    		Projection p3=Projections.property("emp_Last_Name");
    		ProjectionList pl=Projections.projectionList();
    		pl.add(p);
    		pl.add(p1);
    		pl.add(p2);
    		pl.add(p3);
    		cr.setProjection(pl);
    		List<Object[]> m=cr.list();
    		 
    		 String Name=(String) m.get(0)[1]+" "+(String) m.get(0)[2]+" "+(String) m.get(0)[3];
    		 String empcode=(String) m.get(0)[0];
    		 float BasicSalary=BSmanager.basicsal(empcode, Month, year);//Basic
    	
    		Deductionmonth.put("EmployeeCode", empcode);
    		Deductionmonth.put("EmployeeName", Name);
    		Deductionmonth.put("Month", Month);
    		Deductionmonth.put("Year", year);
    		Deductionmonth.put("BasicSalary", BasicSalary);
    		
    		Map deduction=new HashMap();
    		deduction=ADdao.deductionAmount(empcode, Month, year, DeductionName);
    		float DedAmount=0.0f;
    		try {
    				DedAmount=(float) deduction.get("Deduction Amount");
    			}
    		catch(Exception e)
    		{
    			
    		}
    		Deductionmonth.put("Deduction Amount", DedAmount);
    		allDeduct.add(Deductionmonth);
    		
   	 }
		return allDeduct;  		
		
	}
	
	
	//
	public List DayPresentDetails(Date dt)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> DayPresent=new ArrayList<Map<String,Object>>();
		List Shiftid=new ArrayList();
		Criteria cr=session.createCriteria(Shift.class);
		Projection pr=Projections.property("idShift");
		cr.setProjection(pr);
		  Shiftid=cr.list();
	
		    for (int j=0; j<Shiftid.size() ;j++) 
	   	 {
		    	List<Object[]> idempDes=new ArrayList<Object[]>();
		    	 Map info=new HashMap();
		    	 Map Deductionmonth=new HashMap();
		    	 int idShift= (int) Shiftid.get(j);
	
		    	 Criteria cp=session.createCriteria(Shift.class);
		    	 cp.add(Restrictions.eq("idShift", idShift));
		    	 Projection r=Projections.property("name");
		    	 cp.setProjection(r);
		    	 String ShiftName= (String)cp.uniqueResult();

		    	 Criteria sa=session.createCriteria(Attendance.class);
		    	 sa.add(Restrictions.eq("idShift", idShift));
		    	 sa.add(Restrictions.eq("date", dt));
		    	 Projection pa=Projections.property("idEmployees");
		    	 Projection pb=Projections.property("idDesignation");
		    	 Projection p1=Projections.distinct(pa);
		 
		    	 ProjectionList ps=Projections.projectionList();
		    	 ps.add(p1);
		    	 ps.add(pb);
		    	 sa.setProjection(ps);
		    		idempDes=sa.list();
		    	Map DesNameidDept=new HashMap();
		    	Map Shiftinfo=new HashMap();
		    
		    	 for(Object[] row:idempDes)
		    	 {
		    		 
		    		 int idEmployee=(int) row[0];
		    		
		 	
		 			Criteria cr7=session.createCriteria(Employees.class);
					cr7.add(Restrictions.eq("idEmployees", idEmployee));
					Projection p17=Projections.property("employeeCode");
					cr7.setProjection(p17);
					String empcode=(String) cr7.uniqueResult();
		 		
		    		 int idDesignation= (int) row[1];
		    	
		    		 Criteria ac=session.createCriteria(Designation.class);
		    		 ac.add(Restrictions.eq("idDesignation", idDesignation));
		    		 Projection pn=Projections.property("name");
		    		 Projection pn1=Projections.property("idDepartment");
		    		 ProjectionList pd=Projections.projectionList();
		    		 pd.add(pn);
		    		 pd.add(pn1);
		    		 ac.setProjection(pd);
		     		List<Object[]> ms=ac.list();
		    	
		    		String Desname=(String) ms.get(0)[0];
		    		int idDept=(int) ms.get(0)[1];

		    		 Criteria s4=session.createCriteria(Department.class);
		    		 s4.add(Restrictions.eq("idDepartment", idDept));
		    		 Projection pr4=Projections.property("name");
		    		 s4.setProjection(pr4);
		    		 String deptName=(String) s4.uniqueResult();
		    		 Shiftinfo.put("Shift", ShiftName);
		    		 Shiftinfo.put("Department", deptName);
		    		 Shiftinfo.put("Designation", Desname);
		    		 Shiftinfo.put("Employee code", empcode);
		    		 DayPresent.add(Shiftinfo);
		    		 
		    		 
		    	 }
		    	 
	   	 
	   	 }
		    
		    
		    
		return DayPresent;
		
	}
	
	
	public List TotalPF()
	{
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List Empid=new ArrayList();
		List<Map<String,Object>> totalPFreport=new ArrayList<Map<String,Object>>();
		Empid=bsDAO.Empid();
		  for (int j=0; j<Empid.size() ;j++) 
		   	 {
			  	int idemp= (int) Empid.get(j);
			  	
			  	Criteria ca=session.createCriteria(EmpWorkDetails.class);
			  	ca.add(Restrictions.eq("idEmployees", idemp));
			  	Projection pr=Projections.property("joining_Date");
			  	ca.setProjection(pr);
			  	 Date joiningdate1= (Date) ca.uniqueResult();

				Map PFreport=new HashMap();
				String joiningdate=String.valueOf(joiningdate1);
				
				String years[]=joiningdate.split("-");
				int year=Integer.valueOf(years[0]);
			
				int month=Integer.valueOf(years[1]);
				int day=Integer.valueOf(years[1]);
				Calendar calendar = Calendar.getInstance();  
		        calendar.set(year,month,day);  
		        Date date=new Date();
		        calendar.setTime(date);
		        int currntyear = calendar.get(Calendar.YEAR);
		        int currntmonth = calendar.get(Calendar.MONTH);
		      
			    Map Deductionmonth=new HashMap();
			  
			    Criteria cr=session.createCriteria(Employees.class);
	    		cr.add(Restrictions.eq("idEmployees", idemp));
	    		Projection p=Projections.property("employeeCode");
	    		Projection p1=Projections.property("emp_First_Name");
	    		Projection p2=Projections.property("emp_Middle_Name");
	    		Projection p3=Projections.property("emp_Last_Name");
	    		ProjectionList pl=Projections.projectionList();
	    		pl.add(p);
	    		pl.add(p1);
	    		pl.add(p2);
	    		pl.add(p3);
	    		cr.setProjection(pl);
	    		List<Object[]> m=cr.list();
    	
			    String Name=(String) m.get(0)[1]+" "+(String) m.get(0)[2]+" "+(String) m.get(0)[3];
			    String empcode=(String) m.get(0)[0];
			   
			    int idSalary=0;
			    double totalPF=0.0f;
			    try
			    {
			    	Criteria c=session.createCriteria(Salary.class);
			    	c.add(Restrictions.eq("idEmployees", idemp));
			    	c.add(Restrictions.ge("year", year));
			    	c.add(Restrictions.lt("year", currntyear));
			    	Projection pd=Projections.property("idSalary");
			    	c.setProjection(pd);
			    	  idSalary=(int) c.uniqueResult();
			  
				Criteria cv=session.createCriteria(SalaryDeduction.class);
				cv.add(Restrictions.eq("idSalary", idSalary));
				cv.add(Restrictions.eq("deductionType", "PF"));
			    Projection pg=Projections.sum("deductionAmount");
			    cv.setProjection(pg);
			    totalPF=(double) cv.uniqueResult();
			    }
			    catch(NullPointerException ex)
			    {
			    	idSalary=0;
			    	totalPF=0.0f;
			    }
			    
			    PFreport.put("Employee code", empcode);
			    PFreport.put("Employee Name", Name);
			    PFreport.put("StartDate", joiningdate);
			    PFreport.put("PFAmount", totalPF);
			    totalPFreport.add(PFreport);
		   	 }
		return totalPFreport;
		
		
	}
	
	public List TotalEarnReport(String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		
			List Empid=new ArrayList();
			List<Map<String,Object>> TotalEarn=new ArrayList<Map<String,Object>>();
		    Empid=bsDAO.Empid();
		    for (int j=0; j<Empid.size() ;j++) 
	   	 {
		    	 Map Deductionmonth=new HashMap();
		    	 int idemp= (int) Empid.get(j);
		    		Criteria b=session.createCriteria(Employees.class);
					b.add(Restrictions.eq("idEmployees", idemp));
					Projection ad=Projections.property("employeeCode");
					b.setProjection(ad);
					String empcode=(String) b.uniqueResult();

		
		    	float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
				
		    	float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
	
		    	float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
		    	float mOvertime=bsDAO.Overtime(empcode, month, year);
	
		    	float totalEarn=BasicSalary+incentive+ThirdShift+mOvertime;
		    	
		    	
		    	Map<String,Object> TotalEarning=new HashMap();
		    	Map<String,Object> mp=new HashMap();
		    	TotalEarning.put("Employee Code", empcode);
		    	TotalEarning.put("Incentive",incentive );
		    	TotalEarning.put("Third Shift Allownce", ThirdShift);
		    	TotalEarning.put("Overtime", mOvertime);
		    	TotalEarning.put("Basic ", BasicSalary);
		
		    	mp.putAll(TotalEarning);
		    	TotalEarn.add(mp);
		    	
		    	
		    	}
			return TotalEarn;
	}
	
	public List yearlyEarning(String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		int year=Integer.parseInt(year1);
		 List<Map<String,Object>> TotalEarn=new ArrayList<Map<String,Object>>();
		
		int Month1 =0;
		int Month2=11;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,Month1,day);  
        Date fd1 = calendar.getTime();
        day=30;
        calendar.set(year,Month2,day);  
        Date ld1 = calendar.getTime();

        List Empid=new ArrayList();
        List<Map<String,Object>> months=new ArrayList<Map<String,Object>>();
      
    		Empid= bsDAO.Empid();
    		int loop=11;
    		
    		 calendar.set(year,Month1,day); 
    		for(int p=0;p<=loop;p++)
    		{
    			Map MandY=new HashMap();
    			 
    			  int m = calendar.get(Calendar.MONTH);
    			  int y = calendar.get(Calendar.YEAR);
    			  MandY.put("Month", m);
    			  MandY.put("Year", y);
    			  months.add(MandY);
    			  calendar.add(Calendar.MONTH,1);
    			 
    		}
    	 for (int j=0; j<Empid.size() ;j++) 
    	 {
    		 
    	
    		 int idemp= (int) Empid.get(j);
    			Criteria b=session.createCriteria(Employees.class);
    			b.add(Restrictions.eq("idEmployees", idemp));
    			Projection ad=Projections.property("employeeCode");
    			b.setProjection(ad);
    			String empcode=(String) b.uniqueResult();
    			Map Info=new HashMap();
    			Info=bsDAO.info(empcode);//Emp_id& Emp_Name
    		
    		 for(int i=0;i<=loop;i++)
    	      { 
    			 int monthx=(int) months.get(i).get("Month");
    			 int yearx=(int) months.get(i).get("Year");
    			 float BasicSalary=BSmanager.basicsal(empcode, monthx, year);//Basic
    					
    			 float incentive=bsDAO.Incentive(empcode, monthx, year);//Incentive
    	
    			 float ThirdShift=bsDAO.Allownce(empcode, monthx, year);//Allownce
    			 float mOvertime=bsDAO.Overtime(empcode, monthx, year);
    	
    			 float totalEarn=BasicSalary+incentive+ThirdShift+mOvertime;
    			    	
 		    	Map<String,Object> mp=new HashMap();

    			 Map<String,Object> TotalEarning=new HashMap();
    			  TotalEarning.put("Employee Code", empcode);
    			  TotalEarning.put("Incentive",incentive );
    			  TotalEarning.put("Third Shift Allownce", ThirdShift);
    			  TotalEarning.put("Overtime", mOvertime);
    			  TotalEarning.put("Basic ", BasicSalary);
    			  TotalEarning.put("Employee Code", empcode);
    			  mp.putAll(TotalEarning);
    			  TotalEarn.add(TotalEarning);
    			 
    			  }
    	   }
	session.close();
    	 return TotalEarn;
}
	
	public List TotalDeductionReport(String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
	
		List Empid=new ArrayList();
		
		List<Map<String,Object>> AllDeduction=new ArrayList<Map<String,Object>>();
		
		Empid= bsDAO.Empid();
		 for (int j=0; j<Empid.size() ;j++) 
    	 {
			 
			 int empid= (int) Empid.get(j);
		
					Criteria b=session.createCriteria(Employees.class);
					b.add(Restrictions.eq("idEmployees", empid));
					Projection ad=Projections.property("employeeCode");
					b.setProjection(ad);
					String empcode=(String) b.uniqueResult();
				 
			float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
			Map TaxDeduction=new HashMap();
			Map<String,Object> mp=new HashMap();

			Map OtherDeductions=new HashMap(); 
			 TaxDeduction=ADdao.CalDeductions((int) empid, BasicSalary);//TaxDeductions
			 OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
	
			 float welfare=ESdao.Welfare(empcode, month);
			 TaxDeduction.put("Welfare", welfare);
			 TaxDeduction.put("Employee code", empcode);
			 mp.putAll(OtherDeductions);
			 mp.putAll(TaxDeduction);
			 AllDeduction.add(mp);
					
    	 }
		return AllDeduction;
    	 
		
	}
	
	public List TotalDeductionyear(String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int year=Integer.parseInt(year1);
		int Month1 =0;
		int Month2=11;
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,Month1,day);  
        Date fd1 = calendar.getTime();
        day=30;
        calendar.set(year,Month2,day);  
        Date ld1 = calendar.getTime();

   
        
      
        List Empid=new ArrayList();
        List<Map<String,Object>> months=new ArrayList<Map<String,Object>>();
    	List<Map<String,Object>> AllDeduction=new ArrayList<Map<String,Object>>();
    		Empid= bsDAO.Empid();
    		int loop=11;
    		
    		 calendar.set(year,Month1,day); 
    		for(int p=0;p<=loop;p++)
    		{
    			Map MandY=new HashMap();
    			 
    			  int m = calendar.get(Calendar.MONTH);
    			  int y = calendar.get(Calendar.YEAR);
    			  MandY.put("Month", m);
    			  MandY.put("Year", y);
    			  months.add(MandY);
    			  calendar.add(Calendar.MONTH,1);
    			
    		}
	
	 for (int j=0; j<Empid.size() ;j++) 
	 {
		 

		 int idemp= (int) Empid.get(j);
			Criteria b=session.createCriteria(Employees.class);
			b.add(Restrictions.eq("idEmployees", idemp));
			Projection ad=Projections.property("employeeCode");
			b.setProjection(ad);
			String empcode=(String) b.uniqueResult();
		
		 for(int i=0;i<=loop;i++)
	      { 
			 int monthx=(int) months.get(i).get("Month");
			 int yearx=(int) months.get(i).get("Year");

				float BasicSalary=BSmanager.basicsal(empcode, monthx, year);//Basic
				Map TaxDeduction=new HashMap();
				
				 Map<String,Object> mp=new HashMap();
				 Map OtherDeductions=new HashMap(); 
				 TaxDeduction=ADdao.CalDeductions((int) idemp, BasicSalary);//TaxDeductions
				 OtherDeductions=ODdao.OtherDeductions(empcode, monthx, year);//Other Deductions
		
				 float welfare=ESdao.Welfare(empcode, monthx);
				 TaxDeduction.put("Employee code", empcode);
				 TaxDeduction.put("Welfare", welfare);
				 mp.putAll(OtherDeductions);
				 mp.putAll(TaxDeduction);
				 AllDeduction.add(mp);
			
	      }
	
	}	
	 return AllDeduction;
}
	
	public List IncentiveGrpByMonth(String StrtDate,String EndDate)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		String date1[]=StrtDate.split("-");
		int year=Integer.valueOf(date1[0]);
	
		int month=Integer.valueOf(date1[1]);
		month=month-1;
		
		String date2[]=EndDate.split("-");
		int year1=Integer.valueOf(date2[0]);
	
		int month1=Integer.valueOf(date2[1]);
		month1=month1-1;
		
	
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,month,day);  
        Date fd1 = calendar.getTime();
        day=30;
        calendar.set(year1,month1,day);  
        calendar.add(Calendar.DATE,1);
        Date ld1 = calendar.getTime();
        Date dt=fd1;
       
        List<Map<String,Object>> Listmonths=new ArrayList<Map<String,Object>>();
        List<Map<String,Object>> Finl=new ArrayList<Map<String,Object>>();
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        calendar.set(year,month,day);
        int loop=0;
        while(dt.before(ld1))
        {
       	 Map MandY=new HashMap();
       	 int m = calendar.get(Calendar.MONTH);
   		  int y = calendar.get(Calendar.YEAR);
   		  MandY.put("Month", m+1);
   		  MandY.put("Year", y);
   		 
   		  Listmonths.add(MandY);
       	 calendar.add(Calendar.MONTH,1);
       	 dt=calendar.getTime();
       	 
       	 loop++;
        }
		
		 for(int i=0;i<=Listmonths.size()-1;i++)
	      { 
			 int monthx=(int) Listmonths.get(i).get("Month");
			 int yearx=(int) Listmonths.get(i).get("Year");
		
		
			 List idSalary=new ArrayList();
		
			 Criteria c=session.createCriteria(Salary.class);
	
		    	c.add(Restrictions.eq("month", monthx));
		    	c.add(Restrictions.eq("year", yearx));
		    	Projection pd=Projections.property("idSalary");
		    	c.setProjection(pd);
		    	 idSalary=c.list();
			 double Total=0.0f;
			 Map total=new HashMap();
			 for (int j=0; j<idSalary.size() ;j++) 
			 {
				 int idSal=(int) idSalary.get(j);
				 double TotalAmount=0;
				 try {
					 
				 
			
				  Criteria cv=session.createCriteria(SalaryEarning.class);
					cv.add(Restrictions.eq("idSalary", idSalary));
					cv.add(Restrictions.eq("earningType", "Incentive"));
				    Projection pg=Projections.sum("earningAmount");
				    cv.setProjection(pg);
				    TotalAmount=(double) cv.uniqueResult();
				  
				 }
				 catch(Exception e)
				 {
					 TotalAmount=0;
				 }
				 Total=+TotalAmount;
			 }
			 total.put("Month", monthx);
			 total.put("Year", year);
			 total.put("Amount", Total);
			 Finl.add(total);
	      }
			 return Finl;
		
	}
	
	public List SalaryGrpByMonth(String StrtDate,String EndDate)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		String date1[]=StrtDate.split("-");
		int year=Integer.valueOf(date1[0]);
	
		int month=Integer.valueOf(date1[1]);
		month=month-1;
		
		String date2[]=EndDate.split("-");
		int year1=Integer.valueOf(date2[0]);
	
		int month1=Integer.valueOf(date2[1]);
		month1=month1-1;
		
	
		int day=1;
		Calendar calendar = Calendar.getInstance();  
        calendar.set(year,month,day);  
        Date fd1 = calendar.getTime();
        day=30;
        calendar.set(year1,month1,day);  
        calendar.add(Calendar.DATE,1);
        Date ld1 = calendar.getTime();
        Date dt=fd1;
     
        
        List<Map<String,Object>> Listmonths=new ArrayList<Map<String,Object>>();
        List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
        int loop=0;
       
        calendar.set(year,month,day);
     while(dt.before(ld1))
     {
    	 Map MandY=new HashMap();
    	 int m = calendar.get(Calendar.MONTH);
		  int y = calendar.get(Calendar.YEAR);
		  MandY.put("Month", m+1);
		  MandY.put("Year", y);
		 
		  Listmonths.add(MandY);
    	 calendar.add(Calendar.MONTH,1);
    	 dt=calendar.getTime();
    	

    	 loop++;
     }
        
		 for(int i=0;i<=Listmonths.size()-1;i++)
	      { 
			 int monthx=(int) Listmonths.get(i).get("Month");
			 int yearx=(int) Listmonths.get(i).get("Year");
			 double TotalSal=0.0f;
			 Map total=new HashMap();
			 try {
		
				
				 Criteria c=session.createCriteria(Salary.class);
		
			    	c.add(Restrictions.eq("month", monthx));
			    	c.add(Restrictions.eq("year", yearx));
			    	Projection pd=Projections.sum("netSalary");
			    	c.setProjection(pd);
			    	TotalSal=(double) c.uniqueResult();
			 	}
			 catch(NullPointerException ex)
			 {
				 TotalSal=0.0f; 
			 }
			 total.put("Month", monthx);
			 total.put("Year", year);
			 total.put("Amount", TotalSal);
			 list.add(total);
	      }
		return list;
		
	}
	public List IncentiveGrpByYear(String Stryear1,String endyear2) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int Stryear=Integer.parseInt(Stryear1);
		int endyear=Integer.parseInt(endyear2);
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		List idSalary=new ArrayList();
		
		for(int i=Stryear;i<=endyear;i++)
		{
		int endyear1=i+1;
		try {
	
			 Criteria c=session.createCriteria(Salary.class);
				
		    	c.add(Restrictions.eq("year", i));
		    	Projection pd=Projections.property("idSalary");
		    	c.setProjection(pd);
		    	idSalary =c.list();
		
		}
		catch(NullPointerException ex)
		{
			idSalary=null;
		}
		double Total=0.0f;
		
		Map total=new HashMap();
		for (int j=0; j<idSalary.size() ;j++) 
			{
				
				int idSal=(int) idSalary.get(j);

				 Criteria cv=session.createCriteria(SalaryEarning.class);
					cv.add(Restrictions.eq("idSalary", idSal));
					cv.add(Restrictions.eq("earningType", "Incentive"));
				    Projection pg=Projections.sum("earningAmount");
				    cv.setProjection(pg);
				   double TotalAmount=(double) cv.uniqueResult();
				Total=Total+TotalAmount;
				
			}
		total.put(" year", i);
	
		total.put("Amount", Total);
		list.add(total);
		}	
		return list;
	}
	
	
	public List SalaryGrpByYear(String stryear1,String endyear2) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int stryear=Integer.parseInt(stryear1);
		int endyear=Integer.parseInt(endyear2);
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		for(int i=stryear;i<=endyear;i++)
		{
		int endyear1=i+1;
		Map total=new HashMap();
	
		double TotalSal=0;
		try {
	
		 Criteria cm=session.createCriteria(Salary.class);
	
	    	cm.add(Restrictions.eq("year", i));
	    	Projection pd=Projections.sum("netSalary");
	    	cm.setProjection(pd);
	    	TotalSal=(double) cm.uniqueResult();
		}
		catch(NullPointerException ex)
		{
			TotalSal=0.0f;
		}
		total.put(" year", i);
		
		total.put("Amount", TotalSal);
		list.add(total);
		}
		return list;
	}
	
	
	
	public Map monthSalGrpBydept(int month, int year,String Deptname) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Map mp=new HashMap();
		 List idEmp=new ArrayList();
		
		 Criteria cd=session.createCriteria(Department.class);
		 cd.add(Restrictions.eq("name", Deptname));
		 Projection pr=Projections.property("idDepartment");
		 cd.setProjection(pr);
		 int idDept=(int) cd.uniqueResult();
		
		 
		 Criteria cd1=session.createCriteria(Designation.class);
		 cd1.add(Restrictions.eq("idDepartment", idDept));
		 Projection pr1=Projections.property("idDesignation");
		 cd1.setProjection(pr1);
			List idDes1= cd1.list();

		double  TotalSal=0.0f;
		 for (int i=0; i<idDes1.size() ;i++) 
		 {
			 
			 int idDes=(int) idDes1.get(i);

			Criteria cr=session.createCriteria(EmpWorkDetails.class);
			cr.add(Restrictions.eq("idDesignation", idDes));
			Projection a=Projections.property("idEmployees");
			
		
			cr.setProjection(a);
			idEmp=cr.list();

			double Salary=0;
		 for (int j=0; j<idEmp.size() ;j++) 
		 {
			 
			 String empcode;
			 int idemp= (int) idEmp.get(j);
		
			try {
			
			 Criteria cm=session.createCriteria(Salary.class);
				
		    	cm.add(Restrictions.eq("idEmployees", idemp));
		    	Projection pd=Projections.property("netSalary");
		    	cm.setProjection(pd);
		    	 Salary=(double) cm.uniqueResult();
			}
			catch(Exception e)
			{
				Salary=0;
			}
			TotalSal=TotalSal+Salary;
		 }
		 }
		mp.put("Department", Deptname);
		mp.put("month", month);
		mp.put("year", year);
		mp.put("TotalPay", TotalSal);
		 
		return mp;
		
	}
	public Map yearSalGrpBydept(int year,String DeptName)
	{
		Session session = (Session) hipernateConfg.getSession();  
	Transaction t = session.beginTransaction();
		Map mp=new HashMap();
		 List idEmp=new ArrayList();
		 Criteria cd=session.createCriteria(Department.class);
		 cd.add(Restrictions.eq("name", DeptName));
		 Projection pr=Projections.property("idDepartment");
		 cd.setProjection(pr);
		 int idDept=(int) cd.uniqueResult();

			 Criteria cd1=session.createCriteria(Designation.class);
			 cd1.add(Restrictions.eq("idDepartment", idDept));
			 Projection pr1=Projections.property("idDesignation");
			 cd1.setProjection(pr1);
			 int idDes=(int) cd1.uniqueResult();
			
			Criteria cr=session.createCriteria(EmpWorkDetails.class);
			cr.add(Restrictions.eq("idDesignation", idDes));
			Projection a=Projections.property("idEmployees");
			
		
			cr.setProjection(a);
			idEmp=cr.list();
		double  TotalSal=0.0f;
		 for (int j=0; j<idEmp.size() ;j++) 
		 {
			 double Salary=0;
			 String empcode;
			 int idemp= (int) idEmp.get(j);
		try {
			
			 Criteria cm=session.createCriteria(Salary.class);
				
		    	cm.add(Restrictions.eq("idEmployees", idemp));
		    	cm.add(Restrictions.eq("year", year));
		    	Projection pd=Projections.property("netSalary");
		    	cm.setProjection(pd);
		    	 Salary=(double) cm.uniqueResult();
			
		}
		catch(Exception e)
		{
			 Salary=0;
		}
		
		TotalSal=TotalSal+Salary;
		 }
		mp.put("Department", DeptName);
		mp.put("year", year);
		mp.put("TotalPay", TotalSal);
		return mp;
	}
	
	
	
	public List YearBonus(String year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> List=new ArrayList<Map<String,Object>>();
		String date[]=year.split("-");
		int year1=Integer.valueOf(date[0]);
	
		int year2=Integer.valueOf(date[1]);
		
		for(int i=year1;i<=year2;i++)
		{
			 Map TotalBonus=new HashMap();
			int endyear1=i+1;
			String Stryr=String.valueOf(i);
			String endyear=String.valueOf(endyear1);
			String fyear=Stryr+"-"+endyear;
			
			double Bonus=0.0f;
			try {
			Criteria c=session.createCriteria(Bonus.class);
			c.add(Restrictions.eq("year", fyear));
			Projection pr=Projections.sum("bonus");
			c.setProjection(pr);
			Bonus=(double) c.uniqueResult();
			
				}
			 catch(NullPointerException ex)
			 {
				Bonus=0.0f; 
			 }
			TotalBonus.put("Year ", fyear);
			TotalBonus.put("Bonus", Bonus);
			List.add(TotalBonus);
		
			
		}
			
		return List;
	}
	
	
	public List TopEmpBonus(String year ,int limit)
	{
		Session session = (Session) hipernateConfg.getSession();  
		
		List<Map<String,Object>> finl=new ArrayList<Map<String,Object>>();
		List<Object[]> List=new ArrayList<Object[]>();

		Criteria cr=session.createCriteria(Bonus.class);
		cr.add(Restrictions.eq("year", year));
		cr.addOrder(Order.desc("bonus"));
		cr.setFirstResult(0);
		cr.setMaxResults(limit);
		Projection pr=Projections.property("idEmployees");
		Projection pr1=Projections.property("bonus");
		Projection pr2=Projections.property("presentDays");
		ProjectionList pl=Projections.projectionList();
		pl.add(pr);
		pl.add(pr1);
		pl.add(pr2);
		cr.setProjection(pl);
		List=cr.list();
	
		for(Object[] row:List )
		{
	
			Map mp=new HashMap();
			int idEmployee=(int) row[0];
			float bonus=(float) row[1];
			float PresentDays=(float) row[2];
			
			
	
			
			Criteria crd=session.createCriteria(Employees.class);
    		crd.add(Restrictions.eq("idEmployees", idEmployee));
    		Projection p=Projections.property("employeeCode");
    		Projection p1=Projections.property("emp_First_Name");
    		Projection p2=Projections.property("emp_Middle_Name");
    		Projection p3=Projections.property("emp_Last_Name");
    		ProjectionList pl5=Projections.projectionList();
    	
    		pl5.add(p1);
    		pl5.add(p2);
    		pl5.add(p3);
    		pl5.add(p);
    		crd.setProjection(pl5);
    		List<Object[]> m=crd.list();
	
			String Name=(String) m.get(0)[0]+" "+(String) m.get(0)[1]+" "+(String) m.get(0)[2];
			String empcode=(String) m.get(0)[3];
			mp.put("Employee name", Name);
			mp.put("Employee code", empcode);
			mp.put("year", year);
			mp.put("Bonus", bonus);
			mp.put("PresentDays", PresentDays);
			finl.add(mp);
		}
		return finl;
	}
	
	public List TopEmpAttendance(String year,int limit)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> finl=new ArrayList<Map<String,Object>>();
		List<Object[]> List=new ArrayList<Object[]>();

		Criteria cr4=session.createCriteria(Bonus.class);
		cr4.add(Restrictions.eq("year", year));
		cr4.addOrder(Order.desc("bonus"));
		cr4.setFirstResult(0);
		cr4.setMaxResults(limit);
		Projection pr=Projections.property("idEmployees");
		Projection pr1=Projections.property("bonus");
		Projection pr2=Projections.property("presentDays");
		ProjectionList pl4=Projections.projectionList();
		pl4.add(pr);
		pl4.add(pr1);
		pl4.add(pr2);
		cr4.setProjection(pl4);
		List=cr4.list();
	
		for(Object[] row:List )
		{
		
			Map mp=new HashMap();
			int idEmployee=(int) row[0];
			float PresentDays=(float) row[2];
		
		    Criteria cr=session.createCriteria(Employees.class);
    		cr.add(Restrictions.eq("idEmployees", idEmployee));
    		Projection ps=Projections.property("employeeCode");
    		Projection p1=Projections.property("emp_First_Name");
    		Projection p2=Projections.property("emp_Middle_Name");
    		Projection p3=Projections.property("emp_Last_Name");
    		ProjectionList pl=Projections.projectionList();
    
    		pl.add(ps);
    		pl.add(p1);
    		pl.add(p2);
    		pl.add(p3);
    		cr.setProjection(pl);
    		List<Object[]> m=cr.list();
	
			String Name=(String) m.get(0)[1]+" "+(String) m.get(0)[2]+" "+(String) m.get(0)[3];
			String empcode=(String) m.get(0)[0];
			mp.put("Employee name", Name);
			mp.put("Employee code", empcode);
			mp.put("year", year);
			mp.put("PresentDays", PresentDays);
			finl.add(mp);
		}	
		return finl;
	}
	

	public List topFemaleEmp(String year,int limit)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> finl=new ArrayList<Map<String,Object>>();
		List<Object[]> info=new ArrayList<Object[]>();
	
		Criteria ca=session.createCriteria(Employees.class);
		ca.add(Restrictions.eq("gender", "female"));
		Projection pf=Projections.property("idEmployees");
		ca.setProjection(pf);
		List<Integer> idemp1=ca.list();
		Criteria cdr=session.createCriteria(Bonus.class);
		cdr.add(Restrictions.eq("year", year));
		cdr.add(Restrictions.in("idEmployees", idemp1));
		cdr.addOrder(Order.desc("presentDays"));
		cdr.setFirstResult(0);
		cdr.setMaxResults(limit);
		Projection pr=Projections.property("idEmployees");

		Projection pr2=Projections.property("presentDays");
		ProjectionList pld=Projections.projectionList();
		pld.add(pr);
		
		pld.add(pr2);
		cdr.setProjection(pld);
		info=cdr.list();
	
		for(Object[] row:info)
		{
			Map mp=new HashMap();
			Map info1 =new HashMap();
			int idemp=(int) row[0];
			float PresentDays=(float) row[1];
			
		    Criteria cr=session.createCriteria(Employees.class);
    		cr.add(Restrictions.eq("idEmployees", idemp));
    		Projection p=Projections.property("employeeCode");
    		Projection p1=Projections.property("emp_First_Name");
    		Projection p2=Projections.property("emp_Middle_Name");
    		Projection p3=Projections.property("emp_Last_Name");
    		ProjectionList pl=Projections.projectionList();
    		
    		pl.add(p);
    		pl.add(p1);
    		pl.add(p2);
    		pl.add(p3);
    		cr.setProjection(pl);
    		List<Object[]> m=cr.list();
		
			String Name=(String) m.get(0)[1]+" "+(String) m.get(0)[2]+" "+(String) m.get(0)[3];
			String empcode=(String) m.get(0)[0];
			mp.put("Employee name", Name);
			mp.put("Employee code", empcode);
			mp.put("year", year);
			mp.put("PresentDays", PresentDays);
			finl.add(mp);
			
		}
	
		return finl;
		
	}
	
	public List WorstEmpAttendance(String year,int limit)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> finl=new ArrayList<Map<String,Object>>();
		List<Object[]> List=new ArrayList<Object[]>();

		Criteria crz=session.createCriteria(Bonus.class);
		crz.add(Restrictions.eq("year", year));
		crz.addOrder(Order.asc("presentDays"));
		crz.setFirstResult(0);
		crz.setMaxResults(limit);
		Projection pr=Projections.property("idEmployees");
		
		Projection pr2=Projections.property("presentDays");
		ProjectionList plz=Projections.projectionList();
		plz.add(pr);
	
		plz.add(pr2);
		crz.setProjection(plz);
		List=crz.list();
	
		
		for(Object[] row:List )
		{
			Map info =new HashMap();
			Map mp=new HashMap();
			int idEmployee=(int) row[0];
			float PresentDays=(float) row[1];

		    Criteria cr=session.createCriteria(Employees.class);
    		cr.add(Restrictions.eq("idEmployees", idEmployee));
    		Projection p1=Projections.property("employeeCode");
    		Projection p2=Projections.property("emp_First_Name");
    		Projection p3=Projections.property("emp_Middle_Name");
    		Projection p=Projections.property("emp_Last_Name");
    		ProjectionList pl=Projections.projectionList();
    		
    		pl.add(p1);
    		pl.add(p2);
    		pl.add(p3);
    		pl.add(p);
    		cr.setProjection(pl);
    		List<Object[]> map=cr.list();
		
			String Name=(String) map.get(0)[1]+" "+(String) map.get(0)[2]+" "+(String) map.get(0)[3];
			String empcode=(String) map.get(0)[0];
			mp.put("Employee name", Name);
			mp.put("Employee code", empcode);
			mp.put("year", year);
			mp.put("PresentDays", PresentDays);
			finl.add(mp);
		}	
		return finl;
	}
	
	
	public List TopThirdShiftAllownce(int year,int limit)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Object[]> idSalErnAmount=new ArrayList<Object[]>();
		List<Map<String,Object>> topAllownces=new ArrayList<Map<String,Object>>();
		
		Map info =new HashMap();
		Criteria crz=session.createCriteria(SalaryEarning.class);
		crz.add(Restrictions.eq("earningType", "Third Shift Allownce"));
		crz.addOrder(Order.asc("earningAmount"));
		crz.setFirstResult(0);
		crz.setMaxResults(limit);
		Projection pr=Projections.property("idSalary");
		Projection pr3=Projections.distinct(pr);
		Projection pr1=Projections.property("earningAmount");
	
		ProjectionList plz=Projections.projectionList();
		plz.add(pr3);
		plz.add(pr1);
		crz.setProjection(plz);
		idSalErnAmount =crz.list();

		for(Object[] row : idSalErnAmount)
		{
			Map mp =new HashMap();
			int idsal=(int) row[0];
			float Amount=(float) row[1];
			System.err.println(year+"    "+idsal);
			
			Criteria c=session.createCriteria(Salary.class);
	    	
	    	c.add(Restrictions.ge("idSalary", idsal));
	    	c.add(Restrictions.lt("year", year));
	    	Projection pd=Projections.property("idEmployees");
	    	c.setProjection(pd);
	    	int idEmployees=(int) c.uniqueResult();
			
		    Criteria cr=session.createCriteria(Employees.class);
    		cr.add(Restrictions.eq("idEmployees", idEmployees));
    		Projection p1=Projections.property("employeeCode");
    		Projection p2=Projections.property("emp_First_Name");
    		Projection p3=Projections.property("emp_Middle_Name");
    		Projection p=Projections.property("emp_Last_Name");
    		ProjectionList pl=Projections.projectionList();
    		
    		pl.add(p1);
    		pl.add(p2);
    		pl.add(p3);
    		pl.add(p);
    		cr.setProjection(pl);
    		List<Object[]> map=cr.list();
		
			String Name=(String) map.get(0)[1]+" "+(String) map.get(0)[2]+" "+(String) map.get(0)[3];
			String empcode=(String) map.get(0)[0];
			mp.put("Employees Code", empcode);
			mp.put("Employee name", Name);
			mp.put("Third Shift Allownce", Amount);
			
		

			topAllownces.add(mp);
		}
		
		
		return topAllownces;
		
	}
	public Map Bonus_by_Dept(String year, String dept)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		 Criteria cd=session.createCriteria(Department.class);
		 cd.add(Restrictions.eq("name", dept));
		 Projection pr=Projections.property("idDepartment");
		 cd.setProjection(pr);
		 int idDept=(int) cd.uniqueResult();
		 Criteria cd1=session.createCriteria(Designation.class);
		 cd1.add(Restrictions.eq("idDepartment", idDept));
		 Projection pr1=Projections.property("idDesignation");
		 cd1.setProjection(pr1);
			List idDes1= cd1.list();
		float totalBonus=0.0f;
		
		Map DeptBonus=new HashMap();
		for(int i=0;i<idDes1.size();i++)
		{
			List idemp=new ArrayList();
			int iddesi=(int) idDes1.get(i);

			Criteria a1=session.createCriteria(Attendance.class);
			a1.add(Restrictions.eq("idDesignation", iddesi));
			Projection f=Projections.property("idEmployees");
			Projection b=Projections.distinct(f);
			a1.setProjection(b);
			idemp=a1.list();
		
			for(int j=0;j<idemp.size();j++)
			{
				int idEmp= (int) idemp.get(j);
				float bonus=0.0f;
				
				Criteria ca=session.createCriteria(Bonus.class);
				ca.add(Restrictions.eq("idEmployees", idEmp));
				Projection pn=Projections.property("bonus");
				ca.setProjection(pn);
				 bonus=(float) ca.uniqueResult();
				totalBonus=+bonus;
			}
			
		}
		DeptBonus.put("year", year);
		DeptBonus.put("dept", dept);
		DeptBonus.put("Bonus", totalBonus);
		
		return DeptBonus;
	}
	
	
	
	
	
	public List TotalDeductionReport_Dept(String month1,String dept,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
	
		List Empid=new ArrayList();
		
		List<Map<String,Object>> AllDeduction=new ArrayList<Map<String,Object>>();
		
		List idDess=new ArrayList();
		Criteria as=session.createCriteria(Department.class);
		as.add(Restrictions.eq("name", dept));
		Projection fd=Projections.property("idDepartment");
		as.setProjection(fd);
		int idDept=(int) as.uniqueResult();
		
		Criteria as1=session.createCriteria(Designation.class);
		as.add(Restrictions.eq("idDepartment", idDept));
		Projection fd1=Projections.property("idDesignation");
		as1.setProjection(fd1);
		idDess= as1.list();
		float totalBonus=0.0f;
		
		Map DeptBonus=new HashMap();
		for(int i=0;i<idDess.size();i++)
		{
			List<Map<String,Object>> idemp=new ArrayList<Map<String,Object>>();
			int iddesi=(int) idDess.get(i);
			Criteria a1=session.createCriteria(Attendance.class);
			a1.add(Restrictions.eq("idDesignation", iddesi));
			Projection f=Projections.property("idEmployees");
			Projection b=Projections.distinct(f);
			a1.setProjection(b);
			Empid=a1.list();
		 for (int j=0; j<Empid.size() ;j++) 
    	 {
			 
			 int empid= (int) Empid.get(j);
	    		Criteria b1=session.createCriteria(Employees.class);
					b1.add(Restrictions.eq("idEmployees", empid));
					Projection ad=Projections.property("employeeCode");
					b1.setProjection(ad);
					String empcode=(String) b1.uniqueResult();
    	 
			float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
			Map TaxDeduction=new HashMap();
			Map<String,Object> mp=new HashMap();

			Map OtherDeductions=new HashMap(); 
			 TaxDeduction=ADdao.CalDeductions((int) empid, BasicSalary);//TaxDeductions
			 OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
	
			 float welfare=ESdao.Welfare(empcode, month);
			 TaxDeduction.put("Welfare", welfare);
			 TaxDeduction.put("Employee code", empcode);
			 mp.putAll(OtherDeductions);
			 mp.putAll(TaxDeduction);
			 AllDeduction.add(mp);
    	 }
			
    	 }
		return AllDeduction;
    	 
	}
	
	
	
	public List TotalEarnReport_dept(String month1,String dept,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
			int month=Integer.parseInt(month1);
			int year=Integer.parseInt(year1);
		
			List Empid=new ArrayList();
			List<Map<String,Object>> TotalEarn=new ArrayList<Map<String,Object>>();
			List idDess=new ArrayList();
			Criteria as=session.createCriteria(Department.class);
			as.add(Restrictions.eq("name", dept));
			Projection fd=Projections.property("idDepartment");
			as.setProjection(fd);
			int idDept=(int) as.uniqueResult();
			
			Criteria as1=session.createCriteria(Designation.class);
			as1.add(Restrictions.eq("idDepartment", idDept));
			Projection fd1=Projections.property("idDesignation");
			as1.setProjection(fd1);
			idDess= as1.list();
			
		    float totalBonus=0.0f;
		
			Map DeptBonus=new HashMap();
			for(int i=0;i<idDess.size();i++)
			{
				List<Map<String,Object>> idemp=new ArrayList<Map<String,Object>>();
				int iddesi=(int) idDess.get(i);
				Criteria a1=session.createCriteria(Attendance.class);
				a1.add(Restrictions.eq("idDesignation", iddesi));
				Projection f=Projections.property("idEmployees");
				Projection b=Projections.distinct(f);
				a1.setProjection(b);
				Empid=a1.list();
		    for (int j=0; j<Empid.size() ;j++) 
		    	{
		    	 Map Deductionmonth=new HashMap();
		    	 int idemp1= (int) Empid.get(j);
		    		Criteria b1=session.createCriteria(Employees.class);
					b1.add(Restrictions.eq("idEmployees", idemp1));
					Projection ad=Projections.property("employeeCode");
					b1.setProjection(ad);
					String empcode=(String) b1.uniqueResult();

		
		    	float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
				
		    	float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
	
		    	float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
		    	float mOvertime=bsDAO.Overtime(empcode, month, year);
	
		    	float totalEarn=BasicSalary+incentive+ThirdShift+mOvertime;
		    	
		    	
		    	Map<String,Object> TotalEarning=new HashMap();
		    	Map<String,Object> mp=new HashMap();
		    	TotalEarning.put("Employee Code", empcode);
		    	TotalEarning.put("Incentive",incentive );
		    	TotalEarning.put("Third Shift Allownce", ThirdShift);
		    	TotalEarning.put("Overtime", mOvertime);
		    	TotalEarning.put("Basic ", BasicSalary);
		
		    	mp.putAll(TotalEarning);
		    	TotalEarn.add(mp);
		    	
	   	 		}
		    }
			return TotalEarn;
	}
	
	
	public List Salary(String empcode,String date)
	{
		
		Session session = (Session) hipernateConfg.getSession();  
		Salaryreport sr=new Salaryreport();
			
		Map abc=new HashMap();
		
		String start[]=date.split("-");
		int year=Integer.valueOf(start[0]);
		int month=Integer.valueOf(start[1]);
		
		List fnl=new ArrayList();
			
		Map TaxDeduction=new HashMap();
		Map OtherDeductions=new HashMap();

	

		List<Map<String,Object>> FinalTaxDeduction=new ArrayList<Map<String,Object>>();
		List<Map<String,Object>> FinalOtherDeduction=new ArrayList<Map<String,Object>>();
		
			SalarySlip sal=new SalarySlip();
		
			Map Designation_Days=new HashMap();	
		
			
			Map Info=new HashMap();
			Info=bsDAO.info(empcode);//Emp_id& Emp_Name
			int idemp=(int) Info.get("idEmployee");
			String EmpName=(String) Info.get("EmployeeName");
			
			Criteria cr=session.createCriteria(EmpWorkDetails.class);
			cr.add(Restrictions.eq("idEmployees", idemp));
			Projection a=Projections.property("idDesignation");
			
		
			cr.setProjection(a);
			int idDesignation=(int) cr.uniqueResult();
			
			Criteria cs=session.createCriteria(Designation.class);
			cs.add(Restrictions.eq("idDesignation", idDesignation));
			Projection sd=Projections.property("name");
			cs.setProjection(sd);
			String desname=(String) cs.uniqueResult();
			
			
			
			

			float PaidSalLeavs=bsDAO.paidLeaveSal(empcode, month, year);
			float BasicSalary=BSmanager.basicsal(empcode, month, year);//Basic
			
			float incentive=bsDAO.Incentive(empcode, month, year);//Incentive
		
			
			float ThirdShift=bsDAO.Allownce(empcode, month, year);//Allownce
	
			float totalEarn=BasicSalary+incentive+ThirdShift;

			float pf=0.0f;
			float pt=0.0f;
			float esi=0.0f;
			float tds=0.0f;
			float society=0.0f;
		
			
			TaxDeduction=ADdao.CalDeductions(idemp, BasicSalary);//TaxDeductions
			FinalTaxDeduction.add(TaxDeduction);

			if(TaxDeduction.containsKey("PF"))
			{
			pf=(float) TaxDeduction.get("PF");
			}
			if(TaxDeduction.containsKey("PT"))
			{
				
			 pt=(float) TaxDeduction.get("PT");
			}
			if(TaxDeduction.containsKey("ESI"))
			{
			 esi=(float) TaxDeduction.get("ESI");
			}
			if(TaxDeduction.containsKey("TDS"))
			{
			 tds=(float) TaxDeduction.get("TDS");
			}
			if(TaxDeduction.containsKey("Society"))
			{
			society=(float) TaxDeduction.get("Society");
			}
			float AllTaxDeductions=pf+pt+esi+tds+society;
			OtherDeductions=ODdao.OtherDeductions(empcode, month, year);//Other Deductions
			FinalOtherDeduction.add(OtherDeductions);
			float bus =(float) OtherDeductions.get("Bus Charge");
			float Pagetotalbus=+bus;
			
			float phone =(float) OtherDeductions.get("Phone Bills");
			float Pagetotalphone=+phone;
			
			float House =(float) OtherDeductions.get("House Rent");
			float PagetotalHouse=+House;
			
			float Loan =(float) OtherDeductions.get("Loan");
			float PagetotalLoan=+Loan;
			
			float Canteen =(float) OtherDeductions.get("canteen Deduction");
			float PagetotalCanteen=+Canteen;
			
			float Advance =(float) OtherDeductions.get("Advance");
			float PagetotalAdvance=+Advance;
			
			float Other =(float) OtherDeductions.get("Other");
			float PagetotalOther=+Other;
			float LeavHRsal=bsDAO.LeaveHR(empcode, month, year);
			
			double Alldeduction=ODdao.AllDeduction(empcode, month, year);
			
			double TotalDeduction=Alldeduction+AllTaxDeductions;
			double PageTotalDeduction=+TotalDeduction;
			
			int NetPay=(int) (totalEarn+LeavHRsal-TotalDeduction);
		
			
			String NetPayInWord=ENT.convert(Math.abs(NetPay));
			
			float PresentDays=bsDAO.PresentDays(empcode, month, year);//Present Days
		

			sr.setDesignation(desname);
			sr.setEmpcode(empcode);
			sr.setEmpName(EmpName);
			sr.setNetPay(NetPay);
			sr.setPresentDays(PresentDays);
			fnl.add(sr);
			return  fnl;
		 

			
		

	}
	
	
}	
	