package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Hoursleave;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.Shift;

@Component
@Controller
public class HoursleaveDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	
	@Autowired
	EmployeeDAO EmployeeDAO;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	DesignationDAO designationDAO;
	public Hoursleave save(int id,Date date,String shift,String des,int hr,String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession(); 
		Transaction t = session.beginTransaction(); 
		int id1=0;

		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int idemp=emp.getIdEmployees();
		Criteria cr=session.createCriteria(Shift.class);
		cr.add(Restrictions.eq("name", shift));
		Projection pr=Projections.property("idShift");
		cr.setProjection(pr);
		
			int idShift=(int) cr.uniqueResult();

		 Designation desig= (Designation) designationDAO.get(des);
		 int idDes=desig.getIdDesignation();
		 Hoursleave hoursleave=new Hoursleave();
		 	hoursleave.setIdhours_Leave(id);
			hoursleave.setDate(date);
			hoursleave.setIdshift(idShift);
			hoursleave.setIdDesignation(idDes);
			hoursleave.setHours(hr);
			hoursleave.setIdEmployees(idemp);
	
			
			session.saveOrUpdate(hoursleave);
			t.commit();  
			session.close();
			
			return hoursleave;
		
	}

	public Object get(String empcode,Date dt)
	{
		Session session = (Session) hipernateConfg.getSession(); 

		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Hoursleave.class);
		cr.add(Restrictions.eq("idEmployees", id));
		cr.add(Restrictions.eq("date", dt));
		return (Hoursleave) cr.uniqueResult();
		
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession(); 
		
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Hoursleave.class);
		
		return  cr.list();
		
	}

	public Object delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Hoursleave d = (Hoursleave ) session.createCriteria(Hoursleave.class)
	             .add(Restrictions.eq("idhours_Leave", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
