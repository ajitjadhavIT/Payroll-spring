package com.example.PayRoll.Manager;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.SalrytypeDAO;
import com.example.PayRoll.POJO.Salarytype;
@Component
@Controller
public class SalarytypeManager 
{	@Autowired
	SalrytypeDAO salarytypedao;

	public Salarytype save(Salarytype st) {
		// TODO Auto-generated method stub
		return salarytypedao.save(st);
	}
	public Salarytype get(String Name) {
		// TODO Auto-generated method stub
		return salarytypedao.get(Name);
	}
	public List getall() {
		// TODO Auto-generated method stub
		return salarytypedao.getall();
	}
}
