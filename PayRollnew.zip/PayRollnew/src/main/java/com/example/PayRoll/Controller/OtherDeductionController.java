package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.BasicSalaryDAO;
import com.example.PayRoll.Manager.OtherDeductionManager;

@Controller
@RequestMapping("/Deduction")
public class OtherDeductionController {
	
	@Autowired
	OtherDeductionManager ODManager;
	
	
	@RequestMapping("/AllDeductions")
	@GetMapping
	@ResponseBody
	
	public Object AllDeduction(@RequestParam("empcode")String empcode,@RequestParam("Month")int month,@RequestParam("Year")int year )
	{
		return ODManager.AllDeductions(empcode,month,year);
	}
	

	@RequestMapping("/SingleDeduction")
	@GetMapping
	@ResponseBody

	public Object SingleDeduction(@RequestParam("empcode")String empcode,@RequestParam("Month")int month,@RequestParam("Year")int year)
	{
		return ODManager.SingleDeduction(empcode, month, year);
	}
}
