package com.example.PayRoll.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.OtherDeductionsManager;
import com.example.PayRoll.Manager.Provisional_FundManager;
import com.example.PayRoll.POJO.OtherDeduction;

import com.example.PayRoll.POJO.Provisional_Fund;
@Controller
@RequestMapping("OtherDeduction")
public class OtherDeductionsController {

	

	

		@Autowired
		OtherDeductionsManager ODManager;
		@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
		@PostMapping
		@CrossOrigin()
		@ResponseBody
		public OtherDeduction save(@RequestParam("id")int id,@RequestParam("Empcode")String Empcode,
				@RequestParam("dedname")String dedname,@RequestParam("Month")int month,
				@RequestParam("Amount")float amount,@RequestParam("year")int year)
		{
			
			return ODManager.save(id,Empcode,dedname,month,amount,year);
		}
			
		
		
	
		@RequestMapping("/get")
		@GetMapping
		@ResponseBody
		public Object get(@RequestParam("empcode") String empcode) 
		{
			return ODManager.get(empcode);

		}
		

		@RequestMapping("/getall")
		@GetMapping
		@ResponseBody
		public Object getall() 
		{
			return ODManager.getall();

		}
		
		
}

