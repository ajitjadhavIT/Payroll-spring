package com.example.PayRoll.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.EmployeeSalaryDAO;
import com.example.PayRoll.Manager.EmployeeSalaryManager;

@Controller
@RequestMapping("/EmpSal")
public class EmployeeSalaryController {

	@Autowired
	EmployeeSalaryManager EmpsalManager;
	@Autowired
	EmployeeSalaryDAO empsaldao;
	@RequestMapping("/empsal")
	@GetMapping
	@ResponseBody
	
	public List empsal(@RequestParam("empcode")String empcode,@RequestParam("month")int month,@RequestParam("year")int year)
	{
		return EmpsalManager.empsal(empcode,month,year);
	}
	
	
	@RequestMapping("/empsalary")
	@GetMapping
	@ResponseBody
	
	public double empsalary(@RequestParam("empcode")String empcode,@RequestParam("month")int month,@RequestParam("year")int year)
	{
		return empsaldao.EmployeeSalary(empcode, month, year);
	}
	
	@RequestMapping("/Welfare")
	@GetMapping
	@ResponseBody
	
	public float Welfare(@RequestParam("empcode")String empcode,@RequestParam("month")int month)
	{
		return empsaldao.Welfare(empcode, month);
	}
	
}
