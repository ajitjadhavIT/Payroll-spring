package com.example.PayRoll;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayRollApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayRollApplication.class, args);
	}
}
