package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emptype")
public class Emptype 
{
	@Id
	 int idEmpType;
	 String name;
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	 
}
