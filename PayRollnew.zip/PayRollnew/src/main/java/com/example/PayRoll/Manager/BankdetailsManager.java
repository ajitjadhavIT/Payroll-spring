package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;


import com.example.PayRoll.DAO.BankdetailsDAO;
//@ComponentScan(basePackages = "com.yogesh.shoponlinefrontend,com.yogesh.shoponlineback") 


@Component


public class BankdetailsManager 
{
	@Autowired
	BankdetailsDAO bankdao;
	
	public Object get(String empcode)
	{ 
		return bankdao.get(empcode);
		
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return bankdao.getall();
	}
	public Object delete(String empcode) {
		
		return bankdao.delete(empcode);
	}
	public Object update(int idbank,String empcode,String bankname,int accno,String branch,String acctype,String ifsccode,String pfno) {
		// TODO Auto-generated method stub
		return bankdao.update(idbank, empcode, bankname, accno, branch, acctype, ifsccode, pfno);
	}

}
