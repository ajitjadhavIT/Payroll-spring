package com.example.PayRoll.DAO;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;


import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.TblLeave;
import com.example.PayRoll.POJO.TDS;
import com.mysql.jdbc.MysqlDataTruncation;
import com.mysql.jdbc.exceptions.MySQLIntegrityConstraintViolationException;
@Controller
@Component
public class TDSDAO {

	@Autowired
	HipernateConfg hipernateConfg;
	
	
	
	public String save(TDS tds) {
		//idTDS, idEmpType, FromAmount, Percent, ToAmount, TDScol
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		session.saveOrUpdate(tds);
		t.commit();  
		session.close();
		
		return "Saved Successfully";
		
	
	}

	public Object get(String id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		TblLeave e1=new TblLeave();
		e1 = (TblLeave)session.get(TblLeave.class,id);
		t.commit();
		session.close(); 
		
		return e1;
	}

}
