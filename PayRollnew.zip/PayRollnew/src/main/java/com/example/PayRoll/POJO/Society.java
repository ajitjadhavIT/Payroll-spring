package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="society")
public class Society {
	@Id

	int idSociety;

	int idEmpType;
	float amount;
	public int getIdSociety() {
		return idSociety;
	}
	public void setIdSociety(int idSociety) {
		this.idSociety = idSociety;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Society [idSociety=" + idSociety + ", idEmpType=" + idEmpType + ", amount=" + amount + "]";
	}

	
}
