package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bonus")
public class Bonus 
{

	@Id
	int idBonus;
	int idEmployees;
	float presentDays;
	String year;
	float basicSal;
	float bonus;
	public int getIdBonus() {
		return idBonus;
	}
	public void setIdBonus(int idBonus) {
		this.idBonus = idBonus;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	public float getPresentDays() {
		return presentDays;
	}
	public void setPresentDays(float presentDays) {
		this.presentDays = presentDays;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public float getBasicSal() {
		return basicSal;
	}
	public void setBasicSal(float basicSal) {
		this.basicSal = basicSal;
	}
	public float getBonus() {
		return bonus;
	}
	public void setBonus(float bonus) {
		this.bonus = bonus;
	}
	
	
	
}
