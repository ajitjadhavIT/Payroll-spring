package com.example.PayRoll.POJO;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="attendance")
public class Attendance
{
	@Id
	 int idAttendance;//attendance
	 Date date;
	 int idShift;
	 int idDesignation;
	 int idEmployees;
	public int getIdAttendance() {
		return idAttendance;
	}
	public void setIdAttendance(int idAttendance) {
		this.idAttendance = idAttendance;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getIdShift() {
		return idShift;
	}
	public void setIdShift(int idShift) {
		this.idShift = idShift;
	}
	public int getIdDesignation() {
		return idDesignation;
	}
	public void setIdDesignation(int idDesignation) {
		this.idDesignation = idDesignation;
	}
	public int getIdEmployees() {
		return idEmployees;
	}
	public void setIdEmployees(int idEmployees) {
		this.idEmployees = idEmployees;
	}
	@Override
	public String toString() {
		return "Attendance [idAttendance=" + idAttendance + ", date=" + date + ", idShift=" + idShift
				+ ", idDesignation=" + idDesignation + ", idEmployees=" + idEmployees + "]";
	}
	
}
