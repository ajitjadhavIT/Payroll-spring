package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;



@Component
public class Attd_leave_reportbetweenDates
{
List presentreportBetdates=new ArrayList();
	
	List leavereportbetdates=new ArrayList();
	
	List Totalbetdates=new ArrayList();

	public List getPresentreportBetdates() {
		return presentreportBetdates;
	}

	public void setPresentreportBetdates(List presentreportBetdates) {
		this.presentreportBetdates = presentreportBetdates;
	}

	public List getLeavereportbetdates() {
		return leavereportbetdates;
	}

	public void setLeavereportbetdates(List leavereportbetdates) {
		this.leavereportbetdates = leavereportbetdates;
	}

	public List getTotalbetdates() {
		return Totalbetdates;
	}

	public void setTotalbetdates(List totalbetdates) {
		Totalbetdates = totalbetdates;
	}


	
}
