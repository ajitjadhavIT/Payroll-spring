package com.example.PayRoll.DAO;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Emptype;
import com.example.PayRoll.POJO.Overtime;
import com.example.PayRoll.POJO.Shift;
@Component
@Controller
public class OvertimeDAO 
{	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	EmployeeDAO EmployeeDAO;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	DesignationDAO designationDAO;

	public String save(Overtime ovr) 
	{
		/*Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		int id1=0;
		Employees emp=(Employees) EmployeeDAO.get(ovr.getEmoployeeCode());
		int id=emp.getIdEmployees();
		Shift sft=(Shift) shiftDAO.get(ovr.getShift());
		int idShift=sft.getIdShift();
		 Designation des= (Designation) designationDAO.get(ovr.getShortform());
		 int idDes=des.getIdDesignation();
		 
		 Overtime ov=new Overtime();
		 ov.setDate(ovr.getDate());
		 ov.setShift(String.valueOf(idShift));
		 ov.setShortform(String.valueOf(idDes));
		 ov.setEmoployeeCode(String.valueOf(id));
		 ov.setHours(ovr.getHours());
		 session.save(ov);
		 t.commit();
		 session.close();  */
		 
		return "saved Successfully";
	}

	public Object get(String empcode,Date dt) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id =emp.getIdEmployees();
		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Overtime.class);
		cr.add(Restrictions.eq("id", id));
		cr.add(Restrictions.eq("dt", dt));
		return (Overtime) cr.uniqueResult();
		
	
	
	}
	public List Overtime_Report(Date date)
	{//shift,Department,Designation,Employee Code,Employee Name,Hours.
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
		List<Map<String,Object>> overtimedata=new ArrayList<Map<String,Object>>();
		Map empdata=new HashMap();
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		Date userdate=calendar.getTime();

	
		long basicSal=4000;
		long one_hr_salary=basicSal/8;
		
		
		
		Query e= session.createQuery("Select idShift, idDesignation, idEmoployees, Hours from Overtime where Date = :date");
		e.setParameter("date", date);
		List<Object[]> overtime=e.list();
		
				
		int idShift=(int) overtime.get(0)[0];
		int idEmployees=(int) overtime.get(0)[2];
		int idDesignation=(int) overtime.get(0)[1];
	
		Criteria cp=session.createCriteria(Employees.class);
		Projection a3=Projections.property("employeeCode");
		Projection as=Projections.property("emp_First_Name");
		Projection a1=Projections.property("emp_Middle_Name");
		Projection a2=Projections.property("emp_Last_Name");
	
		ProjectionList pa=Projections.projectionList();
		
		pa.add(as);
		pa.add(a1);
		pa.add(a2);
		pa.add(a3);
		cp.setProjection(pa);
		List<Object[]> name_Code=cp.list();
		
		
		
		String EmpName=String.valueOf(name_Code.get(0)[0])+" "+String.valueOf(name_Code.get(0)[1])+" "+String.valueOf(name_Code.get(0)[2]);
		String EmployeeCode=(String) name_Code.get(0)[3];
		
		
		Criteria cd=session.createCriteria(Shift.class);
		cd.add(Restrictions.eq("idShift", idShift));
		Projection ap=Projections.property("name");
		cd.setProjection(ap);
		String shift=(String)cd.uniqueResult();
		

		Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name from Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
		query3.setParameter("idDesignation", idDesignation);
		List<Object[]> des=query3.list();
		
		String Designation_Name=(String) des.get(0)[0];
		String DeptName=(String)des.get(0)[2];
		double Overtime_hours= Double.parseDouble( overtime.get(0)[3].toString());
		System.err.println("Just edited data"+Overtime_hours);
		//double over_hours=Overtime_hours.doubleValue();
		double total_Overtime_salary=one_hr_salary*Overtime_hours;
		empdata.put("shift", shift);
		empdata.put("Department", DeptName);
		empdata.put("Designation", Designation_Name);
		empdata.put("Employee Code", EmployeeCode);
		empdata.put("Employee Name", EmpName);
		empdata.put(" Overtime_Hours",Overtime_hours);
		empdata.put("overtime_salary", total_Overtime_salary);
		overtimedata.add(empdata);
		return overtimedata;
	}
   public List Monthly_Overtime_report(String month1,String year1)
   {
	   Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
	   Calendar calendar = Calendar.getInstance();
	   int month=Integer.parseInt(month1);
	   int year=Integer.parseInt(year1);
		calendar.set(year, month-1, 1);
		Date Datef=calendar.getTime();
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date Datel=calendar.getTime();
	
	
		long basicSal=4000;
		long one_hr_salary=basicSal/8;
		List dept=new ArrayList();
		List<Map<String,Object>> overtime_data=new ArrayList<Map<String,Object>>();
	
		 Criteria cr=session.createCriteria(Department.class);
		 Projection pr=Projections.property("idDepartment");
		 Projection pt=Projections.distinct(pr);
		 cr.setProjection(pt);
		 dept=cr.list();
		for(int i=0;i<dept.size();i++)
		{
			int id1=(int) dept.get(i);
			Map map=new HashMap();
			System.err.println("id"+id1);
	
			
			Query d= session.createQuery("SELECT idDesignation,sum(Hours) from Overtime where idDesignation in (select idDesignation from Designation where idDepartment = :id1) and Date between :Datef and :Datel group by idDesignation");
	          d.setParameter("id1", id1);
	          d.setParameter("Datef", Datef);
	          d.setParameter("Datel", Datel);
			List<Object[]> des_Hours=d.list();
			
			
			int idDesignation=(int) des_Hours.get(0)[0];
			Criteria cp=session.createCriteria(Designation.class);
			cp.add(Restrictions.eq("idDesignation", idDesignation));
			Projection a=Projections.property("name");
			cp.setProjection(a);
			
			String Designation =(String) cp.uniqueResult();
			
		
			Criteria cps=session.createCriteria(Department.class);
			cps.add(Restrictions.eq("idDepartment", id1));
			Projection as=Projections.property("name");
			cps.setProjection(as);
			
			String Department_name =(String) cps.uniqueResult();
			
			BigDecimal Overtime_hours=(BigDecimal) des_Hours.get(0)[1];
			double over_hours=Overtime_hours.doubleValue();
			double total_Overtime_salary=one_hr_salary*over_hours;
			map.put("Department_name", Department_name);
			map.put("Designation", Designation);
			map.put("Overtime_Hours", des_Hours.get(0)[1]);
			map.put("total_Overtime_salary", total_Overtime_salary);
			overtime_data.add(map);
		}
		return overtime_data;   
   }
   public List yearly_Overtime_report(String year1)
   {
	   Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		
	   Calendar calendar = Calendar.getInstance();
	   int year=Integer.parseInt(year1);
		calendar.set(year, 0, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.YEAR, 1);  
	   // calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		List dept=new ArrayList();
		List<Map<String,Object>> overtime_data=new ArrayList<Map<String,Object>>();
		
		 Criteria cr=session.createCriteria(Department.class);
		 Projection pr1=Projections.property("idDepartment");
		 
		 Projection pr=Projections.distinct(pr1);
		 cr.setProjection(pr);
		 dept=cr.list();
		 for(int i=0;i<dept.size();i++)
			{
				int id1=(int) dept.get(i);
				Map map=new HashMap();
				System.err.println("id"+id1);
				System.err.println("firstdate"+FirstDate);
				System.err.println("lastdate"+LastDate);
			Criteria r=session.createCriteria(Designation.class);
			r.add(Restrictions.eq("idDepartment", id1));
			Projection pd=Projections.property("idDesignation");
			Projection pd1=Projections.property("name");
			ProjectionList pl=Projections.projectionList();
			pl.add(pd);
			pl.add(pd1);
			r.setProjection(pl);
			List<Object[]>idDesignationname= r.list();
			int idDesignation=(int) idDesignationname.get(0)[0];
			String Designation=(String) idDesignationname.get(0)[1];
			Criteria sd=session.createCriteria(Overtime.class);
			sd.add(Restrictions.eq("idDesignation", idDesignation));
			sd.add(Restrictions.ge("date", FirstDate));
			sd.add(Restrictions.lt("date", LastDate));
			Projection p=Projections.sum("hours");
			sd.setProjection(p);
			float ovrhours=(float) sd.uniqueResult();
			
			Criteria s=session.createCriteria(Department.class);
			s.add(Restrictions.eq("idDepartment", id1));
			Projection f=Projections.property("name");
			s.setProjection(f);
	
			String Department_name=(String) s.uniqueResult();
		
			map.put("Department_name", Department_name);
			map.put("Designation", Designation);
			map.put("Overtime_Hours", ovrhours);
			overtime_data.add(map);
		}
		return overtime_data;   
   }

public List getall() {
	Session session = (Session) hipernateConfg.getSession();  

	Criteria cr = session.createCriteria(Overtime.class);
	
	return cr.list();
	
}

public Object delete(int id) {
	Session session = (Session) hipernateConfg.getSession();  
	Transaction t = session.beginTransaction();
	Overtime d = (Overtime ) session.createCriteria(Overtime.class)
             .add(Restrictions.eq("idOvertime", id)).uniqueResult();
	session.delete(d);
	t.commit();
	return null;
}
}
