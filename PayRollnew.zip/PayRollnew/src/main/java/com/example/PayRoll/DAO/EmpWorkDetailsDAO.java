package com.example.PayRoll.DAO;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Catagory;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.EmpWorkDetails;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Shift;

@Component
@Controller
public class EmpWorkDetailsDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	@Autowired
	BasicSalaryDAO basicSalaryDAO;
	@Autowired
	EmployeeDAO employeeDAO;
	
	public EmpWorkDetails save(int idwork,String empcode,int IdDesignation, int IdShift,String wrkarea,String jdate1) throws ParseException 
	{	
		 SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		 Date jdate = sdf.parse(jdate1);
		 
		
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		EmpWorkDetails e=new EmpWorkDetails();
		Employees emp=(Employees) employeeDAO.get(empcode);
		int idEmployees=emp.getIdEmployees();
		e.setIdEmpWorkDetails(idwork);
		e.setIdEmployees(idEmployees);
		e.setIdDesignation(IdDesignation);
		e.setIdShift(IdShift);
		e.setWork_Area(wrkarea);
		e.setJoining_Date(jdate);
		session.saveOrUpdate(e);
		t.commit();
		session.close();
		return e;
	}

	public Object get(String empcode)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Employees emp=(Employees) employeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(EmpWorkDetails.class);
				cr.add(Restrictions.eq("idEmployees", id));
				return (EmpWorkDetails) cr.uniqueResult();
			
	}

	public List Monthly_joining_Report(String month1,String year1) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		// Department, Date , Employee Code, Employee name, Designation, Address, Contact.
			int month=Integer.parseInt(month1);
			int year=Integer.parseInt(year1);
		 	List<Map<String,Object>> monthjoinReport =new ArrayList<Map<String,Object>>();
			Calendar calendar = Calendar.getInstance();
			calendar.set(year, month-1, 1);
			Date Datef=calendar.getTime();
			calendar.add(Calendar.MONTH, 1);  
		    calendar.set(Calendar.DAY_OF_MONTH, 1);  
		    calendar.add(Calendar.DATE, -1);  
			Date Datel=calendar.getTime();
			
			
			
			List<Object[]> idEmployees=new ArrayList<Object[]>();
		
			Criteria cr=session.createCriteria(EmpWorkDetails.class);
			cr.add(Restrictions.ge("date", Datef));
			cr.add(Restrictions.lt("date", Datel));
			Projection s=Projections.property("idEmployees");
			Projection a=Projections.property("idDesignation");
			Projection b=Projections.property("idShift");
			Projection c=Projections.property("joining_Date");
			ProjectionList pl=Projections.projectionList();
			pl.add(s);
			pl.add(a);
			pl.add(b);
			pl.add(c);
			cr.setProjection(pl);
			idEmployees=cr.list();
			for(Object[] id:idEmployees)
			{
				int idEmp=(int) id[0];
				int idDes=(int) id[1];
				int idShift=(int)id[2];
				Date date=(Date) id[3];
				Criteria cp=session.createCriteria(Employees.class);
				cp.add(Restrictions.eq("idEmployees", idEmp));
				Projection a4=Projections.property("employeeCode");
				Projection a1=Projections.property("emp_First_Name");
				Projection a2=Projections.property("emp_Middle_Name");
				Projection a3=Projections.property("emp_Last_Name");
				Projection a5=Projections.property("address");
				Projection a6=Projections.property("contact_No");
				ProjectionList pt=Projections.projectionList();
				pt.add(a1);
				pt.add(a2);
				pt.add(a3);
				pt.add(a4);
				pt.add(a5);
				pt.add(a6);
				cp.setProjection(pt);
				List<Object[]> empdata=cp.list();

				
				String empname=String.valueOf(empdata.get(0)[0])+" "+String.valueOf(empdata.get(0)[1])+" "+String.valueOf(empdata.get(0)[2]);
				long EmpCode=(long) empdata.get(0)[3];
				String Address=(String) empdata.get(0)[4];
				long ContacNO=(long) empdata.get(0)[5];
				Criteria cd=session.createCriteria(Shift.class);
				cd.add(Restrictions.eq("idShift", idShift));
				Projection ap=Projections.property("name");
				cd.setProjection(ap);
				String shift=(String)cd.uniqueResult();

				Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name from Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDes");
				query3.setParameter("idDes", idDes);
				List<Object[]> des=query3.list();
				String Designation_Name=(String) des.get(0)[0];
				String DeptName=(String)des.get(0)[1];
				Map map=new HashMap();
				map.put("Department", DeptName);
				map.put("Date",date);
				map.put("Employee Code", EmpCode);
				map.put("Employee name", empname);
				map.put("Designation", Designation_Name);
				map.put("Address", Address);
				map.put("Contact", ContacNO);
				monthjoinReport.add(map);
			}
			return monthjoinReport;
	}
	public List yearly_joining_Report(String year1) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		// Department, Date , Employee Code, Employee name, Designation, Address, Contact.
		 	List<Map<String,Object>> monthjoinReport =new ArrayList<Map<String,Object>>();
			Calendar calendar = Calendar.getInstance();
			int year=Integer.parseInt(year1);
			calendar.set(year, 0, 1);
			Date Datef=calendar.getTime();
			calendar.add(Calendar.YEAR, 1);  
		    //calendar.set(Calendar.DAY_OF_MONTH, 1);  
		    calendar.add(Calendar.DATE, -1);  
			Date Datel=calendar.getTime();
			
			List<Object[]> idEmployees=new ArrayList<Object[]>();
			Criteria cr=session.createCriteria(EmpWorkDetails.class);
			cr.add(Restrictions.ge("date", Datef));
			cr.add(Restrictions.lt("date", Datel));
			Projection s=Projections.property("idEmployees");
			Projection a=Projections.property("idDesignation");
			Projection b=Projections.property("idShift");
			Projection c=Projections.property("joining_Date");
			ProjectionList pl=Projections.projectionList();
			pl.add(s);
			pl.add(a);
			pl.add(b);
			pl.add(c);
			cr.setProjection(pl);
			idEmployees=cr.list();
			for(Object[] id:idEmployees)
			{
				int idEmp=(int) id[0];
				int idDes=(int) id[1];
				int idShift=(int)id[2];
				Date date=(Date) id[3];
				
				Criteria cp=session.createCriteria(Employees.class);
				cp.add(Restrictions.eq("idEmployees", idEmp));
				Projection a4=Projections.property("employeeCode");
				Projection a1=Projections.property("emp_First_Name");
				Projection a2=Projections.property("emp_Middle_Name");
				Projection a3=Projections.property("emp_Last_Name");
				Projection a5=Projections.property("address");
				Projection a6=Projections.property("contact_No");
				ProjectionList pt=Projections.projectionList();
				pt.add(a1);
				pt.add(a2);
				pt.add(a3);
				pt.add(a4);
				pt.add(a5);
				pt.add(a6);
				cp.setProjection(pt);
				List<Object[]> empdata=cp.list();;
				String empname=String.valueOf(empdata.get(0)[0])+" "+String.valueOf(empdata.get(0)[1])+" "+String.valueOf(empdata.get(0)[2]);
				long EmpCode=(long) empdata.get(0)[3];
				String Address=(String) empdata.get(0)[4];
				long ContacNO=(long) empdata.get(0)[5];
				
				Criteria cd=session.createCriteria(Shift.class);
				cd.add(Restrictions.eq("idShift", idShift));
				Projection ap=Projections.property("name");
				cd.setProjection(ap);
				String shift=(String)cd.uniqueResult();

				Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name from Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDes");
				query3.setParameter("idDes", idDes);
				List<Object[]> des=query3.list();
				String Designation_Name=(String) des.get(0)[0];
				String DeptName=(String) des.get(0)[2];
				Map map=new HashMap();
				map.put("Department", DeptName);
				map.put("Date",date);
				map.put("Employee Code", EmpCode);
				map.put("Employee name", empname);
				map.put("Designation", Designation_Name);
				map.put("Address", Address);
				map.put("Contact", ContacNO);
				monthjoinReport.add(map);
			}
			
		
		return monthjoinReport;
	}
	public List MusterRollon_Report()
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();

		List<Object[]> iddes=new ArrayList<Object[]>();
		List<Map<String,Object>> Muster_Report=new ArrayList<Map<String,Object>>();
	
		
		Criteria cr=session.createCriteria(EmpWorkDetails.class);
		Projection pr=Projections.groupProperty("idDesignation");
		Projection p7=Projections.rowCount();
		ProjectionList pl7=Projections.projectionList();
		pl7.add(pr);
		pl7.add(p7);
		cr.setProjection(pl7);
		iddes=cr.list();
		
		for(Object[] row:iddes)
		{
			Map muster=new HashMap();
			int idDesignation=(int) row[0];
			Criteria r=session.createCriteria(Designation.class);
			r.add(Restrictions.eq("idDesignation", idDesignation));
			Projection p=Projections.property("name");
			Projection p1=Projections.property("idDepartment");
			Projection p2=Projections.property("idCatagory");
		ProjectionList pl=Projections.projectionList();
		pl.add(p);
		pl.add(p1);
		pl.add(p2);
		r.setProjection(pl);
			List<Object[]> des=r.list();
			int idDepartment=(int) des.get(0)[1];
			String Designation_Name=(String) des.get(0)[0];
			Criteria cd=session.createCriteria(Department.class);
			
			cd.add(Restrictions.eq("idDepartment", idDepartment));
			Projection ap=Projections.property("name");
			cd.setProjection(ap);
			String DeptName=(String)cd.uniqueResult();

			int idCategory=(int) des.get(0)[2];
			
			Criteria cd1=session.createCriteria(Catagory.class);
			
			cd1.add(Restrictions.eq("idCatagory", idCategory));
			Projection ap1=Projections.property("name");
			cd1.setProjection(ap1);
			String Catagory_name=(String)cd1.uniqueResult();
			
			muster.put("Department", DeptName);
			muster.put("Catagory", Catagory_name);
			muster.put("Designation", Designation_Name);
			muster.put("Employees", row[1]);
			Muster_Report.add(muster);
		}
		return Muster_Report;
	}
}
