package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="groupdeduction")
public class GroupDeductions {

	@Id
	int idGroupDeduction;
	int idEmpType;
	int idDeductions;
	@Override
	public String toString() {
		return "GroupDeductions [idGroupDeduction=" + idGroupDeduction + ", idEmpType=" + idEmpType + ", idDeductions="
				+ idDeductions + "]";
	}
	public int getIdGroupDeduction() {
		return idGroupDeduction;
	}
	public void setIdGroupDeduction(int idGroupDeduction) {
		this.idGroupDeduction = idGroupDeduction;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	public int getIdDeductions() {
		return idDeductions;
	}
	public void setIdDeductions(int idDeductions) {
		this.idDeductions = idDeductions;
	}
	
}
