package com.example.PayRoll.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="incentiveamount")
public class IncentAmount 
{//idIncentiveamount, idIncentive, Condition, amount, idemptype
	@Id
	int idIncentiveamount;
	int idincentive;
	int condition1;
	float amount;
	int idEmpType;
	public int getIdIncentiveamount() {
		return idIncentiveamount;
	}
	public void setIdIncentiveamount(int idIncentiveamount) {
		this.idIncentiveamount = idIncentiveamount;
	}
	public int getIdincentive() {
		return idincentive;
	}
	public void setIdincentive(int idincentive) {
		this.idincentive = idincentive;
	}
	public int getCondition1() {
		return condition1;
	}
	public void setCondition1(int condition1) {
		this.condition1 = condition1;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public int getIdEmpType() {
		return idEmpType;
	}
	public void setIdEmpType(int idEmpType) {
		this.idEmpType = idEmpType;
	}
	

	
	
	
}
