package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Contractor;
import com.example.PayRoll.POJO.OtherDeductiontype;
@Component
@Controller
public class ContractorDAO  {

	@Autowired
	HipernateConfg hipernateConfg;
	
	
	
	public Contractor save(int id,String name,String addr,int contact,String email) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
//idContractor, Name, Address, Contact, Email
		Contractor c=new Contractor();
		c.setIdContractor(id);
		c.setName(name);
		c.setAddress(addr);
		c.setContact(contact);
		c.setEmail(email);
		
		session.saveOrUpdate(c);
		t.commit();  
		session.close();
		return c;
		
	}
	public List get(String Name)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//@SuppressWarnings("deprecation")
			Criteria cr = session.createCriteria(Contractor.class);
			cr.add(Restrictions.eq("name", Name));
			return cr.list();
	
	}
	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		
			Criteria cr = session.createCriteria(Contractor.class);
		
			return  cr.list();
	}
	public List delete(int id) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Contractor d = (Contractor ) session.createCriteria(Contractor.class)
                 .add(Restrictions.eq("idContractor", id)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}
	
	
}
