package com.example.PayRoll.DAO;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.query.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.Manager.BasicSalaryManager;
import com.example.PayRoll.POJO.Attendance;
import com.example.PayRoll.POJO.DayPresent;
import com.example.PayRoll.POJO.Department;
import com.example.PayRoll.POJO.Designation;
import com.example.PayRoll.POJO.Employees;
import com.example.PayRoll.POJO.Shift;


@Component
@Controller
public class AttendanceDAO 
{
	@Autowired
	HipernateConfg hipernateConfg;
	
	
@Autowired
WorkhoursDAO1 whdao;
@Autowired
BasicSalaryManager bsmanager;
@Autowired
BasicSalaryDAO bsdao;
	@Autowired
	DayPresent dp;
	
	
	@Autowired
	EmployeeDAO EmployeeDAO;
	@Autowired
	ShiftDAO shiftDAO;
	@Autowired
	DesignationDAO designationDAO;
	@Autowired
	EmployeeDAO employeeDAO;
	@Autowired
	DepartmentDAO departmentDAO;
	public String save(int idAttendance, Date date,String shift,String Shortform,String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Criteria cr=session.createCriteria(Shift.class);
		cr.add(Restrictions.eq("name", shift));
		Projection pr=Projections.property("idShift");
		cr.setProjection(pr);
		
			int idShift=(int) cr.uniqueResult();
		int idDesignation=designationDAO.get(Shortform).getIdDesignation();
		int idemp=EmployeeDAO.get(empcode).getIdEmployees();
		Attendance a=new Attendance();
		a.setIdAttendance(idAttendance);
		a.setDate(date);
		a.setIdDesignation(idDesignation);
		a.setIdEmployees(idemp);
		a.setIdShift(idShift);
		session.saveOrUpdate(a);
	
		t.commit();  
		session.close();
		return "Saved Succesfully";
	}

	public Attendance get(Date date,String empcode) 
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		//@SuppressWarnings("deprecation")
		Employees emp=(Employees) EmployeeDAO.get(empcode);
		int id=emp.getIdEmployees();
		System.err.println("id"+id+"\ndate"+date);
		Criteria cr = session.createCriteria(Attendance.class);
		cr.add(Restrictions.eq("idEmployees", id));
		cr.add(Restrictions.eq("date", date));
		System.err.println(cr.uniqueResult());
		return (Attendance) cr.uniqueResult();
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  
		Criteria cr = session.createCriteria(Attendance.class);
		
		return  cr.list();
	
	}
	public List presentReport(Date date)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		//shift,Department,Designation,Employee Code,Employee Name
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		Date userdate=calendar.getTime();
		List<Object[]> getempsftdesid=new ArrayList<Object[]>();
		List<Map<String,Object>> present_Report=new ArrayList<Map<String,Object>>();
		Query query=session.createQuery("select idEmployees in(select idEmployees from empworkdetails where idDesignation in(select idDesignation from Designation where idDepartment )), idDesignation, idShift from Attendance where Date = :date");
		query.setParameter("date", date);
		getempsftdesid=query.list();
		for(Object[] ts:getempsftdesid)
		{
			Map empdata=new HashMap();
			int idEmployees=(int) ts[0];
			int idShift=(int) ts[2];
			int idDesignation=(int) ts[1];
			Query query1=session.createQuery("select emp_First_Name,emp_Middle_Name,emp_Last_Name,employeeCode from Employees where idEmployees = :idEmployees");
			query1.setParameter("idEmployees", idEmployees);
			List<Object[]> name_Code=query1.list();
			String EmpName=String.valueOf(name_Code.get(0)[0])+" "+String.valueOf(name_Code.get(0)[1])+" "+String.valueOf(name_Code.get(0)[2]);
			String EmployeeCode= (String)name_Code.get(0)[3];
			Query query2=session.createQuery("Select name from Shift where idShift = :idShift");
			query2.setParameter("idShift", idShift);
			String shift=(String) query2.uniqueResult();
			Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
			query3.setParameter("idDesignation", idDesignation);
			List<Object[]> des=query3.list();
			
			String Designation_Name=(String) des.get(0)[0];
			String DeptName=(String) des.get(0)[2];
		
			empdata.put("shift", shift);
			empdata.put("Department", DeptName);
			empdata.put("Designation_Name",Designation_Name);
			empdata.put("EmployeeCode",EmployeeCode);
			empdata.put("Employee Name", EmpName);
			present_Report.add(empdata);
		}
		return present_Report;
	}
	public List Monthly_presentReport(String month1,String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> dept_desig_count=new ArrayList<Map<String,Object>>();
		Calendar calendar = Calendar.getInstance();
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		calendar.set(year, month-1, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.MONTH, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		
		
		List<Integer> dept=new ArrayList<Integer>();
		Query query1=session.createQuery("select idDepartment from Designation where idDesignation in (select distinct idDesignation from Attendance where Date between :FirstDate and :LastDate )");
		query1.setParameter("FirstDate", FirstDate);
		query1.setParameter("LastDate", LastDate);
		dept=query1.list();
		
		for(int id:dept)
		{
			int id1=(int) id;
			Map map=new HashMap();
			System.err.println("id"+id1);
			System.err.println("firstdate"+FirstDate);
			System.err.println("lastdate"+LastDate);
		
		Query query2=session.createQuery("select idDesignation,count(*) from Attendance where idDesignation in (select idDesignation from Designation where "
				+ "idDepartment = :id1) and Date between :FirstDate and :LastDate group by idDesignation");
		query2.setParameter("id1", id1);
		query2.setParameter("FirstDate", FirstDate);
		query2.setParameter("LastDate", LastDate);
		List<Object[]> des_count=query2.list();
		int idDesignation=(int) des_count.get(0)[0];
		Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
		query3.setParameter("idDesignation", idDesignation);
		List<Object[]> des=query3.list();
		String Designation=(String) des.get(0)[0];
		String Department_name=(String) des.get(0)[2];
		System.err.println("Deptname"+Department_name);
		map.put("DepartmentName", Department_name);
		map.put("Count",des_count.get(0)[1]);
		map.put("Designation",Designation);
		System.err.println("Count"+des_count.get(0)[1]);
		dept_desig_count.add(map);
		}
		return dept_desig_count;
	}

	public List yearly_present_report(String year1)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> dept_desig_count=new ArrayList<Map<String,Object>>();
		int year=Integer.parseInt(year1);
		Calendar calendar = Calendar.getInstance();
		calendar.set(year, 0, 1);
		Date FirstDate=calendar.getTime();
		calendar.add(Calendar.YEAR, 1);  
	   // calendar.set(Calendar.DAY_OF_MONTH, 1);  
	    calendar.add(Calendar.DATE, -1);  
		Date LastDate=calendar.getTime();
		
		List<Integer> dept=new ArrayList<Integer>();
		Query query=session.createQuery("select idDepartment from Designation where idDesignation in"
				+ "(select distinct idDesignation from Attendance where Date between :FirstDate and :LastDate)");
		query.setParameter("FirstDate", FirstDate);
		query.setParameter("LastDate", LastDate);
		dept=query.list();
		for(int id:dept)
		{
			int id1=(int) id;
			Map map=new HashMap();
			System.err.println("id"+id1);
			System.err.println("firstdate"+FirstDate);
			System.err.println("lastdate"+LastDate);
		
			Query query1=session.createQuery("select idDesignation,count(*) from Attendance where idDesignation in (select idDesignation from Designation where "
					+ "idDepartment = :id1 ) and Date between :FirstDate and :LastDate group by idDesignation");
			query1.setParameter("id1", id1);
			query1.setParameter("FirstDate", FirstDate);
			query1.setParameter("LastDate", LastDate);
			List<Object[]> des_count=query1.list();
			int idDesignation=(int) des_count.get(0)[0];
			Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :idDesignation");
			query3.setParameter("idDesignation", idDesignation);
			List<Object[]> des=query3.list();
			
		String Designation=(String) des.get(0)[0];
		String Department_name=(String) des.get(0)[2];
		System.err.println("Deptname"+Department_name);
		map.put("DepartmentName", Department_name);
		map.put("Count",des_count.get(0)[1]);
		map.put("Designation",Designation);
		System.err.println("Count"+des_count.get(0)[1]);
		dept_desig_count.add(map);
		}
		return dept_desig_count;
		
	}
	public DayPresent Day_Report(Date date1)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date1);
		Date date=calendar.getTime();
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Object[]> Experienced1=new ArrayList<Object[]>();
		List<Object[]> trainee1=new ArrayList<Object[]>();
		Query experienced1=session.createQuery("SELECT idShift,count(*) from Attendance where idEmployees in (select idEmployees from Employees where idEmpType in"
				+ " (select idEmpType from Emptype where name != 'Trainee'))and Date = :date Group by idShift");
		experienced1.setParameter("date", date);
		Experienced1=experienced1.list();
		
		Query Trainee1=session.createQuery("SELECT idShift,count(*) from Attendance where idEmployees in (select idEmployees from Employees where idEmpType in"
				+ " (select idEmpType from Emptype where name = 'Trainee'))and Date = :date Group by idShift");
		Trainee1.setParameter("date", date);
		trainee1=Trainee1.list();
		
		dp.setexperienced(Experienced1);
		System.err.print("list"+Experienced1);
		System.err.print("Date"+date);
		dp.setTrainee(trainee1);
		System.err.print("list1"+trainee1);
		return dp;
	}
	public List attdday_groupbyshift(Date date)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		Query query=session.createQuery("select idEmployees, count(*) from Attendance where Date = :date group by idShift");
		query.setParameter("date", date);
		list=query.list();
		return list;
	}
	public List attdday_groupbydept(String deptName,String date) 
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		Query query=session.createQuery("Select idDepartment from Department where name = :deptName");
		query.setParameter("deptName", deptName);
		long idDept=(long) query.uniqueResult();
		
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		
		Query query1=session.createQuery("select idDesignation,count(*) from Attendance where idDesignation in (select idDesignation from Designation where idDepartment = :idDept ) and Date = :date group by idDesignation");
		query1.setParameter("idDept", idDept);
		query1.setParameter("date", date);
		List<Object[]> m=query1.list();
		
		long iddes=(long) m.get(0)[0];
		Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :iddes");
		query3.setParameter("iddes", iddes);
		List<Object[]> des=query3.list();
		String Deptname=(String) des.get(0)[2];
		Map ms=new HashMap();
		ms.put("Department Name", Deptname);
		ms.put("Count", m.get(0)[1]);
		list.add(ms);
		return list;
	}
	public List attdday_dept_groupbyShift(String deptName,String date)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
	
		Query query=session.createQuery("Select idDepartment from Department where name = :deptName");
		query.setParameter("deptName", deptName);
		long idDept=(long) query.uniqueResult();
		
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		List<Object[]> list1=new ArrayList<Object[]>();
		
		Query query1=session.createQuery("select idDesignation,count(*) from Attendance where idDesignation in (select idDesignation from Designation where idDepartment = :idDept ) and Date = :date group by idShift");
		query1.setParameter("idDept", idDept);
		query1.setParameter("date", date);
		list1=query1.list();
		
		for(Object[] rs:list1)
		{
			long iddes=(long) rs[0];
			Query query3=session.createQuery("SELECT  t1.name,t1.idDepartment, t2.name FROM Designation t1 join Department t2 ON t1.idDepartment = t2.idDepartment where t1.idDesignation = :iddes");
			query3.setParameter("iddes", iddes);
			List<Object[]> des=query3.list();
			String Deptname=(String) des.get(0)[2];

			Map ms=new HashMap();
			ms.put("Department Name", Deptname);
			ms.put("Count", rs[1]);
			list.add(ms);
		}
		
		return list;
		
	}
	public List attd_Weekly_report(String week1,String month1,String year1) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Calendar calendar = Calendar.getInstance();
		int week=Integer.parseInt(week1);
		int month=Integer.parseInt(month1);
		int year=Integer.parseInt(year1);
		calendar.set(year, month-1, 1);
		int wk = calendar.get(Calendar.WEEK_OF_MONTH);
		calendar.set(Calendar.WEEK_OF_MONTH,week);
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

	    ArrayList days = new ArrayList();
	    int delta = -calendar.get(GregorianCalendar.DAY_OF_WEEK) + 1; //add 2 if your week start on monday
	    calendar.add(Calendar.DAY_OF_MONTH, delta );
	    for (int i = 0; i < 7; i++)
	    {
	        days.add(format.format(calendar.getTime()));
	        calendar.add(Calendar.DAY_OF_MONTH, 1);
	    }
		System.err.println("days"+days);
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		 
		for(int i=0;i<days.size();i++)
		{
		Map m=new HashMap();
		String date1=  (String) days.get(i);
		System.err.println("date1"+date1);
		Date date=format.parse(date1);
		Query query=session.createQuery("select count(*) from Attendance where date = :date");
		query.setParameter("date", date);
		long count=(long) query.uniqueResult();
		System.err.println("date"+date);
		m.put("date", date1);
		m.put("count", count);
		list.add(m);
		}
		return list;
	}
	public List Monthly_pre_groupbyDay(String Month1,String year1) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH-1, 1);  
	    calendar.set(Calendar.DAY_OF_MONTH, 1); 
	    int Month=Integer.parseInt(Month1);
	    int year=Integer.parseInt(year1);
	    calendar.add(Calendar.DATE, -1);
		calendar.set(year, Month-1, 1);
		int month = calendar.get(Calendar.MONTH-1);
		calendar.set(Calendar.MONTH,Month-1);
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		Date lastdate=calendar.getTime();
		
	    ArrayList<Date>days = new ArrayList<Date>();
	    int delta = -calendar.get(GregorianCalendar.DAY_OF_MONTH) + 1 ; //add 2 if your week start on monday
	    calendar.add(Calendar.DAY_OF_MONTH, delta );
	    int ld=Calendar.getInstance().getActualMaximum(Calendar.DAY_OF_MONTH);
		System.err.println("ld"+ld);
	    for (int i = 0; i < ld; i++)
	    {
	        days.add(calendar.getTime());
	        calendar.add(Calendar.DAY_OF_MONTH, 1);
	    }
		System.err.println("days"+days);
		List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
		 
		for(int i=0;i<days.size();i++)
		{
			
		Map m=new HashMap();
		Date date=  format.parse(format.format(days.get(i))) ;
		
		//String[] day=date.split("/")[2];
		//String day1=date.split("/")[2];
		Query query=session.createQuery("select count(*) from Attendance where date = :date");
		query.setParameter("date", date);
		long count=(long) query.uniqueResult();
		System.err.println("date"+date);
		m.put("date", format.format(date).split("/")[2]);
		m.put("count", count);
		list.add(m);
		}
		return list;
		
	}
	public List yearly_groupbyMonth(String year1) throws ParseException
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Calendar calendar = Calendar.getInstance();
		int year=Integer.parseInt(year1);
		
		calendar.set(year, 0, 1);
		calendar.add(Calendar.YEAR, 1);  
		calendar.add(Calendar.DATE, -1);
		int month = calendar.get(Calendar.MONTH);
		ArrayList Month = new ArrayList();
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	    int delta = -calendar.get(GregorianCalendar.MONTH) ; //add 2 if your week start on monday
	    calendar.add(Calendar.MONTH, delta );
	    List<Map<String,Object>> Month1=new ArrayList<Map<String,Object>>();
	    
	    for (int i = 0; i < 12; i++)
	    {
	    	Map ms=new HashMap();
	    	calendar.set(Calendar.DAY_OF_MONTH, 1);
	  
	    	ms.put("StratDate",format.format( calendar.getTime()));
	    	calendar.add(Calendar.MONTH, 1);  
	 	   // calendar.set(Calendar.DAY_OF_MONTH, 1);  
	 	    calendar.add(Calendar.DATE, -1);
	 	    
	    	ms.put("Lastdate",format.format( calendar.getTime()));

	    	Month1.add(ms);
	    	Month.add(format.format(calendar.getTime()));
	        calendar.add(Calendar.MONTH, 1);
	    }
	    
	    List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
	    for(int i=0;i<Month.size();i++)
		{
		String fd= (String) Month1.get(i).get("StratDate");	
		String ld= (String) Month1.get(i).get("Lastdate");
		System.err.println("fd"+fd);
		System.err.println("ld"+ld);
		Map m=new HashMap();
		String date1=  (String) Month.get(i);
		Date date=format.parse(date1);
		//String[] day=date.split("/")[2];
		//String day1=date.split("/")[2];
		
		Query query=session.createQuery("select count(*) from Attendance where Date = :date");
		query.setParameter("date", date);
		long count=(long) query.uniqueResult();
		m.put("Month", (date1).split("/")[1]);
		m.put("count", count);
		list.add(m);
		}
	    
		return list;
	}
	public List Report_groupbyyear(int year)
	{
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Calendar calendar = Calendar.getInstance();
		 int year1 =year+1;
		calendar.set(year1, 0, 1);
		//calendar.add(Calendar.YEAR, 1);  
		calendar.add(Calendar.DATE, -1);
		int Year = calendar.get(Calendar.YEAR);
		ArrayList Month = new ArrayList();
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	    int delta = -calendar.get(GregorianCalendar.MONTH) ; //add 2 if your week start on monday
	    calendar.add(Calendar.MONTH, delta );
	    List<Map<String,Object>> Month1=new ArrayList<Map<String,Object>>();
	    
	    for (int i = 0; i < 12; i++)
	    {
	    	Map ms=new HashMap();
	    	calendar.set(Calendar.DAY_OF_MONTH, 1);
	  
	    	ms.put("StratDate",format.format( calendar.getTime()));
	    	calendar.add(Calendar.MONTH, 1);  
	 	   // calendar.set(Calendar.DAY_OF_MONTH, 1);  
	 	    calendar.add(Calendar.DATE, -1);
	 	    
	    	ms.put("Lastdate",format.format( calendar.getTime()));

	    	Month1.add(ms);
	    	Month.add(format.format(calendar.getTime()));
	        calendar.add(Calendar.MONTH, 1);
	    }
	    
	    List<Map<String,Object>> list=new ArrayList<Map<String,Object>>();
	    int c =0;
	    for(int i=0;i<Month.size();i++)
		{
		String fd= (String) Month1.get(i).get("StratDate");	
		String ld= (String) Month1.get(i).get("Lastdate");
		System.err.println("fd"+fd);
		System.err.println("ld"+ld);
		
		//String date=  (String) Month.get(i);
		//String[] day=date.split("/")[2];
		//String day1=date.split("/")[2];
		//select count(*) from attendence where date between "+fd+" and  "+ld+"
		Query query=session.createQuery("select count(*) from Attendance where date between :fd and :ld");
		query.setParameter("fd",fd );
		query.setParameter("ld",ld );
		long count=(long) query.uniqueResult();
		System.err.println("count"+count);
		c += count;
		
		}
	    Map m=new HashMap();
	    m.put("year", year);
		m.put("count", c);
		list.add(m);
		return list;
	}
	public List presentReport1(Date date,String Group,String Department,String Catagory,String Designation,String Shift,String Employee_Code) throws ParseException
	 {
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		List<Integer> From_dept=new ArrayList<Integer>();
		List<Integer> From_group=new ArrayList<Integer>();
		List<Integer> From_Category=new ArrayList<Integer>();
		List<Integer> From_designation=new ArrayList<Integer>();
		List<Integer> from_employeecode=new ArrayList<Integer>();
		List<Integer> Common_list=new ArrayList<Integer>();
		List<Attendance> present_report=new ArrayList<Attendance>();
		List<Integer> Shift_report=new ArrayList<Integer>();
		int idemp=0;
		//Group, Department,Category,Designation,Shift,Employee Code,Date
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		Date date1=format.parse(format.format(date));
		
		
		System.err.println("Catagory"+Catagory);
		Query q=session.createQuery("select idEmployees from EmpWorkDetails");
		Common_list=q.list();
  		System.err.println("Common_list"+Common_list);

		 if(!Group.isEmpty())
	        {
			 
	        	Query g=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in "
	        			+ "(select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from Employees where idEmpType = (select idEmpType from Emptype  where name = :Group)))");
	        	g.setParameter("Group", Group);
	        	From_group=g.list();
	        	Common_list.retainAll(From_group);
	       		System.err.println(" grp Common_list"+Common_list);

	        }
		 if(!Employee_Code.isEmpty())
	        {
			 Employees emp=(Employees)employeeDAO.get(Employee_Code);
				idemp=emp.getIdEmployees();
					        	
	        	from_employeecode.add(idemp);
	        	Common_list.retainAll(from_employeecode);
	       		System.err.println("empcode Common_list"+Common_list);

	        }
		 else if(!Designation.isEmpty())
		 {
			 Designation ds=(Designation) designationDAO.get(Designation);
			 int iddes=ds.getIdDesignation();
			 Query d=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from EmpWorkDetails where idDesignation in (select idDesignation from Designation where Name = :Designation))");
			 d.setParameter("Designation", Designation);
			 From_designation=d.list();;
			 Common_list.retainAll(From_designation);
		   		System.err.println("des Common_list"+Common_list);

		 }
		 else if(!Catagory.isEmpty())
	        {
	        	Query c=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from EmpWorkDetails where idDesignation in (select distinct idDesignation from Designation where idCatagory in(select idCatagory from catagory where Name = :Catagory)))");
	        	c.setParameter("Catagory", Catagory);
	        	From_Category=c.list();
	        	Common_list.retainAll(From_Category);
	       		System.err.println("in cat Common_list"+Common_list);

	        }
		 else if(!Department.isEmpty())
      {
			 Department dept = (Department) departmentDAO.get(Department);
			int idDept=dept.getIdDepartment();
				
		Query dept1=session.createQuery("select idEmployees from EmpWorkDetails where idEmployees in(select idEmployees from EmpWorkDetails where idDesignation in (select distinct idDesignation from Designation where idDepartment in(select idDepartment from Department where Name =:Department)))");
		dept1.setParameter("Department", Department);
		From_dept=dept1.list();
		Common_list.retainAll(From_dept);
  		System.err.println("in dept Common_list"+Common_list);

      }
		
      else
      {
      	System.err.println("invalid input");
      }
      if(!Shift.isEmpty())
      {
   	   Shift e1=new Shift();
  		  	e1 = (Shift)session.createCriteria(Shift.class).add( Restrictions.eq("Name", Shift )).uniqueResult();
  		   int idshift=e1.getIdShift();
  		   System.err.println("Common_list"+Common_list);
  		   Query shift=session.createQuery("select idEmployee from Attendance where idShift =:idshift and Date=:date");
  		   shift.setParameter("idshift", idshift);
  		   shift.setParameter("date", date1);
  		   Shift_report=shift.list();
  		   Common_list.retainAll(Shift_report);
  		   		
      }
      System.err.println("Shift_report"+Shift_report);
    
     System.err.println(Shift);
      System.err.println("date"+date1);
    System.err.println("Common_list"+Common_list);
		Query r=session.createQuery("select empt.Name as Emptype,dept.Name as department,cat.Name as Catagory,"
				+ "desg.Name as Designation ,emp.EmployeeCode as EmployeeCode ,sft.Name as Shift,whr.inTime "
				+ "as Intime,whr.outTime as Outtime,TIMEDIFF(Intime, Outtime)as timdef,CONCAT(emp.Emp_First_Name, ' ',emp.Emp_Middle_Name,' '"
				+ ",emp.Emp_Last_Name) AS EmployeeName "
				+ "from Department dept, Shift sft,Workhours whr, Emptype "
				+ "as empt , Employees AS emp, Catagory AS cat , Designation as desg "
				+ "where emp.idEmployees in :Common_list "
				+ "and empt.idEmpType = (select idEmpType from Employees where idEmployees = emp.idEmployees) "
				+ "and desg.idDesignation = (select idDesignation from EmpWorkDetails where idEmployees = emp.idEmployees) "
				+ "and cat.idCatagory = (select idCatagory from Designation where idDesignation = desg.idDesignation) "
				+ "and dept.idDepartment = (select idDepartment from Catagory  where idCatagory = cat.idCatagory) "
				+ "and sft.idShift=(select distinct idShift from Attendance where Date = :date and idEmployee = emp.idEmployees) "
				+ "and whr.idWorkHours=(select idWorkHours from Workhours where idAttendance = (select idAttendance from Attendance where date = :date and idEmployee = emp.idEmployees))");
		r.setParameter("Common_list", Common_list);
		r.setParameter("date", date1);
		present_report=r.list();
		
		return present_report;
     
	 }

}