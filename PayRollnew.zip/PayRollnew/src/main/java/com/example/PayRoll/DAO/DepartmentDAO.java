package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Department;


@Component
@Controller
public class DepartmentDAO 
{	@Autowired
	HipernateConfg hipernateConfg;
	
	
	public Department save(int id,String name)
	{	
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Department d=new Department();
		d.setIdDepartment(id);
		d.setName(name);
		session.saveOrUpdate(d);
		t.commit();
		session.close();
		return d;
		
	}

	public Department get(String name)
	{
		Session session = (Session) hipernateConfg.getSession();  
	
		//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(Department.class);
				cr.add(Restrictions.eq("name", name));
				return (Department) cr.uniqueResult();
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();
		Criteria cr = session.createCriteria(Department.class);
		
		return  cr.list();
	}

	public Object delete(String name) {
		
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Department d = (Department ) session.createCriteria(Department.class)
                 .add(Restrictions.eq("name", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
