package com.example.PayRoll.Controller;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.DAO.WorkhoursDAO1;
import com.example.PayRoll.POJO.Workhours;

@Component
@Controller
@RequestMapping("/WorkHours")
public class WorkHoursController {

	@Autowired
	WorkhoursDAO1 whDAO;
	
	@RequestMapping(value = "save", method = RequestMethod.POST, consumes= {MediaType.APPLICATION_JSON_VALUE})
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Workhours save(@RequestBody Workhours a)
	{
		
		return whDAO.save(a);
	}
	@RequestMapping("/PresentHR")
	@PostMapping
	@ResponseBody
	public Object get(@RequestParam("empcode")String empcode,@RequestParam("month")int month,@RequestParam("year")int year) throws ParseException
	{
		return whDAO.PresentDaybyHR(empcode, month, year);
	}
	
	//PresentDaybyHRbyDate
	
	
	@RequestMapping("/PresentHRByDay")
	@PostMapping
	@ResponseBody
	public Object get(@RequestParam("empcode")String empcode,@RequestParam("date")Date dt) throws ParseException
	{
		return whDAO.PresentDaybyHRbyDate(empcode, dt);
	}
	
}
