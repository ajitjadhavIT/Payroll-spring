package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.PayRoll.DAO.LeaveAprovalDAO;
import com.example.PayRoll.POJO.LeaveAproval;
@Component
public class LeaveAprovalManager {
@Autowired
LeaveAprovalDAO laDAO;
	public LeaveAproval save(LeaveAproval la) {
		// TODO Auto-generated method stub
	
		return laDAO.save(la);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return laDAO.getall();
	}

}
