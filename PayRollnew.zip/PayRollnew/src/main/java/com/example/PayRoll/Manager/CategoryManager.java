package com.example.PayRoll.Manager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.DAO.CategoryDAO;
import com.example.PayRoll.POJO.Catagory;
@Component
@Controller
public class CategoryManager 
{
	@Autowired
	CategoryDAO catdao;
	
	public Catagory save(int idcat,String dept,String name) 
	{
		return catdao.save(idcat,dept,name);
	}
	public Object get(String name) 
	{
		return catdao.get(name);
	}
	public Object getall() {
		// TODO Auto-generated method stub
		return catdao.getall();
	}
	public Object delete(String name) {
		// TODO Auto-generated method stub
		return catdao.delete(name);
	}

}
