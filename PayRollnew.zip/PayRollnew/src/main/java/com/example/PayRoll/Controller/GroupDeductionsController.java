package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.GroupDeductionsManager;
import com.example.PayRoll.POJO.GroupDeductions;

@Controller
@Component
@RequestMapping("/GroupDeductions")
public class GroupDeductionsController {

	@Autowired
	GroupDeductionsManager gdManager;
	
	@RequestMapping("/save")
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	public GroupDeductions save(@RequestParam("id") int idGroupDeduction,@RequestParam("emptype")String emptype,@RequestParam("deduction")String deduction)
	{
		return gdManager.save(idGroupDeduction,emptype,deduction);
	}
	@RequestMapping("/getall")
	@PostMapping
	@CrossOrigin()
	@ResponseBody
	public Object getall()
	{
		return gdManager.getall();
	}
}
