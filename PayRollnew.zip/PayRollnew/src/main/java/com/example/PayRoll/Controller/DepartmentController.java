package com.example.PayRoll.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.PayRoll.Manager.DepartmentManager;
import com.example.PayRoll.POJO.Department;

@Component
@Controller
@RequestMapping("/Department")
public class DepartmentController 
{
	@Autowired
	DepartmentManager deptman;
	
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/get")
	public Object get(@RequestParam("Name")String name)
	{
		return deptman.get(name);
	}
	@GetMapping
	@CrossOrigin()
	@ResponseBody
	@RequestMapping("/save")
	public Department save(@RequestParam("id")int id,@RequestParam("name")String name)
	{
		
		
		return deptman.save(id,name);
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/getall")
	public Object getall()
	{
		
		return deptman.getall();
		
	}
	@GetMapping
	@ResponseBody
	@CrossOrigin()
	@RequestMapping("/delete")
	public Object Delete(@RequestParam("Name")String name)
	{
		return deptman.delete(name);
		
	}
}
