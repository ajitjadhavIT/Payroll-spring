package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class WagesDayFilter {


	List salday=new ArrayList();
	List overtimeday=new ArrayList();
	List leaveDay=new ArrayList();
	List totalday=new ArrayList();
	public List getSalday() {
		return salday;
	}
	public void setSalday(List salday) {
		this.salday = salday;
	}
	public List getOvertimeday() {
		System.err.println("in get = "+overtimeday);
		return overtimeday;
	}
	public void setOvertimeday(List overtimeday) {
		this.overtimeday = overtimeday;
		
	}
	public List getLeaveDay() {
		System.err.println("in get = "+leaveDay);
		return leaveDay;
	}
	public void setLeaveDay(List leaveDay) {
		this.leaveDay = leaveDay;
		System.err.println("in set = "+leaveDay);
	}
	public List getTotalday() {
		return totalday;
	}
	public void setTotalday(List totalday) {
		this.totalday = totalday;
	}
	
}
