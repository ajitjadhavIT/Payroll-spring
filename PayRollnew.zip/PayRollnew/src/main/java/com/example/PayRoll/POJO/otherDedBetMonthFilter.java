package com.example.PayRoll.POJO;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class otherDedBetMonthFilter {

	
	List otherded=new ArrayList();
	Map total=new HashMap();
	public List getOtherded() {
		return otherded;
	}
	public void setOtherded(List otherded) {
		this.otherded = otherded;
	}
	public Map getTotal() {
		return total;
	}
	public void setTotal(Map total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "otherDedBetMonthFilter [otherded=" + otherded + ", total=" + total + "]";
	}
	
	
}
