package com.example.PayRoll.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.example.PayRoll.HipernateConfg;
import com.example.PayRoll.POJO.Absent;
import com.example.PayRoll.POJO.Catagory;
import com.example.PayRoll.POJO.Department;

@Component
@Controller

public class CategoryDAO 
{	@Autowired
	HipernateConfg hipernateConfg;
	@Autowired 
	DepartmentDAO deptdao;
	
	public Catagory save(int idcat,String dept,String name)
	{	
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		int iddept=deptdao.get(dept).getIdDepartment();
		
System.err.println(iddept+"idcat  "+idcat+"name"+name);
		Catagory ct=new Catagory();
		ct.setIdCatagory(idcat);
		ct.setIdDepartment(iddept);
		ct.setName(name);
		session.saveOrUpdate(ct);
		t.commit();  
		session.close();
		return ct;
	}

	public Catagory get(String name) 
	{	
		Session session = (Session) hipernateConfg.getSession();  

				//@SuppressWarnings("deprecation")
				Criteria cr = session.createCriteria(Catagory.class);
				cr.add(Restrictions.eq("name", name));
				return (Catagory) cr.uniqueResult();
	}

	public List getall() {
		Session session = (Session) hipernateConfg.getSession();  

		//@SuppressWarnings("deprecation")
		Criteria cr = session.createCriteria(Catagory.class);

		return  cr.list();
		
	}

	public Object delete(String name) {
		Session session = (Session) hipernateConfg.getSession();  
		Transaction t = session.beginTransaction();
		Catagory d = (Catagory ) session.createCriteria(Catagory.class)
                 .add(Restrictions.eq("name", name)).uniqueResult();
		session.delete(d);
		t.commit();
		return null;
	}

}
